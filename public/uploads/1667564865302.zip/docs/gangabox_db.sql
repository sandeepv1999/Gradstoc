-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 30, 2020 at 05:56 PM
-- Server version: 8.0.18-0ubuntu0.19.10.1
-- PHP Version: 7.1.33-2+ubuntu19.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gangabox_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:yes, 0:no',
  `i_by` bigint(20) DEFAULT NULL,
  `i_date` datetime DEFAULT NULL,
  `u_by` bigint(20) DEFAULT NULL,
  `u_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `user_id`, `subject`, `comment`, `is_deleted`, `i_by`, `i_date`, `u_by`, `u_date`) VALUES
(1, 2847204835381, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL),
(2, 2847204835381, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL),
(3, 2847204835381, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL),
(4, 2847204835381, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL),
(5, 2847204835385, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL),
(6, 2847204835385, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL),
(7, 2847204835385, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL),
(8, 2847204835385, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL),
(9, 2847204835385, 'test', 'bola na test', 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setting_master`
--

CREATE TABLE `setting_master` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_by` bigint(20) DEFAULT NULL,
  `u_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `setting_master`
--

INSERT INTO `setting_master` (`id`, `title`, `key`, `value`, `u_by`, `u_date`) VALUES
(1, 'Support Email', 'support_email', 'info@gangabox.com', 1, '2019-12-19 05:20:50'),
(2, 'Support Number', 'support_number', '+52126792465', 1, '2019-12-19 05:20:50');

-- --------------------------------------------------------

--
-- Table structure for table `user_devices`
--

CREATE TABLE `user_devices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `language` char(3) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'en',
  `device_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `device_type` char(1) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `access_token` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `login_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:Normal, 2:Facebook,3:Google',
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:active, 0:inactive',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:yes, 0:no',
  `i_by` bigint(20) DEFAULT NULL,
  `i_date` datetime DEFAULT NULL,
  `u_by` bigint(20) DEFAULT NULL,
  `u_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_devices`
--

INSERT INTO `user_devices` (`id`, `user_id`, `language`, `device_id`, `device_type`, `access_token`, `login_type`, `is_active`, `is_deleted`, `i_by`, `i_date`, `u_by`, `u_date`) VALUES
(118, 2847204835365, 'en', NULL, NULL, 'a9byZZBqWVKRrYnPw1kco+0Zb1qdp09crj0bLmOfUmocMPYAdUsQAD7W0+KYf0fcp1EsyIIiUa+yJWF2030amQ==', 1, 1, 0, NULL, NULL, NULL, NULL),
(119, 2847204835366, 'en', NULL, NULL, 'HozTdoTNcMta41uGL6qbDzH7DvPA28YQmyY+HVxbpYFsGMfdypbwWlSGf6ZLXrElDrVoioRoGSFcXKQ7Q/l/+Q==', 1, 1, 0, NULL, NULL, NULL, NULL),
(120, 2847204835368, 'en', NULL, NULL, '6SXL6qwpsm6GVcVYUNh/XHDk9VoaYaJoOTjcTgQ0w4RYyJhHJj+GdnDxXA+WJabNwyDB+USZi9+dol8dxrD2zQ==', 1, 1, 0, NULL, NULL, NULL, NULL),
(121, NULL, 'en', NULL, NULL, 'IlzBiNHjcTQSSjQnpz8i71vFr022831cvpmIznY7iiMWjWesLf+PjRKgJPmSmGUO/ckueSUwxYFCjeIguDc+OA==', 1, 1, 0, NULL, NULL, NULL, NULL),
(122, 2847204835374, 'en', NULL, NULL, 'KwQmBHfqneFwbLhryM39bfTG9zgwYK968MXz+X4ZQLB0vexO4EO6V6RjvHgPYERXWuQiws0UzT/gwjkGthdrqQ==', 1, 1, 0, NULL, NULL, NULL, NULL),
(123, NULL, 'en', NULL, NULL, 'pviDCCsdolMHtwb7k2xIXp2ZD+QQcmdKEiIXowz2hFk46mh5fsnAhSaH8Sf6u/4TTqQz0/ww+1rH4iZVHqTxew==', 1, 1, 0, NULL, NULL, NULL, NULL),
(124, 2847204835376, 'en', NULL, NULL, '5f+o9odgph9aXM/OBFij6z+h+iXxx/tvVYywHJ4EsLaUTtoXwgjkLpz3HZ2icybvmRTItVoqRndfk150cDcQaw==', 1, 1, 0, NULL, NULL, NULL, NULL),
(125, 2847204835377, 'en', NULL, NULL, 'j6uu/BFm7ZZIlE1v566lX4JCO1vsjJNa0mz+NDGYbqoyZz8bO5QQhuBP9bMauUpwoVdAAZNF7/XbfB5+hSyOcw==', 1, 1, 0, NULL, NULL, NULL, NULL),
(126, 2847204835380, 'en', NULL, NULL, 'ahM4BuDKLgrlKSCeRQ2z03BfIrDdtbXmFNRf4NybrEFkxu6212xYw3HdmNVtAYaxs1lwIMgm5DPUK4sbljNqXQ==', 1, 1, 0, NULL, NULL, NULL, NULL),
(132, 2847204835382, 'en', NULL, NULL, 'vCqDpCD8pEhJCpVdSsvetUxQYpIy3Rpwsj3YzwAB/3DMJEvRwDE9kt/63hA46X/ClJW57U0jJjOPtnNFQc77DQ==', 1, 1, 0, NULL, NULL, NULL, NULL),
(133, NULL, 'en', NULL, '1', 'hNUrbhfYam8lnGilVOca5F1eMsY9dR1pwUhgOVf8pm/D91hbgsRMSkzN55HmJoara26h5zzNjeLSlSaskCaIrQ==', 1, 1, 0, NULL, NULL, NULL, NULL),
(134, NULL, 'en', '111777', '1', 'wyI7gjTQ/9sUqM5mPCZqsmbFxX0YQOdKJ/+u03hHyZAZvs4tNY0aKZ6MOsBYxy+pib56xN/T/3jiwUGzL1JwpQ==', 1, 1, 0, NULL, NULL, NULL, NULL),
(135, NULL, 'en', NULL, '1', 'aKc/MRI+5bODK9ea77gwjUz8d6ekqhaQf/yw9dvDQfMKFaXcskxCU2LPoLC+/S8f51sFWOkJzdvDG8Wr7HolKg==', 1, 1, 0, NULL, NULL, NULL, NULL),
(136, 2847204835391, 'en', NULL, '1', 'uZu6QLXYZH6Bl9aX+z1MuhbqZUUkQeRaQHPrh79ZGBHa3nV5pe1EhYb7PvjMvRVP86JfVEYDo88NuIoXqEG2qQ==', 1, 1, 0, NULL, NULL, NULL, NULL),
(137, NULL, 'en', NULL, '1', 'tHmIJdckTQJrTzU85HddhSj0RYW6GaFWS+1SZYnitIZJuPLc9znJrbNT+vS6wwEi9Eq2iMFbHxBQb8F6xi6z/g==', 1, 1, 0, NULL, NULL, NULL, NULL),
(138, 2847204835393, 'en', NULL, '1', 'SrrrEVeZDuSm+m5mmqGfWEpRhbyOGDiiGc1a889AMpdKtatQqvQW9N6rlhsNIEmUsTq0pz3mo6yXnQt8jw8tfw==', 1, 1, 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE `user_master` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `shopify_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_code` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:yes, 0:no',
  `notification_setting` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:yes, 0:no',
  `forgot_password_token` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `forgot_password_token_timeout` datetime DEFAULT NULL,
  `social_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:Normal, 2:Facebook,3:Google',
  `social_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:active, 0:inactive',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:yes, 0:no',
  `i_by` bigint(20) DEFAULT NULL,
  `i_date` datetime DEFAULT NULL,
  `u_by` bigint(20) DEFAULT NULL,
  `u_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`id`, `shopify_id`, `name`, `country_code`, `mobile_number`, `email`, `password`, `image`, `email_verified`, `notification_setting`, `forgot_password_token`, `forgot_password_token_timeout`, `social_type`, `social_id`, `is_active`, `is_deleted`, `i_by`, `i_date`, `u_by`, `u_date`) VALUES
(2847204835366, 2847264636962, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani98503@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, '007', 1, 0, NULL, '2020-01-23 09:13:11', NULL, '2020-01-23 09:13:11'),
(2847204835368, 2847209685026, 'abhishek', 'CA', '58664', 'abhishek.savani98501@peerbits.com', NULL, NULL, 1, 1, NULL, NULL, 1, '0077', 1, 0, NULL, '2020-01-23 10:39:26', NULL, '2020-01-23 10:39:26'),
(2847204835369, 2847320014882, 'abhishek', 'CA', '+919601375149', 'abhishek.savani985090@peerbits.com', NULL, NULL, 1, 1, NULL, NULL, 1, '00779', 1, 0, NULL, '2020-01-23 11:20:07', NULL, '2020-01-23 11:20:07'),
(2847204835370, 2847325159458, 'abhishek', 'CA', '+919601375166', 'abhishek.savani985066@peerbits.com', NULL, NULL, 1, 1, NULL, NULL, 1, '00766', 1, 0, NULL, '2020-01-23 11:30:51', NULL, '2020-01-23 11:30:51'),
(2847204835371, 2847343804450, 'abhishek', 'CA', '+919601375852', 'abhishek.savani985852@peerbits.com', NULL, NULL, 1, 1, NULL, NULL, 1, '007852', 1, 0, NULL, '2020-01-23 12:05:52', NULL, '2020-01-23 12:05:52'),
(2847204835372, 2847343804450, NULL, NULL, NULL, 'abhishek.savani985852@peerbits.com', NULL, NULL, 1, 1, NULL, NULL, 1, '0078521', 1, 0, NULL, '2020-01-23 12:16:14', NULL, '2020-01-23 12:16:14'),
(2847204835373, 2847360057378, NULL, NULL, NULL, 'abhishek.savani985002@peerbits.com', NULL, NULL, 1, 1, NULL, NULL, 1, '0078002', 1, 0, NULL, '2020-01-23 12:36:20', NULL, '2020-01-23 12:36:20'),
(2847204835374, 2847369920546, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani985033@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-23 12:56:20', NULL, '2020-01-23 12:56:20'),
(2847204835375, 2848096059426, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani9k6k57k@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-24 06:17:32', NULL, '2020-01-24 06:17:32'),
(2847204835376, 2848108871714, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani9k6k557k@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-24 06:44:13', NULL, '2020-01-24 06:44:13'),
(2847204835377, 2848212287522, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani555test@peerbits.com', '123456677', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-24 10:06:33', NULL, '2020-01-24 10:06:33'),
(2847204835378, 2848225656866, 'test_abhiraj1', NULL, NULL, 'abhishek.savani66test@peerbits.com', '12345667711', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-24 10:54:31', NULL, '2020-01-24 10:54:31'),
(2847204835379, 2848258752546, 'test_abhiraj1', NULL, NULL, 'abhishek.savani661test@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-24 12:03:59', NULL, '2020-01-24 12:03:59'),
(2847204835380, 2848307642402, 'test_abhiraj1', NULL, NULL, 'abhishek.savani6611test1@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-24 13:38:10', NULL, '2020-01-24 13:38:10'),
(2847204835381, 2851585261602, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani6611test11@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-28 06:29:21', NULL, '2020-01-28 06:29:21'),
(2847204835382, 2851684909090, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani.test_28_1_20___1@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-28 11:20:48', NULL, '2020-01-28 11:20:48'),
(2847204835383, 2852563058722, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani.test_28_1_20___2@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-29 10:20:51', NULL, '2020-01-29 10:20:51'),
(2847204835384, 2852563157026, NULL, NULL, NULL, 'abhishek.savani.test_28_1_20___3@peerbits.com', '123456', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-29 10:20:51', NULL, '2020-01-29 10:20:51'),
(2847204835385, 2852564336674, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani.test_28_1_20___4@peerbits.com', '12345677', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-29 10:23:57', NULL, '2020-01-29 10:23:57'),
(2847204835386, 2852568334370, NULL, NULL, NULL, 'abhishek.savani9850021@peerbits.com', NULL, NULL, 1, 1, NULL, NULL, 1, '00780021', 1, 0, NULL, '2020-01-29 10:33:18', NULL, '2020-01-29 10:33:18'),
(2847204835387, 2852570300450, 'test_abhiraj1', NULL, NULL, 'abhishek.savani985002111@peerbits.com', '12345677', NULL, 1, 1, NULL, NULL, 1, '0078002111', 1, 0, NULL, '2020-01-29 10:37:17', NULL, '2020-01-29 10:37:17'),
(2847204835388, 2852658937890, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani.test_28_1_20___5@peerbits.com', 'dee5dc5fdff246fc12863b71eead0d60ac6793dbfb5b639ce064ae851421879b', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-29 13:16:36', NULL, '2020-01-29 13:16:36'),
(2847204835389, 2852698882082, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani.test_28_1_20___6@peerbits.com', '$2b$10$BU.1vlffxbt7DadkChCzEOeDwgGn9kGPvS89V8F6nli3u5TlctxKS', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-29 13:50:23', NULL, '2020-01-29 13:50:23'),
(2847204835390, 2852706549794, 'Abhishek_Test11', NULL, NULL, 'abhishek.savani.test_28_1_20___7@peerbits.com', '$2b$10$i790Eo1BjcGA1fCpIylWCuAsXfIoYDyw7jDIgCjplv3RfE5/qvcUG', NULL, 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-29 13:50:23', NULL, '2020-01-29 13:50:23'),
(2847204835391, 2852710252578, 'test_abhiraj1', NULL, NULL, 'abhishek.savani.test_28_1_20___8@peerbits.com', '$2b$10$JM/HDOJN5J3WCMu8qL.ekuT5NcN0OQq8NbJOIbiIPqe/k6qjUlw7i', 'https://picsum.photos/200', 1, 1, NULL, NULL, 1, NULL, 1, 0, NULL, '2020-01-29 13:50:23', NULL, '2020-01-29 13:50:23'),
(2847204835392, 2853572214818, NULL, NULL, NULL, 'abhishek.savani___1111@peerbits.com', NULL, 'https://picsum.photos/200', 1, 1, NULL, NULL, 1, '007800211111134t11211', 1, 0, NULL, '2020-01-30 11:34:35', NULL, '2020-01-30 11:34:35'),
(2847204835393, 2853592465442, NULL, NULL, NULL, 'abhishek.savani___1111g@peerbits.com', NULL, 'https://picsum.photos/200', 1, 1, NULL, NULL, 1, '00780021g11', 1, 0, NULL, '2020-01-30 12:07:08', NULL, '2020-01-30 12:07:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting_master`
--
ALTER TABLE `setting_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_devices`
--
ALTER TABLE `user_devices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `access_token` (`access_token`);

--
-- Indexes for table `user_master`
--
ALTER TABLE `user_master`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `setting_master`
--
ALTER TABLE `setting_master`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user_devices`
--
ALTER TABLE `user_devices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;
--
-- AUTO_INCREMENT for table `user_master`
--
ALTER TABLE `user_master`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2847204835394;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
