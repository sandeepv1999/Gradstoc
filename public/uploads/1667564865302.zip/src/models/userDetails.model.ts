/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User Address model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin @peerbits.com>
 */
import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class UserDetails extends Model {
  public id!: number;
  public user_id!: number;
  public about_me!: string;
  public hourly_rate!: number;
  public fix_rate!: number;
  public can_set_price!: number;
  public avg_rating!: number;
  public view_count!: number;
  public total_jobs_done!: number;
  public avg_resp_time!: number;
  public total_users_rated!: number;
  public total_earnings!: number;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

UserDetails.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    about_me: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    hourly_rate: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    fix_rate: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    can_set_price: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    can_set_price_type: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    avg_rating: {
      type: DataTypes.FLOAT,
      allowNull: true,
    },

    view_count: {
      type: DataTypes.BIGINT,
      allowNull: true,
      defaultValue: 0,
    },

    total_jobs_done: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    avg_resp_time: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    total_users_rated: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    total_earnings: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    cancellation_percentage: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'user_details',
    timestamps: true,
    sequelize: sequelize, // this bit is important
    defaultScope: {
      where: { is_deleted: 0 },
      attributes: {
        exclude: ['is_active', 'is_deleted', 'i_by', 'u_by', 'createdAt', 'updatedAt'],
      },
    },
  },
);
