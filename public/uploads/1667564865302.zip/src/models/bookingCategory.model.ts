/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Booking Category model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <Faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class BookingCategory extends Model {
  public id!: number;
  public booking_id!: number;
  public category_id!: number;
  public name!: number;
  public language_code!: string;
}
const sequelize = setUpSequelize();

BookingCategory.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    booking_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    category_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    language_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    tableName: 'booking_categories',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);
