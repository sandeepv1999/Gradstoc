/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Category model
 * @copyright Peerbits
 * @author Arshad Shaikh <arshad@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class MusicianPayments extends Model {
  public id!: number;
  public booking_id!: number;
  public musician_id!: number;
  public outstanding_amount!: number;
  public paid_amount!: number;
  public pending_amount!: number;
  public payment_date!: string;
  public description!: string;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public i_date!: Date;
  public u_date!: Date;
}
const sequelize = setUpSequelize();

MusicianPayments.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    booking_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    musician_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    outstanding_amount: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    paid_amount: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    pending_amount: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    description: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    payment_date: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'i_date',
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'u_date',
    },
  },
  {
    tableName: 'musician_payments',
    timestamps: true,
    sequelize: sequelize, // this bit is important
    // scopes: {
    //   portfolio: {
    //     attributes: ['id', 'sound_url', 'icon_url', 'translation[0].name'],
    //   },
    // },
  },
);
