/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Reason model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { NotificationTranslation } from './notificationTranslation.model';
import { Booking } from './bookings.model';

export class Notifications extends Model {
  public id!: number;
  public from_id!: number;
  public receiver_ids!: string;
  public to_type!: number;
  public notification_type!: string;
  public redirection_id!: number;
  public read_by!: string;
  public deleted_by!: string;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

Notifications.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    from_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    receiver_ids: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: '',
    },
    to_type: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    notification_type: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    redirection_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    read_by: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: '',
    },
    deleted_by: {
      type: DataTypes.STRING(255),
      allowNull: true,
      defaultValue: '',
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'notifications',
    timestamps: true,
    sequelize: sequelize, // this bit is important
    scopes: {
      withTranslation: {
        include: [
          {
            model: NotificationTranslation,
            as: 'translation',
          },
        ],
      },
    },
  },
);

Notifications.hasMany(NotificationTranslation, { as: 'translation', foreignKey: 'notification_id', sourceKey: 'id' });
Notifications.hasOne(Booking, { as: 'booking', foreignKey: 'id', sourceKey: 'redirection_id' });
