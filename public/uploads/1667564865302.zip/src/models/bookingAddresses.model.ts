/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Booking Details model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { City } from './city.model';
import { Country } from './country.model';
import { State } from './state.model';

export class BookingAddress extends Model {
  public id!: number;
  public booking_id!: number;
  public contact_person!: string;
  public address!: string;
  public landmark!: string;
  public address_type!: string;
  public city!: number;
  public state!: number;
  public country!: number;
  public lat!: string;
  public lng!: string;
}
const sequelize = setUpSequelize();

BookingAddress.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    booking_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    contact_person: {
      // DEFAULT ADD USER NAME
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    address: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    landmark: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    address_type: {
      type: DataTypes.STRING(25),
      allowNull: false,
    },
    city: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    state: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    country: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    lat: {
      type: DataTypes.DOUBLE,
      allowNull: false,
    },
    lng: {
      type: DataTypes.DOUBLE,
      allowNull: false,
    },
  },
  {
    tableName: 'booking_address',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);

// BookingAddress.belongsTo(City, { as: 'city', foreignKey: 'city_id', targetKey: 'id' });
// BookingAddress.belongsTo(State, { as: 'state', foreignKey: 'state_id', targetKey: 'id' });
// BookingAddress.belongsTo(Country, { as: 'country', foreignKey: 'country_id', targetKey: 'id' });
