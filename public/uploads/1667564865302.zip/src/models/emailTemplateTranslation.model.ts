/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User model
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class EmailTemplateTranslation extends Model {
  public id!: number;
  public email_template_id!: number;
  public language_code!: string;
  public title!: string;
  public content!: string;
}
const sequelize = setUpSequelize();

EmailTemplateTranslation.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    email_template_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    language_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    title: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    content: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    tableName: 'email_templates_translation',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);
