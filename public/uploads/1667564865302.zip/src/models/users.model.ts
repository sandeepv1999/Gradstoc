/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User model
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { Model, DataTypes, Op, Sequelize } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { UserAddress } from './userAddresses.model';
import config from '../config';
import bcrypt from 'bcryptjs';
import { UserDetails } from './userDetails.model';
import { UserBankDetails } from './userBankDetails.model';
import { MusicianCategories } from './musicianCategories.model';
import { Token } from './tokens.model';
import { Roles } from './roles.model';
import { Actors } from '../utils/constants';
import { CategoryTranslation } from './categoryTranslation.model';
import { MusicianPortfolio } from './musicianPortfolio.model';
import { UserFavorites } from './userFavorite.model';
import { Booking } from './bookings.model';
import { State } from './state.model';
import { City } from './city.model';
import { Country } from './country.model';
import { Rating } from './rating.model';
import { RecentView } from './recentView.model';

export class User extends Model {
  public id!: number;
  public en_full_name!: string;
  public actor!: number;
  public email!: string;
  public password!: string;
  public dial_code!: string;
  public phone_number!: number;
  public image!: string;
  public user_language!: string;
  public is_notification!: number;
  public is_profile_completed!: number;
  public is_bank_completed!: number;
  public is_address_completed!: number;
  public is_password_created!: number;
  public is_music_detail_completed!: number;
  public is_portfolio_completed!: number;
  public email_verification_token!: string;
  public forgot_password_token!: string;
  public forgot_password_token_timeout!: string;
  public otp!: number;
  public is_email_verified!: number;
  public is_phone_verified!: number;
  public is_suspended!: number;
  public suspension_time!: string;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
  public details: UserDetails;
  public addresses: UserAddress[];
  public musician_categories!: MusicianCategories[];
  public portfolios!: MusicianPortfolio[];
  public tokens!: Token[];
  public roles!: Roles;
}
const sequelize = setUpSequelize();

User.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    en_full_name: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    actor: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '3',
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    password: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    dial_code: {
      type: DataTypes.STRING(6),
      allowNull: true,
      defaultValue: '+966',
    },
    phone_number: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    image: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    role: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    user_language: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 'en',
    },
    is_notification: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '1',
    },
    is_profile_completed: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_bank_completed: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_address_completed: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_password_created: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_music_detail_completed: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_portfolio_completed: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    email_verification_token: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    forgot_password_token: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    forgot_password_token_timeout: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    otp: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '1234',
    },
    is_email_verified: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_phone_verified: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_suspended: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    suspension_time: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'users',
    timestamps: true,
    sequelize: sequelize, // this bit is important
    defaultScope: {
      where: { is_deleted: 0 },
      attributes: {
        exclude: ['updatedAt', 'u_by', 'createdAt', 'i_by'],
      },
    },
    scopes: {
      login: {
        where: { is_deleted: 0, is_active: 1, actor: { [Op.in]: [1, 2] } },
      },
      withPassword: {
        attributes: {
          exclude: [
            'email_verification_token',
            'forgot_password_token',
            'forgot_password_token_timeout',
            'otp',
            'i_by',
            'createdAt',
            'u_by',
            'updatedAt',
            'role',
            'is_deleted',
            'is_active',
          ],
        },
      },
      withToken: {
        include: [
          {
            model: Token,
            as: 'tokens',
          },
        ],
      },
      customerLogin: {
        where: { is_deleted: 0, actor: Actors.Customer },
        include: [
          {
            model: UserAddress,
            as: 'address',
            include: [
              {
                model: City,
                as: 'city',
              },
              {
                model: State,
                as: 'state',
              },
              {
                model: Country,
                as: 'country',
              },
            ],
            required: false,
            where: { is_deleted: 0, is_active: 1 },
            attributes: [
              'id',
              'user_id',
              'contact_person',
              'address',
              'landmark',
              'address_type',
              'city_id',
              'state_id',
              'country_id',
              'lat',
              'lng',
              'is_default',
              [Sequelize.fn('', Sequelize.col('`address.city.name')), 'city_name'],
              [Sequelize.fn('', Sequelize.col('`address.state.name')), 'state_name'],
              [Sequelize.fn('', Sequelize.col('`address.country.name')), 'country_name'],
            ],
            // attributes: { exclude: ['is_deleted', 'is_active', 'i_by', 'createdAt', 'u_by', 'updatedAt'] },
          },
          {
            model: UserBankDetails,
            as: 'bank',
            required: false,
            where: { is_deleted: 0, is_active: 1 },
          },
        ],
        attributes: {
          exclude: [
            'forgot_password_token',
            'forgot_password_token_timeout',
            'otp',
            'i_by',
            'createdAt',
            'u_by',
            'updatedAt',
            'role',
            'is_deleted',
          ],
        },
      },
      musicianLogin: {
        where: { is_deleted: 0, actor: Actors.Musician },
        include: [
          {
            model: UserAddress,
            include: [
              {
                model: City,
                as: 'city',
              },
              {
                model: State,
                as: 'state',
              },
              {
                model: Country,
                as: 'country',
              },
            ],
            as: 'address',
            required: false,
            where: { is_deleted: 0, is_active: 1 },
            attributes: [
              'id',
              'user_id',
              'contact_person',
              'address',
              'landmark',
              'address_type',
              'city_id',
              'state_id',
              'country_id',
              'lat',
              'lng',
              'is_default',
              [Sequelize.fn('', Sequelize.col('`address.city.name')), 'city_name'],
              [Sequelize.fn('', Sequelize.col('`address.state.name')), 'state_name'],
              [Sequelize.fn('', Sequelize.col('`address.country.name')), 'country_name'],
            ],
            // attributes: { exclude: ['is_deleted', 'is_active', 'i_by', 'createdAt', 'u_by', 'updatedAt'] },
          },
          {
            model: UserBankDetails,
            as: 'bank',
            required: false,
            where: { is_deleted: 0, is_active: 1 },
          },
          {
            model: UserDetails,
            as: 'details',
            where: { is_deleted: 0, is_active: 1 },
          },
          // {
          //   model: MusicianCategories,
          //   include: [
          //     {
          //       model: CategoryTranslation,
          //       as: 'category',
          //     },
          //   ],
          //   as: 'musician_categories',
          //   required: false,
          // },
        ],
        attributes: [
          'id',
          [Sequelize.fn('', Sequelize.col('en_full_name')), 'name'],
          'email',
          'image',
          [Sequelize.fn('', Sequelize.col('dial_code')), 'country_code'],
          [Sequelize.fn('', Sequelize.col('phone_number')), 'mobile_number'],
          'is_email_verified',
          'is_profile_completed',
          'is_music_detail_completed',
          'is_address_completed',
          'is_portfolio_completed',
          'is_notification',
          'password',
          'is_suspended',
          'is_active',
          [Sequelize.fn('', Sequelize.col('details.about_me')), 'about_me'],
          [Sequelize.fn('', Sequelize.col('details.can_set_price')), 'is_rate_editable'],
          [Sequelize.fn('', Sequelize.col('details.hourly_rate')), 'hourly_rate'],
          [Sequelize.fn('', Sequelize.col('details.fix_rate')), 'full_day_rate'],
        ],
      },
    },
  },
);

User.hasOne(UserDetails, { as: 'details', foreignKey: 'user_id', sourceKey: 'id' });
User.hasMany(UserAddress, { as: 'addresses', foreignKey: 'user_id', sourceKey: 'id' });
User.hasMany(UserBankDetails, { as: 'banks', foreignKey: 'user_id', sourceKey: 'id' });
User.hasMany(MusicianCategories, { as: 'musician_categories', foreignKey: 'musician_id', sourceKey: 'id' });
User.hasMany(MusicianPortfolio, { as: 'portfolios', foreignKey: 'user_id', sourceKey: 'id' });
User.hasMany(Token, { as: 'tokens', foreignKey: 'user_id', sourceKey: 'id' });
User.belongsTo(Roles, { as: 'roles', foreignKey: 'role' });

User.hasOne(UserAddress, { as: 'address', foreignKey: 'user_id', sourceKey: 'id' });
User.hasOne(UserBankDetails, { as: 'bank', foreignKey: 'user_id', sourceKey: 'id' });
User.hasOne(UserFavorites, { as: 'favorites', foreignKey: 'musician_id', sourceKey: 'id' });

User.hasMany(Rating, { as: 'ratings', foreignKey: 'musician_id' });

// User.hasMany(Booking, { as: 'userBookings', foreignKey: 'user_id', sourceKey: 'id' });
// User.hasMany(Booking, { as: 'musicianBookings', foreignKey: 'musician_id', sourceKey: 'id' });

User.hasMany(RecentView, { as: 'recentview', foreignKey: 'user_id', sourceKey: 'id' });

User.beforeCreate(async function(user) {
  if (user.email) {
    const isEmailExist = await User.count({
      where: {
        email: user.email,
        actor: user.actor,
      },
    });
    if (isEmailExist > 0) {
      throw new Error('Email is already exists');
    }
  }

  if (user.phone_number) {
    const isPhoneExist = await User.count({
      where: { phone_number: user.phone_number, actor: user.actor },
    });
    if (isPhoneExist > 0) {
      throw new Error('Phone number is already exists');
    }
  }

  if (user.password) {
    const salt = await bcrypt.genSalt(config.BCRYPT_ROUND_FOR_PASSWORD);
    user.password = await bcrypt.hash(user.password, salt);
  }
});

// User.beforeUpdate(async function(user) {
//   console.log('hook', user);

//   if (user.password) {
//     const salt = await bcrypt.genSalt(config.BCRYPT_ROUND_FOR_PASSWORD);
//     user.password = await bcrypt.hash(user.password, salt);
//   }
// });
