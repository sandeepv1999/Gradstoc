/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User Address model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin @peerbits.com>
 */
import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class UserBankDetails extends Model {
  public id!: number;
  public user_id!: number;
  public full_name!: string;
  public bank_account_no!: number;
  public code!: string;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
  public iban!: string; //added on 21 june 2022
}
const sequelize = setUpSequelize();

export const DEFAULT_SCOPE_GETTER = () => ({
  where: { is_deleted: 0, is_active: 1 },
});
UserBankDetails.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    full_name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    bank_account_no: {
      type: DataTypes.STRING,
      allowNull: true, //added on 21 june 2022
    },
    code: {
      type: DataTypes.STRING,
      allowNull: true, //added on 21 june 2022
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    iban: { //added on 21 june 2022
      type: DataTypes.STRING,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'user_bank_details',
    timestamps: true,
    sequelize: sequelize, // this bit is important
    defaultScope: {
      where: {
        is_deleted: 0,
      },
      attributes: ['id', 'user_id', 'full_name', 'bank_account_no', 'code', 'is_active', 'is_deleted','iban'],
    },
  },
);
