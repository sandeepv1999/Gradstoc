/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Recent View model
 * @copyright Peerbits
 * @author Arshad Shaikh <arshad@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class RecentView extends Model {
  public id!: number;
  public user_id!: number;
  public musician_id!: number;
  public view!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

RecentView.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    musician_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    view: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'recent_view',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);
