/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Category model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class Settings extends Model {
  public id!: number;
  public key!: string;
  public title!: string;
  public value!: string;
}
const sequelize = setUpSequelize();

Settings.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    key: {
      type: DataTypes.STRING(20),
      allowNull: false,
    },
    title: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    value: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
  },
  {
    tableName: 'settings',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);
