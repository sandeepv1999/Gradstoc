/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Roles model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class Roles extends Model {
  public id!: number;
  public title!: string;
  public auth_item!: string;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

Roles.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    auth_item: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'roles',
    timestamps: true,
    sequelize: sequelize, // this bit is important
  },
);
