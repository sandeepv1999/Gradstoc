/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Country model
 * @copyright Peerbits
 * @author Arshad Shaikh <arshad@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class PaymentRequest extends Model {
  public id!: number;
  public booking_id!: number;
  public musician_id!: number;
  public amount!: number;
  public subject!: string;
  public message!: string;
  public description!: string;
  public is_approved!: number;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public i_date!: Date;
  public u_date!: Date;
}
const sequelize = setUpSequelize();

PaymentRequest.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    musician_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    booking_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    amount: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    message: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    subject: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    is_approved: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    i_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    u_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'payment_request',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);
