/**
 * @file Account Request model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class AccountRequest extends Model {
  public id!: number;
  public dial_code!: string;
  public phone_number!: number;
  public otp!: number;
}
const sequelizeInstance = setUpSequelize();
AccountRequest.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    dial_code: {
      type: DataTypes.STRING(5),
      allowNull: false,
    },
    phone_number: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    otp: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    tableName: 'account_request',
    timestamps: false,
    sequelize: sequelizeInstance,
  },
);
