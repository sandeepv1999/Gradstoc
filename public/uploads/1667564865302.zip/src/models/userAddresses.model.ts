/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User Address model
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { City } from './city.model';
import { State } from './state.model';
import { Country } from './country.model';

export class UserAddress extends Model {
  public id!: number;
  public user_id!: number;
  public contact_person!: string;
  public address!: string;
  public landmark!: string;
  public address_type!: string;
  public city_id!: number;
  public state_id!: number;
  public country_id!: number;
  public lat!: string;
  public lng!: string;
  public is_default!: number;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;

  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

UserAddress.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
    },
    contact_person: {
      // DEFAULT ADD USER NAME
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    address: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    landmark: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    address_type: {
      type: DataTypes.STRING(25),
      allowNull: false,
    },
    city_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    state_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    country_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    lat: {
      type: DataTypes.STRING(15),
      allowNull: false,
    },
    lng: {
      type: DataTypes.STRING(15),
      allowNull: false,
    },
    is_default: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'user_address',
    timestamps: true,
    sequelize: sequelize, // this bit is important
  },
);

UserAddress.belongsTo(City, { as: 'city', foreignKey: 'city_id', targetKey: 'id' });
UserAddress.belongsTo(State, { as: 'state', foreignKey: 'state_id', targetKey: 'id' });
UserAddress.belongsTo(Country, { as: 'country', foreignKey: 'country_id', targetKey: 'id' });
