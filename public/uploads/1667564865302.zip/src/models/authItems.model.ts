/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Category model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class AuthItems extends Model {
  public id!: number;
  public name!: string;
  public controller!: string;
  public sub_module!: string;
  public action!: string;
  public description!: string;
  public is_available!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

AuthItems.init(
  {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    controller: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    sub_module: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    action: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    auth_type: {
      type: DataTypes.ENUM('A', 'E'),
      allowNull: false,
    },
    description: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    is_available: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'i_date',
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'u_date',
    },
  },
  {
    tableName: 'auth_item',
    timestamps: true,
    sequelize: sequelize, // this bit is important
  },
);
