/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Language model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class Language extends Model {
  public id!: number;
  public name!: string;
  public language_code!: string;
}
const sequelize = setUpSequelize();

Language.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(20),
      allowNull: false,
    },
    language_code: {
      type: DataTypes.STRING(5),
      allowNull: false,
    },
  },
  {
    tableName: 'language',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);
