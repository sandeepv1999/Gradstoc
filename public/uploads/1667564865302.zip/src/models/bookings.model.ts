/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User model
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { Model, DataTypes, Op, Sequelize } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { BookingAddress } from './bookingAddresses.model';
import { User } from './users.model';
import { BookingCategory } from './bookingCategory.model';
import { Rating } from './rating.model';
import { BookingCancellationReason } from './bookingCancellationReason.model';

export class Booking extends Model {
  public id!: number;
  public booking_no!: string;
  public user_id!: number;
  public musician_id!: number;
  public description!: string;
  public is_fixed!: number;
  public booking_rate!: number;
  public booking_date!: number;
  public event_date!: number;
  public start_time!: string;
  public end_time!: string;
  public hours!: number;
  public total_amount!: number;
  public musician_earning!: number;
  public admin_earning!: number;
  public admin_commission_percentage!: number;
  public status!: number;
  public cancelled_date!: number;
  public cancelled_by!: number;
  public cancellation_reason!: string;
  public cancellation_fee!: number;
  public is_refunded!: number;
  public refund_status!: number;
  public refund_description!: string;
  public refund_date!: number;
  public refund_amount!: number;
  public musician_resp_time?: number;
  public notify_to_admin?: number;
  public timezone!: string;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

Booking.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    musician_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    is_fixed: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    booking_rate: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    booking_date: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    event_date: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    start_time: {
      type: DataTypes.STRING(20),
      allowNull: false,
    },
    end_time: {
      type: DataTypes.STRING(20),
      allowNull: false,
    },
    hours: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    total_amount: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    musician_earning: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    admin_earning: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    admin_commission_percentage: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    status: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    cancelled_date: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    cancelled_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    cancellation_reason: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    cancellation_fee: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    is_refunded: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    refund_status: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    refund_description: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    refund_amount: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    musician_resp_time: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    timezone: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    notify_to_admin: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'bookings',
    timestamps: true,
    sequelize: sequelize, // this bit is important
  },
);

Booking.hasOne(BookingAddress, { as: 'booking_address', foreignKey: 'booking_id', sourceKey: 'id' });
Booking.hasOne(BookingCategory, { as: 'booking_category', foreignKey: 'booking_id', sourceKey: 'id' });
Booking.hasOne(BookingCancellationReason, {
  as: 'booking_cancellation_reson',
  foreignKey: 'booking_id',
  sourceKey: 'id',
});
Booking.hasOne(Rating, { as: 'booking_review', foreignKey: 'booking_id', sourceKey: 'id' });
Booking.belongsTo(User, { as: 'musician', foreignKey: 'musician_id', targetKey: 'id' });
Booking.belongsTo(User, { as: 'customer', foreignKey: 'user_id', targetKey: 'id' });
// Booking.belongsTo(User, { as: 'musician', foreignKey: 'musician_id', targetKey: 'id' });
// Booking.belongsTo(User, { as: 'customer', foreignKey: 'user_id' });
