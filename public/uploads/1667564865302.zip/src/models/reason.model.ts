/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Reason model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class Reason extends Model {
  public id!: number;
  public reason!: string;
  public type!: number;
  public actor!: number;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

Reason.init(
  {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    reason: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    type: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    actor: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '3',
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'cancel_reasons',
    timestamps: true,
    sequelize: sequelize, // this bit is important
  },
);
