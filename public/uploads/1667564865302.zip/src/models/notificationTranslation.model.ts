/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
// import { UserAddress } from './userAddresses.model';
// import config from '../config';
// import bcrypt from 'bcryptjs';
// import { UserDetails } from './userDetails.model';

export class NotificationTranslation extends Model {
  public id!: number;
  public notification_id!: number;
  public language_code!: string;
  public title!: string;
  public message!: string;
}
const sequelize = setUpSequelize();

NotificationTranslation.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    notification_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    language_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    title: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    message: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    tableName: 'notifications_translation',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);
