/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User model
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
// import { UserAddress } from './userAddresses.model';
// import config from '../config';
// import bcrypt from 'bcryptjs';
// import { UserDetails } from './userDetails.model';

export class FAQTranslation extends Model {
  public id!: number;
  public faq_id!: number;
  public language_code!: string;
  public question!: string;
  public answer!: string;
}
const sequelize = setUpSequelize();

FAQTranslation.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    faq_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    language_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    question: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    answer: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    tableName: 'faq_translation',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);

// User.hasOne(UserDetails, { as: 'details', foreignKey: 'user_id', sourceKey: 'id' });
