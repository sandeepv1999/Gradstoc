/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User Address model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin @peerbits.com>
 */
// import { Model, DataTypes } from 'sequelize';
import { Model, DataTypes, Op, Sequelize } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { User } from './users.model';

export class Rating extends Model {
  public id!: number;
  public user_id!: number;
  public musician_id!: number;
  public booking_id!: number;
  public rating!: number;
  public comments!: string;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
  public avg_rating: number;
}
const sequelize = setUpSequelize();

Rating.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    musician_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },

    booking_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    rating: {
      type: DataTypes.NUMBER,
      allowNull: false,
      defaultValue: '1',
    },
    comments: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'rating',
    timestamps: true,
    sequelize: sequelize, // this bit is important
    defaultScope: {
      where: {
        is_deleted: 0,
      },
      attributes: {
        exclude: ['i_by', 'u_by', 'updatedAt'],
      },
    },
  },
);

// Rating.hasMany(User, { as: 'user', foreignKey: 'id', sourceKey: 'user_id' });
