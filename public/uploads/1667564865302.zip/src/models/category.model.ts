/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Category model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { CategoryTranslation } from './categoryTranslation.model';

export class Category extends Model {
  public id!: number;
  public sound_url!: string;
  public icon_url!: string;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
  public translation: CategoryTranslation[];
}
const sequelize = setUpSequelize();

Category.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    sound_url: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    icon_url: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'category_master',
    timestamps: true,
    sequelize: sequelize, // this bit is important
    // scopes: {
    //   portfolio: {
    //     attributes: ['id', 'sound_url', 'icon_url', 'translation[0].name'],
    //   },
    // },
  },
);

Category.hasMany(CategoryTranslation, { as: 'translation', foreignKey: 'category_id', sourceKey: 'id' });
