/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User model
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { Language } from './language.model';
// import { UserAddress } from './userAddresses.model';
// import config from '../config';
// import bcrypt from 'bcryptjs';
// import { UserDetails } from './userDetails.model';

export class CategoryTranslation extends Model {
  public id!: number;
  public category_id!: string;
  public language_code!: string;
  public name!: number;
}
const sequelize = setUpSequelize();

CategoryTranslation.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    category_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    language_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
  },
  {
    tableName: 'category_translation',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);

CategoryTranslation.belongsTo(Language, { as: 'language', foreignKey: 'language_code', targetKey: 'language_code' });

// User.hasOne(UserDetails, { as: 'details', foreignKey: 'user_id', sourceKey: 'id' });
