/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User Address model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin @peerbits.com>
 */
import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { Category } from './category.model';

export class MusicianPortfolio extends Model {
  public id!: number;
  public user_id!: number;
  public category_id!: number;
  public title!: string;
  public video_url!: string;
  public is_approved: number;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
  public category!: Category;
}
const sequelize = setUpSequelize();

MusicianPortfolio.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    category_id: {
      type: DataTypes.NUMBER,
      allowNull: false,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    video_url: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    video_thumb: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    is_approved: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '0',
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'musician_portfolio',
    timestamps: true,
    sequelize: sequelize, // this bit is important
    defaultScope: {
      where: {
        is_deleted: 0,
      },
      attributes: {
        exclude: ['i_by', 'u_by', 'createdAt', 'updatedAt'],
      },
    },
  },
);

MusicianPortfolio.belongsTo(Category, { as: 'category', foreignKey: 'category_id' });
