/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file User Favorites model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin @peerbits.com>
 */
import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class UserFavorites extends Model {
  public id!: number;
  public user_id!: number;
  public musician_id!: number;
  public is_favorite!: number;
  public is_active!: number;
  public is_deleted!: number;
  public i_by!: number;
  public u_by!: number;
  public createdAt!: Date;
  public updatedAt!: Date;
}
const sequelize = setUpSequelize();

UserFavorites.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    musician_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    is_favorite: {
      type: DataTypes.INTEGER,
      defaultValue: '0',
      allowNull: false,
    },
    is_active: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '1',
    },
    is_deleted: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: '0',
    },
    i_by: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    u_by: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    tableName: 'user_favorites',
    timestamps: true,
    sequelize: sequelize, // this bit is important
  },
);
