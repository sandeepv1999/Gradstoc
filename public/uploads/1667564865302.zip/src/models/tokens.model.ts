/**
 * @file Token model
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { Languages } from '../utils/constants';
export class Token extends Model {
  public id!: number;
  public user_id!: number;
  public device_id!: string;
  public device_type!: string;
  public access_token!: string;
  public is_notification!: number;
  public last_login!: Date;
  public user_language!: string;
}
const sequelizeInstance = setUpSequelize();
Token.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id',
      },
    },
    device_id: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    access_token: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    device_type: {
      type: DataTypes.STRING(1),
      allowNull: true,
    },
    is_notification: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: '1',
    },
    last_login: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    user_language: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: Languages.ENGLISH,
    },
  },
  {
    tableName: 'tokens',
    timestamps: false,
    sequelize: sequelizeInstance,
  },
);

// import { UserMaster } from './userMaster.model';

// Token.belongsTo(UserMaster, { as: 'user', foreignKey: 'user_id' });
