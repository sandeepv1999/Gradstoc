/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file booking Cancellation Reason model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';

export class BookingCancellationReason extends Model {
  public id!: number;
  public booking_id!: number;
  public reason!: string;
  public language_code!: string;
}
const sequelize = setUpSequelize();

BookingCancellationReason.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    booking_id: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    reason: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    language_code: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    tableName: 'booking_cancellation_reason',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);
