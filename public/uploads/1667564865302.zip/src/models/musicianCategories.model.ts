/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file Category model
 * @copyright Peerbits
 * @author Faizanuddin Morkas <faizanuddin@peerbits.com>
 */

import { Model, DataTypes } from 'sequelize';
import { setUpSequelize } from '../db/sql/connection';
import { CategoryTranslation } from './categoryTranslation.model';
import { Category } from './category.model';

export class MusicianCategories extends Model {
  public id!: number;
  public musician_id!: string;
  public category_id!: string;
  public category!: CategoryTranslation;
}
const sequelize = setUpSequelize();

MusicianCategories.init(
  {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    musician_id: {
      type: DataTypes.STRING(20),
      allowNull: false,
    },
    category_id: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
  },
  {
    tableName: 'musician_categories',
    timestamps: false,
    sequelize: sequelize, // this bit is important
  },
);

// MusicianCategories.hasOne(CategoryTranslation, { as: 'category', foreignKey: 'category_id', sourceKey: 'category_id' });
// MusicianCategories.hasMany(CategoryTranslation, {
//   as: 'categories',
//   foreignKey: 'category_id',
//   sourceKey: 'category_id',
// });

MusicianCategories.belongsTo(Category, { as: 'category', foreignKey: 'category_id', targetKey: 'id' });
MusicianCategories.hasMany(Category, {
  as: 'categories',
  foreignKey: 'id',
  sourceKey: 'category_id',
});
