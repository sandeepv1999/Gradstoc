import * as _ from 'lodash';
import { Reason } from '../models/reason.model';

export const createReason = async (data: object): Promise<Reason> => {
  console.log('*********** inside create ***********');
  try {
    const cancellationReason = new Reason(data);
    await cancellationReason.save();
    return cancellationReason;
  } catch (error) {
    throw new Error(error);
  }
};

export const updateReasonByField = async (_field: string, _value: string | number, data: object): Promise<Reason> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await Reason.update(data, query);
    return await Reason.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};
