import * as _ from 'lodash';
import { Booking } from '../models/bookings.model';
import { BookingCategory } from '../models/bookingCategory.model';
import { BookingAddress } from '../models/bookingAddresses.model';
import { BookingCancellationReason } from '../models/bookingCancellationReason.model';

export const createBooking = async (data: object): Promise<Booking> => {
  console.log('*********** inside create booking ***********');
  try {
    const _booking = new Booking(data);
    await _booking.save();
    return _booking;
  } catch (error) {
    throw new Error(error);
  }
};

export const createBookingAddress = async (data: object): Promise<BookingAddress> => {
  console.log('*********** inside create booking ***********');
  try {
    const _bookingAddress = new BookingAddress(data);
    await _bookingAddress.save();
    return _bookingAddress;
  } catch (error) {
    throw new Error(error);
  }
};

export const createBookingCategories = async (data: object[]): Promise<BookingCategory[]> => {
  console.log('*********** inside create booking ***********');
  try {
    const _bookingCategories = await BookingCategory.bulkCreate(data);
    return _bookingCategories;
  } catch (error) {
    throw new Error(error);
  }
};

export const updateBookingByField = async (_field: string, _value: string | number, data: object): Promise<Booking> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await Booking.update(data, query);
    return await Booking.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};
