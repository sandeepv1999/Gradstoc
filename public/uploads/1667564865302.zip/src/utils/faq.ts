import { FAQ } from '../models/faq.model';
import { FAQTranslation } from '../models/faqTranslation.model';
import * as _ from 'lodash';

export const createFaq = async (data: object): Promise<FAQ> => {
  console.log('*********** inside create ***********');
  try {
    const faq = new FAQ(data);
    await faq.save();
    return faq;
  } catch (error) {
    throw new Error(error);
  }
};

export const createFaqTranslation = async (data: object[]): Promise<FAQTranslation[]> => {
  console.log('*********** inside create translation***********');
  try {
    const translation = await FAQTranslation.bulkCreate(data);
    return translation;
  } catch (error) {
    throw new Error(error);
  }
};

export const updateFAQByField = async (_field: string, _value: string | number, data: object): Promise<FAQ> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await FAQ.update(data, query);
    return await FAQ.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};

export const updateCategoryTranslationByField = async (
  _field: string,
  _value: string | number,
  data: object,
): Promise<FAQTranslation> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }
  if (_field === 'faq_id') {
    _.set(whereCondition, 'faq_id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await FAQTranslation.update(data, query);
    return await FAQTranslation.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};
