import * as Excel from 'exceljs';
/* eslint-disable @typescript-eslint/no-explicit-any */
import * as _ from 'lodash';
import * as authService from '../utils/auth';
import * as pushService from '../services/notification.service';

import { Actors, BookingStatus, BookingType, LanguageCodes, PushNotificaitonTypes } from './constants';
import { Op, QueryTypes, Sequelize } from 'sequelize';

import { Booking } from '../models/bookings.model';
import { BookingCategory } from '../models/bookingCategory.model';
import { Category } from '../models/category.model';
import { CategoryTranslation } from '../models/categoryTranslation.model';
import { City } from '../models/city.model';
import { Country } from '../models/country.model';
import { MusicianCategories } from '../models/musicianCategories.model';
import { MusicianPortfolio } from '../models/musicianPortfolio.model';
import { Rating } from '../models/rating.model';
import { RecentView } from '../models/recentView.model';
import { State } from '../models/state.model';
import { User } from '../models/users.model';
import { UserAddress } from '../models/userAddresses.model';
import { UserBankDetails } from '../models/userBankDetails.model';
import { UserDetails } from '../models/userDetails.model';
import { UserFavorites } from '../models/userFavorite.model';
import config from '../config';
import { map } from 'p-iteration';
import moment from 'moment';
import { setUpSequelize } from '../db/sql/connection';
import e = require('express');

const connection: Sequelize = setUpSequelize();
const generateOTP = () => {
  return Math.floor(1000 + Math.random() * 9000);
  // return 1234;
};

const createUser = async (data: object): Promise<User> => {
  console.log('*********** inside create ***********');
  try {
    const user = new User(data);
    await user.save();
    return user;
  } catch (error) {
    throw new Error(error);
  }
};

const createUserDetails = async (data: object): Promise<UserDetails> => {
  try {
    console.log('*********** inside userDetails ***********');
    const userDetails = new UserDetails(data);
    await userDetails.save();
    return userDetails;
  } catch (error) {
    throw new Error(error);
  }
};

const getUserByField = async (_field: string, _value: string | number, _include: string[] = []): Promise<User> => {
  const whereCondition = {};
  const include = [];

  _include.forEach(elem => {
    switch (elem) {
      case 'address':
        include.push({
          model: UserAddress,
          as: 'address',
          required: false,
          include: [
            {
              model: City,
              as: 'city',
            },
            {
              model: State,
              as: 'state',
            },
            {
              model: Country,
              as: 'country',
            },
          ],
          attributes: [
            'id',
            'user_id',
            'contact_person',
            'address',
            'landmark',
            'address_type',
            'city_id',
            'state_id',
            'country_id',
            'lat',
            'lng',
            'is_default',
            [Sequelize.fn('', Sequelize.col('``address->city`.`name``')), 'city_name'],
            [Sequelize.fn('', Sequelize.col('`address->state`.`name`')), 'state_name'],
            [Sequelize.fn('', Sequelize.col('`address->country`.`name`')), 'country_name'],
          ],
        });
        break;
      case 'bankdetails':
        include.push({ model: UserBankDetails, as: 'banks', required: false });
        break;
      case 'userdetails':
        include.push({
          model: UserDetails,
          as: 'details',
          required: false,
        });
        break;
      case 'musician_categories':
        include.push({
          model: MusicianCategories,
          as: 'musician_categories',
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: LanguageCodes.ENGLISH },
                  as: 'translation',
                },
              ],
            },
          ],
          // include: [
          //   {
          //     model: CategoryTranslation,
          //     where: { language_code: 'en' },
          //     as: 'category',
          //     required: false,
          //   },
          // ],
          required: false,
        });
        break;

      default:
        break;
    }
  });

  if (_field === 'email') {
    _.set(whereCondition, 'email', _value);
  }

  if (_field === 'phone_number') {
    _.set(whereCondition, 'phone_number', _value);
  }

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }

  if (_field === 'actor') {
    _.set(whereCondition, 'actor', _value);
  }

  if (_field === 'forgot_password_token') {
    _.set(whereCondition, 'forgot_password_token', _value);
  }

  const query = {
    include,
    where: whereCondition,
  };
  try {
    const user = await User.findOne(query);
    return user;
  } catch (error) {
    console.log(error);
    throw new Error(error);
  }
};

const updateUserByField = async (_field: string, _value: string | number, data: object): Promise<User> => {
  const whereCondition = {};

  if (_field === 'email') {
    _.set(whereCondition, 'email', _value);
  }
  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }
  if (_field === 'phone_number') {
    _.set(whereCondition, 'phone_number', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await User.update(data, query);
    return await User.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};

const generateEmailToken = async () => {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
};

const createAddress = async (data: object): Promise<UserAddress> => {
  try {
    const userAddress = new UserAddress(data);
    await userAddress.save();
    return userAddress;
  } catch (error) {
    throw new Error(error);
  }
};

const updateUserDetailsByField = async (
  _field: string,
  _value: string | number,
  data: object,
): Promise<UserDetails> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }
  if (_field === 'user_id') {
    _.set(whereCondition, 'user_id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await UserDetails.update(data, query);
    return await UserDetails.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};

const getAllPortfolioByMusician = async (userId: string | number): Promise<any> => {
  try {
    const portfolios = await MusicianPortfolio.findAndCountAll({
      where: { user_id: userId },
      include: [
        {
          model: Category,
          include: [
            {
              model: CategoryTranslation,
              where: { language_code: 'en' },
              as: 'translation',
            },
          ],
          attributes: ['id', 'sound_url', 'icon_url'],
          as: 'category',
        },
      ],
    });
    const _portfolios = { count: portfolios.count, rows: [] };
    portfolios.rows.forEach(element => {
      const _element: any = element.toJSON();
      _element.category_id = element.category.id;
      _element.categort_name = element.category.translation[0].name;
      _element.categort_image = element.category.icon_url;
      _element.categort_sound = element.category.sound_url;
      delete _element['category'];
      _portfolios.rows.push(_element);
    });
    return _portfolios;
  } catch (error) {
    throw new Error(error);
  }
};

const createMusicianCategories = async (data: object[]): Promise<MusicianCategories[]> => {
  try {
    // const musicianCategories = new MusicianCategories(data);
    const musicianCategories = await MusicianCategories.bulkCreate(data);
    return musicianCategories;
  } catch (error) {
    throw new Error(error);
  }
};

const getMusicianCategories = async (musician_id, language): Promise<MusicianCategories[]> => {
  try {
    let musicianCategories = await MusicianCategories.findAll({
      include: [
        {
          model: Category,
          as: 'category',
          where: { is_deleted: 0, is_active: 1 },
          include: [
            {
              model: CategoryTranslation,
              where: { language_code: language },
              as: 'translation',
            },
          ],
        },
      ],
      // as: 'musician_categories',
      // required: false,
      attributes: [
        [Sequelize.fn('', Sequelize.col('`category.id`')), 'category_id'],
        [Sequelize.fn('', Sequelize.col('`category.translation.name`')), 'category_name'],
      ],
      where: { musician_id: musician_id },
      order: [['id', 'DESC']],
    });
    // console.log('before',musicianCategories)
    // await musicianCategories.forEach(element => {
    musicianCategories = await map(musicianCategories, async elem => {
      const elemJson: any = elem.toJSON();
      return elemJson;
    });
    // console.log('after',musicianCategories)
    return musicianCategories;
  } catch (error) {
    throw new Error(error);
  }
};

const updateMusicianCategories = async (musician_id, data: object[]): Promise<MusicianCategories[]> => {
  try {
    // const musicianCategories = new MusicianCategories(data);
    await MusicianCategories.destroy({ where: { musician_id } });
    const musicianCategories = await MusicianCategories.bulkCreate(data);
    return musicianCategories;
  } catch (error) {
    throw new Error(error);
  }
};

const exportUsers = async res => {
  console.log('*************Export***************');
  const workbook = new Excel.Workbook();
  const worksheet = workbook.addWorksheet('Report');
  const data = [];
  const users = await User.findAll({
    include: [
      {
        model: UserAddress,
        where: { is_default: 1 },
        as: 'addresses',
        required: false,
      },
    ],
    where: { is_deleted: 0, actor: 3 },
    order: [['id', 'DESC']],
  });

  users.forEach(element => {
    const _data: any = {
      en_full_name: element.en_full_name,
      email: element.email,
      phone_number: element.phone_number,
      city: element.addresses && element.addresses.length > 0 ? element.addresses[0].city_id : '',
      state: element.addresses && element.addresses.length > 0 ? element.addresses[0].state_id : '',
    };
    data.push(_data);
  });

  worksheet.columns = [
    {
      header: 'Full Name',
      key: 'en_full_name',
      width: 30,
    },
    {
      header: 'Email Address',
      key: 'email',
      width: 30,
    },
    { header: 'Mobile Number', key: 'phone_number', width: 25 },
    {
      header: 'City',
      key: 'city',
      width: 20,
    },
    { header: 'State', key: 'state', width: 20 },
  ];

  const firstRow = worksheet.getRow(1);
  firstRow.font = { size: 12, bold: true };
  firstRow.alignment = { vertical: 'middle', horizontal: 'center' };

  worksheet.addRows(data);

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  await workbook.xlsx.write(res);
  res.end();
};

const exportMusician = async res => {
  console.log('*************Export***************');
  const workbook = new Excel.Workbook();
  const worksheet = workbook.addWorksheet('Report');
  const data = [];
  const musicians = await User.findAll({
    where: { is_deleted: 0, actor: 4 },
    include: [
      { model: UserAddress, as: 'addresses', where: { is_active: 1, is_deleted: 0, is_default: 1 }, required: false },
      {
        model: UserDetails,
        as: 'details',
        required: false,
      },
      {
        model: MusicianCategories,
        as: 'musician_categories',
        include: [
          {
            model: Category,
            as: 'category',
            where: { is_deleted: 0, is_active: 1 },
            include: [
              {
                model: CategoryTranslation,
                where: { language_code: LanguageCodes.ENGLISH },
                as: 'translation',
              },
            ],
          },
        ],
        // include: [
        //   {
        //     model: CategoryTranslation,
        //     where: { language_code: 'en' },
        //     as: 'category',
        //     required: false,
        //   },
        // ],
        required: false,
      },
    ],
    order: [['id', 'DESC']],
  });

  musicians.forEach(element => {
    const _data: any = {
      en_full_name: element.en_full_name,
      email: element.email,
      phone_number: element.phone_number,
      city: element.addresses && element.addresses.length > 0 ? element.addresses[0].city_id : '',
      state: element.addresses && element.addresses.length > 0 ? element.addresses[0].state_id : '',
      categories:
        element.musician_categories && element.musician_categories.length > 0
          ? element.musician_categories
              .map((x: any) => {
                return x.category.translation[0].name;
              })
              .toString()
          : '',
    };
    data.push(_data);
  });

  worksheet.columns = [
    {
      header: 'Full Name',
      key: 'en_full_name',
      width: 30,
    },
    {
      header: 'Email Address',
      key: 'email',
      width: 30,
    },
    { header: 'Mobile Number', key: 'phone_number', width: 25 },
    {
      header: 'City',
      key: 'city',
      width: 20,
    },
    { header: 'State', key: 'state', width: 20 },
    { header: 'Categories', key: 'categories', width: 20, alignment: { wrapText: true } },
  ];

  const firstRow = worksheet.getRow(1);
  firstRow.font = { size: 12, bold: true };
  firstRow.alignment = { vertical: 'middle', horizontal: 'center' };

  worksheet.addRows(data);

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  await workbook.xlsx.write(res);
  res.end();
};

const createUserBank = async (data: object): Promise<UserBankDetails> => {
  try {
    const userBank = new UserBankDetails(data);
    await userBank.save();
    return userBank;
  } catch (error) {
    throw new Error(error);
  }
};

const updateUserAddress = async (_field: string, _value: string | number, data: object): Promise<UserAddress> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }
  if (_field === 'user_id') {
    _.set(whereCondition, 'user_id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await UserAddress.update(data, query);
    return await UserAddress.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};

const updateUserBank = async (_field: string, _value: string | number, data: object): Promise<UserBankDetails> => {
  const whereCondition = {};

  _.set(whereCondition, 'is_deleted', 0);
  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }
  if (_field === 'user_id') {
    _.set(whereCondition, 'user_id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    const bankData = await UserBankDetails.findOne(query);
    if (bankData) {
      await UserBankDetails.update(data, query);
    } else {
      const newData = {
        user_id: _value,
        full_name: data['full_name'],
        bank_account_no: data['bank_account_no'],
        code: data['code'],
        iban: data['iban'],
        is_default: 1,
        i_by: data['u_by'],
        u_by: data['u_by'],
      };
      const userBank = new UserBankDetails(newData);
      await userBank.save();
    }
    return await UserBankDetails.findOne(query);
  } catch (error) {
    console.log(error);
    throw new Error(error);
  }
};

const reOrder = async function(data) {
  const result = data.reduce(function(r, a) {
    r[a.name] = r[a.name] || [];
    r[a.name].push(a);
    return r;
  }, Object.create(null));

  return result;
};

const createMusicianPortfolio = async (data: object): Promise<MusicianPortfolio> => {
  try {
    // const musicianCategories = new MusicianCategories(data);
    const musicianPortfolio = await MusicianPortfolio.create(data);
    return musicianPortfolio;
  } catch (error) {
    throw new Error(error);
  }
};

const getMusicianPortfolio = async (_field: string, _value: string | number): Promise<MusicianPortfolio> => {
  try {
    const whereCondition = { is_deleted: 0, is_active: 1 };

    if (_field === 'id') {
      _.set(whereCondition, 'id', _value);
    }
    if (_field === 'user_id') {
      _.set(whereCondition, 'user_id', _value);
    }

    const query = {
      where: whereCondition,
    };
    return await MusicianPortfolio.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};

const updateMusicianPortfolio = async (
  _field: string,
  _value: string | number,
  data: object,
): Promise<MusicianPortfolio> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }
  if (_field === 'user_id') {
    _.set(whereCondition, 'user_id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await MusicianPortfolio.update(data, query);
    return await MusicianPortfolio.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};

const musicianResponse = async function(id, language) {
  try {
    const musician = await User.findOne({
      where: { id },
      include: [
        {
          model: UserAddress,
          include: [
            {
              model: City,
              as: 'city',
            },
            {
              model: State,
              as: 'state',
            },
            {
              model: Country,
              as: 'country',
            },
          ],
          as: 'address',
          required: false,
          where: { is_deleted: 0, is_active: 1 },
          attributes: [
            'id',
            'user_id',
            'contact_person',
            'address',
            'landmark',
            'address_type',
            'city_id',
            'state_id',
            'country_id',
            'lat',
            'lng',
            'is_default',
            [Sequelize.fn('', Sequelize.col('`address.city.name')), 'city_name'],
            [Sequelize.fn('', Sequelize.col('`address.state.name')), 'state_name'],
            [Sequelize.fn('', Sequelize.col('`address.country.name')), 'country_name'],
          ],
          // attributes: { exclude: ['is_deleted', 'is_active', 'i_by', 'createdAt', 'u_by', 'updatedAt'],  },
        },
        {
          model: UserBankDetails,
          as: 'bank',
          required: false,
          where: { is_deleted: 0, is_active: 1 },
        },
        {
          model: UserDetails,
          as: 'details',
          where: { is_deleted: 0, is_active: 1 },
        },
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                },
              ],
            },
          ],
          // include: [
          //   {
          //     model: Category,
          //     as: 'category',
          //     where: { is_deleted: 0, is_active: 1 },
          //     include: [
          //       {
          //         model: CategoryTranslation,
          //         where: { language_code: language },
          //         as: 'translation',
          //       },
          //     ],
          //   },
          // ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
        {
          model: MusicianPortfolio,
          as: 'portfolios',
          where: { is_deleted: 0, is_active: 1 },
          required: false,
        },
      ],
      attributes: [
        'id',
        [Sequelize.fn('', Sequelize.col('en_full_name')), 'name'],
        'email',
        'image',
        [Sequelize.fn('', Sequelize.col('dial_code')), 'country_code'],
        [Sequelize.fn('', Sequelize.col('phone_number')), 'mobile_number'],
        'is_email_verified',
        'is_profile_completed',
        'is_music_detail_completed',
        'is_address_completed',
        'is_portfolio_completed',
        'is_notification',
        'password',
        'is_suspended',
        'is_active',
        [Sequelize.fn('', Sequelize.col('details.about_me')), 'about_me'],
        [Sequelize.fn('', Sequelize.col('details.can_set_price')), 'is_rate_editable'],
        [Sequelize.fn('', Sequelize.col('details.hourly_rate')), 'hourly_rate'],
        [Sequelize.fn('', Sequelize.col('details.fix_rate')), 'full_day_rate'],
      ],
    });

    const musicianResp: any = musician.toJSON();
    if (musicianResp.is_suspended == 1) {
      _.set(musicianResp, 'status', 3);
    } else {
      _.set(musicianResp, 'status', 2);
      if (musicianResp.is_active == 1) {
        _.set(musicianResp, 'status', 1);
      }
    }
    if (!musicianResp.address) {
      _.set(musicianResp, 'address', {});
    }
    if (!musicianResp.bank) {
      _.set(musicianResp, 'bank', {});
    }

    if (musicianResp.details) {
      _.set(
        musicianResp.details,
        'cancellation_percentage',
        parseFloat(musicianResp.details.cancellation_percentage).toFixed(2),
      );
    }
    if (musicianResp.musician_categories) {
      musicianResp.musician_categories.map(elem => {
        delete elem['category'];
      });
    }

    if (musicianResp.address) {
      delete musicianResp.address['city'];
      delete musicianResp.address['state'];
      delete musicianResp.address['country'];
    }

    await Object.keys(musicianResp).forEach(key => {
      if (musicianResp[key] == undefined && musicianResp[key] == null) {
        musicianResp[key] = '';
      }
      if (typeof musicianResp[key] === 'object') {
        Object.keys(musicianResp[key]).forEach(k => {
          if (musicianResp[key][k] == undefined && musicianResp[key][k] == null) {
            musicianResp[key][k] = '';
          }
        });
      }
    });

    return musicianResp;
  } catch (error) {
    throw new Error(error);
  }
};

const getMusicianResponse = async function(id, language, orderByFlag = 1) {
  try {
    let orderBy = 'id';
    if (orderByFlag == 2) orderBy = 'rating';
    if (id == null) return null;
    const musician = await User.findOne({
      where: { id },
      include: [
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                  required: false,
                },
              ],
              required: false,
            },
          ],
          // include: [
          //   {
          //     model: Category,
          //     as: 'category',
          //     where: { is_deleted: 0, is_active: 1 },
          //     include: [
          //       {
          //         model: CategoryTranslation,
          //         where: { language_code: language },
          //         as: 'translation',
          //       },
          //     ],
          //   },
          // ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
        {
          model: Rating,
          as: 'ratings',
          where: { is_deleted: 0, is_active: 1 },
          required: false,
          attributes: [
            'id',
            'user_id',
            'rating',
            ['comments', 'review'],
            ['createdAt', 'date'],
            [
              Sequelize.literal('(SELECT en_full_name FROM users WHERE id = ratings.user_id AND is_deleted = 0)'),
              'name',
            ],
            [Sequelize.literal('(SELECT image FROM users WHERE id = ratings.user_id AND is_deleted = 0)'), 'image'],
          ],
        },
      ],
      attributes: [
        'id',
        [Sequelize.fn('', Sequelize.col('en_full_name')), 'name'],
        'email',
        'image',
        [
          Sequelize.literal('(SELECT AVG(`rating`) FROM rating WHERE musician_id = User.id AND is_deleted = 0)'),
          'avg_rating',
        ],
        [
          Sequelize.literal('(SELECT COUNT(`id`) FROM rating WHERE musician_id = User.id AND is_deleted = 0)'),
          'total_rating',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = User.id AND rating = 5 AND is_deleted = 0)`,
          ),
          'very_good',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = User.id AND rating = 4 AND is_deleted = 0)`,
          ),
          'good',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = User.id AND rating = 3 AND is_deleted = 0)`,
          ),
          'average',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = User.id AND rating = 2 AND is_deleted = 0)`,
          ),
          'bad',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = User.id AND rating = 1 AND is_deleted = 0)`,
          ),
          'very_bad',
        ],
      ],
      order: [[{ model: Rating, as: 'ratings' }, orderBy, 'DESC']],
      logging: true,
    });

    let musicianResp: any = {};
    if (musician) {
      musicianResp = musician.toJSON();
    } else {
      return null;
    }
    // if (!musicianResp.address) {
    //   _.set(musicianResp, 'address', {});
    // }
    // if (!musicianResp.bank) {
    //   _.set(musicianResp, 'bank', {});
    // }

    if (musicianResp.musician_categories) {
      musicianResp.musician_categories.map(elem => {
        delete elem['category'];
      });
    }
    if (musicianResp.ratings) {
      musicianResp.ratings.map(elem => {
        elem.date = moment(elem.date).unix();
      });
    }

    // if (musicianResp.address) {
    //   delete musicianResp.address['city'];
    //   delete musicianResp.address['state'];
    //   delete musicianResp.address['country'];
    // }

    await Object.keys(musicianResp).forEach(key => {
      if (musicianResp[key] == undefined && musicianResp[key] == null) {
        musicianResp[key] = '';
      }
      if (typeof musicianResp[key] === 'object') {
        Object.keys(musicianResp[key]).forEach(k => {
          if (musicianResp[key][k] == undefined && musicianResp[key][k] == null) {
            musicianResp[key][k] = '';
          }
        });
      }
    });

    return musicianResp;
  } catch (error) {
    throw new Error(error);
  }
};

const musicianFavorite = async function(musician_id, user_id) {
  try {
    const hasFavorite = await UserFavorites.findOne({ where: { musician_id, user_id, is_deleted: 0 } });
    let message = 'musician_favorite_add_success';
    let favorite = 1;
    if (hasFavorite) {
      if (hasFavorite.is_favorite == 1) {
        favorite = 0;
        message = 'musician_favorite_remove_success';
      }
      await UserFavorites.update({ is_favorite: favorite }, { where: { id: hasFavorite.id } });
    } else {
      await UserFavorites.create({ user_id, musician_id, is_favorite: favorite, i_by: user_id });
    }
    return message;
  } catch (error) {
    throw new Error(error);
  }
};
const recentViewByUser = async function(musician_id, user_id) {
  try {
    const hasFavorite = await RecentView.findOne({
      where: { musician_id: musician_id, user_id: user_id, is_deleted: 0 },
    });

    if (hasFavorite) {
      const view_count = hasFavorite.view + 1;
      await RecentView.update({ view: view_count }, { where: { id: hasFavorite.id, u_by: user_id } });
    } else {
      await RecentView.create({ user_id, musician_id, view: 1, i_by: user_id, u_by: user_id });
    }
    return true;
  } catch (error) {
    throw new Error(error);
  }
};

const getfavoriteMusicianByUser = async function(user_id) {
  try {
    const hasFavorite = await UserFavorites.findAll({
      attributes: ['musician_id'],
      where: { is_favorite: 1, user_id: user_id, is_deleted: 0 },
      order: [['id', 'DESC']],
    });

    return hasFavorite;
  } catch (error) {
    throw new Error(error);
  }
};

const getrecentViewMusicianByUser = async function(user_id) {
  try {
    const hasFavorite = await RecentView.findAll({
      attributes: ['musician_id'],
      where: { user_id: user_id, is_deleted: 0 },
      order: [['view', 'DESC']],
    });

    return hasFavorite;
  } catch (error) {
    throw new Error(error);
  }
};
const exportBooking = async (res, isInclude = 1) => {
  console.log('*************Export***************');
  console.log('isInclude===>', isInclude);
  const workbook = new Excel.Workbook();
  const worksheet = workbook.addWorksheet('Report');
  const data = [];
  const bookings = await Booking.findAll({
    where: { is_deleted: 0 },
    include: [
      {
        model: User,
        as: 'musician',
        attributes: ['id', 'en_full_name', 'image'],
      },
      {
        model: User,
        as: 'customer',
        attributes: ['id', 'en_full_name', 'image'],
      },
      {
        model: BookingCategory,
        as: 'booking_category',
        where: {
          language_code: 'en',
        },
        attributes: ['id', 'name'],
      },
    ],
    order: [['id', 'DESC']],
    attributes: [
      'id',
      ['booking_date', 'booking_date'],
      ['event_date', 'event_date'],
      'start_time',
      'end_time',
      'hours',
      'status',
      'admin_earning',
      ['is_fixed', 'booked_type'],
      ['total_amount', 'total_amount'],
      [Sequelize.fn('', Sequelize.col('`musician`.`en_full_name`')), 'musician_name'],
      [Sequelize.fn('', Sequelize.col('`booking_category`.`name`')), 'category_name'],
      [Sequelize.fn('', Sequelize.col('`customer`.`en_full_name`')), 'customer_name'],
    ],
    // logging: true,
  });
  // console.log(bookings);
  bookings.forEach(element => {
    const elemJson: any = element.toJSON();
    const bookingDate = new Date(elemJson.booking_date * 1000);
    bookingDate.setMonth(bookingDate.getMonth() + 1);
    const finalBookingDate = bookingDate.getDate() + '-' + bookingDate.getMonth() + '-' + bookingDate.getFullYear();

    const eventDate = new Date(elemJson.event_date * 1000);
    eventDate.setMonth(eventDate.getMonth() + 1);
    const amOrPm = eventDate.getHours() < 12 ? 'AM' : 'PM';
    const hour = eventDate.getHours() < 12 ? eventDate.getHours() : eventDate.getHours() - 12;

    const finalEventDate =
      eventDate.getDate() +
      '-' +
      eventDate.getMonth() +
      '-' +
      eventDate.getFullYear() +
      ' ' +
      hour +
      ':' +
      eventDate.getMinutes() +
      ':' +
      eventDate.getSeconds() +
      ' ' +
      amOrPm;

    const _data: any = {
      id: elemJson.id,
      bookingDate: elemJson.booking_date ? finalBookingDate : '-',
      eventDate: elemJson.event_date ? finalEventDate : '-',
      customerName: elemJson.customer_name,
      category: elemJson.category_name,
      package: elemJson.booked_type == 1 ? 'Hourly' : 'Fixed',
      amount: 'SR ' + elemJson.total_amount.toFixed(2),
    };
    if (isInclude == 2) {
      _data.admin_earning = 'SR ' + element.admin_earning.toFixed(2);
    }
    data.push(_data);
  });

  worksheet.columns = [
    {
      header: 'Bookin ID',
      key: 'id',
      width: 10,
    },
    {
      header: 'Booking Date',
      key: 'bookingDate',
      width: 15,
    },
    {
      header: 'Event Date & Time',
      key: 'eventDate',
      width: 25,
    },
    {
      header: 'Customer Name',
      key: 'customerName',
      width: 20,
    },
    { header: 'Categories', key: 'category', width: 20 },
    { header: 'Package', key: 'package', width: 10 },
    { header: 'Total Booking Price', key: 'amount', width: 20 },
  ];
  if (isInclude == 2) {
    worksheet.columns = [
      {
        header: 'Bookin ID',
        key: 'id',
        width: 10,
      },
      {
        header: 'Booking Date',
        key: 'bookingDate',
        width: 15,
      },
      {
        header: 'Event Date & Time',
        key: 'eventDate',
        width: 25,
      },
      {
        header: 'Customer Name',
        key: 'customerName',
        width: 20,
      },
      { header: 'Categories', key: 'category', width: 20 },
      { header: 'Package', key: 'package', width: 10 },
      { header: 'Total Booking Price', key: 'amount', width: 20 },
      { header: 'Net Earning (Admin)', key: 'amount', width: 20 },
    ];
  }

  const firstRow = worksheet.getRow(1);
  firstRow.font = { size: 12, bold: true };
  firstRow.alignment = { vertical: 'middle', horizontal: 'center' };

  worksheet.addRows(data);

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  await workbook.xlsx.write(res);
  res.end();
};

const getMusicianAvaibility = async function(musician_id, start_date) {
  try {
    let result = 1;
    const fromDate = moment(start_date * 1000)
      .utc()
      .startOf('day')
      .unix();

    const toDate = moment(start_date * 1000)
      .utc()
      .endOf('day')
      .unix();

    const bookingData = await Booking.findOne({
      where: {
        is_deleted: 0,
        musician_id: musician_id,
        status: [1, 2],
        event_date: {
          [Op.gte]: fromDate,
          [Op.lte]: toDate,
        },
      },
      // logging: true,
    });
    if (bookingData) {
      result = 0;
    }

    return result;
  } catch (error) {
    throw new Error(error);
  }
};

const getMusicianAvaibilityByTime = async function(musician_id, start_time) {
  try {
    let result = 1;

    const bookingData = await Booking.findOne({
      where: {
        is_deleted: 0,
        musician_id: musician_id,
        status: { [Op.in]: [BookingStatus.Completed, BookingStatus.Confirmed] },
      },
      order: [['id', 'DESC']],
    });
    console.log('*********booking************');
    console.log(bookingData);
    if (bookingData) {
      const requestedEventTime = moment(start_time * 1000);
      const bookingEndTime = moment(Number(bookingData.end_time) * 1000);
      const bookingStartTime = moment(Number(bookingData.start_time) * 1000);
      // const diff = bookingEndTime.diff(requestedEventTime, 'h');
      const diff = requestedEventTime.diff(bookingEndTime, 'h');
      // const diffWithStartDate = requestedEventTime.diff(bookingStartTime, 'h');
      const diffWithStartDate = bookingStartTime.diff(requestedEventTime, 'h');
      console.log('****************');
      console.log('End Time of last booking', bookingData.end_time);
      console.log('Requested Start Time', start_time);
      console.log('Difference', diff);
      console.log('Start Date Difference', diffWithStartDate);
      console.log('****************');

      if (requestedEventTime <= bookingStartTime) {
        if (
          (bookingData.is_fixed == BookingType.Hourly && diffWithStartDate >= 1) ||
          (bookingData.is_fixed == BookingType.FixedDay && diffWithStartDate >= 2)
        ) {
          result = 1;
        } else {
          result = 0;
        }
      } else {
        if (
          (bookingData.is_fixed == BookingType.Hourly && diff >= 1) ||
          (bookingData.is_fixed == BookingType.FixedDay && diff >= 2)
        ) {
          result = 1;
        } else {
          result = 0;
        }
      }
    }
    return result;
  } catch (error) {
    throw new Error(error);
  }
};

const getMusicianAllCategory = async function(id, language) {
  try {
    const musician = await User.findOne({
      where: { id },
      include: [
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                },
              ],
            },
          ],
          // include: [
          //   {
          //     model: Category,
          //     as: 'category',
          //     where: { is_deleted: 0, is_active: 1 },
          //     include: [
          //       {
          //         model: CategoryTranslation,
          //         where: { language_code: language },
          //         as: 'translation',
          //       },
          //     ],
          //   },
          // ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
      ],
      logging: true,
    });

    const musicianResp: any = musician.toJSON();
    // if (!musicianResp.address) {
    //   _.set(musicianResp, 'address', {});
    // }
    // if (!musicianResp.bank) {
    //   _.set(musicianResp, 'bank', {});
    // }

    if (musicianResp.musician_categories) {
      musicianResp.musician_categories.map(elem => {
        // delete elem['category'];
      });
    }

    // if (musicianResp.address) {
    //   delete musicianResp.address['city'];
    //   delete musicianResp.address['state'];
    //   delete musicianResp.address['country'];
    // }

    await Object.keys(musicianResp).forEach(key => {
      if (musicianResp[key] == undefined && musicianResp[key] == null) {
        musicianResp[key] = '';
      }
      if (typeof musicianResp[key] === 'object') {
        Object.keys(musicianResp[key]).forEach(k => {
          if (musicianResp[key][k] == undefined && musicianResp[key][k] == null) {
            musicianResp[key][k] = '';
          }
        });
      }
    });

    return musicianResp.musician_categories;
  } catch (error) {
    throw new Error(error);
  }
};

const checkMusicianFavourite = async (user_id, musician_id) => {
  try {
    const hasFavorite = await UserFavorites.findOne({
      where: { is_favorite: 1, user_id, musician_id },
    });

    return hasFavorite;
  } catch (error) {
    throw new Error(error);
  }
};

const checkCurrentBookingByUserId = async (user_id, musician_id) => {
  try {
    const currentBooking = await Booking.findOne({
      where: {
        is_deleted: 0,
        is_active: 1,
        user_id,
        musician_id,
        status: { [Op.in]: [BookingStatus.Pending, BookingStatus.Confirmed] },
      },
    });
    return currentBooking;
  } catch (error) {
    throw new Error(error);
  }
};

const getMusicianAvgResponseTime = async musician_id => {
  try {
    const sql =
      "SELECT AVG(`bookings`.`musician_resp_time`) as 'avg' FROM `bookings` WHERE `bookings`.`musician_id` =" +
      musician_id +
      ';';
    const result: any = await connection.query(sql, { type: QueryTypes.SELECT });

    console.log('*****************');
    console.log(result[0].avg);
    console.log('*****************');

    return result.length > 0 ? parseInt(result[0].avg) : 0;
  } catch (error) {
    throw new Error(error);
  }
};

const updateCancellationPercentage = async user_id => {
  try {
    let cancellation_percentage_data: any = 0;
    const Userdata = await User.findOne({
      where: { id: user_id },
      attributes: [
        'id',
        [
          Sequelize.literal(
            `(SELECT COUNT(IFNULL(id,0)) FROM bookings WHERE musician_id = User.id  AND is_deleted = 0)`,
          ),
          'total_booking',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(IFNULL(id,0)) FROM bookings WHERE musician_id = User.id  AND is_deleted = 0 AND status=7)`,
          ),
          'total_cancel',
        ],
      ],
      logging: true,
    });
    console.log(Userdata);
    if (Userdata) {
      if (Number(Userdata.get('total_booking')) > 0) {
        cancellation_percentage_data =
          (Number(Userdata.get('total_cancel')) * 100) / Number(Userdata.get('total_booking'));
      }
    }
    await UserDetails.update(
      {
        cancellation_percentage: cancellation_percentage_data,
        updatedAt: new Date(),
        u_by: user_id,
      },
      { where: { user_id: user_id }, logging: true },
    );
    return true;
  } catch (error) {
    throw new Error(error);
  }
};

const blockMusician = async (user_id, token) => {
  try {
    const start = moment
      .utc()
      .startOf('day')
      .unix();
    const end = moment
      .utc()
      .endOf('day')
      .unix();

    console.log(start + ':' + end);

    const Userdata = await User.findOne({
      where: { id: user_id },
      attributes: [
        'id',
        [
          Sequelize.literal(
            `(SELECT COUNT(IFNULL(id,0)) FROM bookings WHERE musician_id = User.id  AND is_deleted = 0 AND status=7 and cancelled_date >= ${start} and cancelled_date <= ${end})`,
          ),
          'total_cancel',
        ],
      ],
      logging: true,
    });
    console.log(Userdata);
    if (Userdata) {
      if (Number(Userdata.get('total_cancel')) >= config.CONSICUTIVE_CANCELLATION) {
        //block the user

        const suspension_time = moment()
          .add('24', 'hours')
          .unix();

        const musician = await updateUserByField('id', user_id, {
          is_suspended: 1,
          suspension_time: suspension_time,
          u_by: user_id,
        });

        //send push
        await pushService.sendNotification(
          PushNotificaitonTypes.ACCOUNT_BLOCK_BY_REQUEST,
          [user_id],
          Actors.Musician,
          null,
          1,
          null,
        );
        //delete token
        await authService.destroyToken(token);
      }
    }

    return true;
  } catch (error) {
    throw new Error(error);
  }
};
export {
  createUser,
  getUserByField,
  updateUserByField,
  createAddress,
  generateEmailToken,
  createUserDetails,
  updateUserDetailsByField,
  getAllPortfolioByMusician,
  exportUsers,
  createMusicianCategories,
  updateMusicianCategories,
  exportMusician,
  reOrder,
  createUserBank,
  updateUserAddress,
  updateUserBank,
  generateOTP,
  musicianResponse,
  createMusicianPortfolio,
  updateMusicianPortfolio,
  getMusicianPortfolio,
  musicianFavorite,
  exportBooking,
  getMusicianResponse,
  getMusicianAvaibility,
  getMusicianAllCategory,
  recentViewByUser,
  getrecentViewMusicianByUser,
  getfavoriteMusicianByUser,
  checkMusicianFavourite,
  checkCurrentBookingByUserId,
  getMusicianAvaibilityByTime,
  getMusicianAvgResponseTime,
  updateCancellationPercentage,
  blockMusician,
  getMusicianCategories,
};
