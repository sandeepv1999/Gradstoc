import { CMS } from '../models/cms.model';
import { CMSTranslation } from '../models/cmsTranslation.model';
import * as _ from 'lodash';

export const createCMS = async (data: object): Promise<CMS> => {
  console.log('*********** inside create ***********');
  try {
    const category = new CMS(data);
    await category.save();
    return category;
  } catch (error) {
    throw new Error(error);
  }
};

export const createTranslation = async (data: object[]): Promise<CMSTranslation[]> => {
  console.log('*********** inside create ***********');
  try {
    // const translation = new CategoryTranslation(data);
    const translation = await CMSTranslation.bulkCreate(data);
    return translation;
  } catch (error) {
    throw new Error(error);
  }
};

export const updateCMSByField = async (_field: string, _value: string | number, data: object): Promise<CMS> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await CMS.update(data, query);
    return await CMS.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};

export const updateCMSTranslationByField = async (
  _field: string,
  _value: string | number,
  data: object,
): Promise<CMSTranslation> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }
  if (_field === 'category_id') {
    _.set(whereCondition, 'category_id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await CMSTranslation.update(data, query);
    return await CMSTranslation.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};
