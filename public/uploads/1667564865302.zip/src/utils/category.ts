import { Category } from '../models/category.model';
import { CategoryTranslation } from '../models/categoryTranslation.model';
import * as _ from 'lodash';

export const createCategory = async (data: object): Promise<Category> => {
  console.log('*********** inside create ***********');
  try {
    const category = new Category(data);
    await category.save();
    return category;
  } catch (error) {
    throw new Error(error);
  }
};

export const createTranslation = async (data: object[]): Promise<CategoryTranslation[]> => {
  console.log('*********** inside create ***********');
  try {
    // const translation = new CategoryTranslation(data);
    const translation = await CategoryTranslation.bulkCreate(data);
    return translation;
  } catch (error) {
    throw new Error(error);
  }
};

export const updateCategoryByField = async (
  _field: string,
  _value: string | number,
  data: object,
): Promise<Category> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await Category.update(data, query);
    return await Category.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};

export const updateCategoryTranslationByField = async (
  _field: string,
  _value: string | number,
  data: object,
): Promise<CategoryTranslation> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }
  if (_field === 'category_id') {
    _.set(whereCondition, 'category_id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await CategoryTranslation.update(data, query);
    return await CategoryTranslation.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};
