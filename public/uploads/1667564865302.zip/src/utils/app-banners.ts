import * as _ from 'lodash';
import { AppBanners } from '../models/appBanner.model';

export const createBanner = async (data: object): Promise<AppBanners> => {
  console.log('*********** inside create ***********');
  try {
    const banner = new AppBanners(data);
    await banner.save();
    return banner;
  } catch (error) {
    throw new Error(error);
  }
};

export const updateBannerByField = async (
  _field: string,
  _value: string | number,
  data: object,
): Promise<AppBanners> => {
  const whereCondition = {};

  if (_field === 'id') {
    _.set(whereCondition, 'id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await AppBanners.update(data, query);
    return await AppBanners.findOne(query);
  } catch (error) {
    throw new Error(error);
  }
};
