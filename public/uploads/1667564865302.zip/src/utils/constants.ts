/**
 * @file Global Constants
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 * DESCRIPTION
 */

export enum DeviceTypes {
  ANDROID = 'A',
  IOS = 'I',
}

export enum Languages {
  ENGLISH = '1',
  AREBIC = '2',
}

export enum LanguageCodes {
  ENGLISH = 'en',
  AREBIC = 'ar',
}

export enum Actors {
  Admin = 1,
  SubAdmin = 2,
  Customer = 3,
  Musician = 4,
}

export enum NotificationTypes {
  AllCustomers = 1,
  AllMusicians = 2,
  SelectedCustomers = 3,
  SelectedMusicians = 4,
}

export enum BookingType {
  Hourly = 1,
  FixedDay = 2,
}

export enum BookingStatus {
  Pending = 1,
  Confirmed = 2,
  Completed = 3,
  cancelledByAdmin = 4,
  cancelledByMusician = 5,
  cancelledByUser = 6,
  rejectededByMusician = 7,
}

export enum CancelReasons {
  Cancellation = 1,
  Reject = 2,
}

export enum Notifications {
  Cancellation = 1,
  Reject = 2,
}

export enum UserStatus {
  Active = 1,
  InActive = 0,
}

export enum AddressTypes {
  Home = 1,
  Work = 2,
  Other = 3,
}

export enum MusicianPricing {
  OFF = 0,
  HOURLY = 1,
  FIXED = 2,
  BOTH = 3,
}

export enum RefundStatus {
  PENDING = 0,
  COMPLETED = 1,
  REJECTED = 2,
}

export enum MusicianPaymentRequest {
  PENDING = 0,
  APPROVED = 1,
  DECLINED = 2,
}

export enum PushNotificaitonTypes {
  REQUEST_ACCEPTED = 'request_accepted',
  REQUEST_REJECTED = 'request_rejected',
  REQUEST_COMPLETED = 'request_completed',
  PAYMENT_REFUND = 'payment_refund',
  ADMIN_NOTIFICATION = 'admin_notification',
  PORTFOLIO_APPROVED = 'portfolio_approved',
  PORTFOLIO_UNAPPROVED = 'portfolio_unapproved',
  BOOKING_REQUEST = 'booking_request',
  CANCEL_REQUEST = 'cancel_request',
  // USER_ACTIVE = 'user_active',
  USER_BLOCK = 'user_block',
  USER_INACTIVE = 'user_inactive',
  USER_DELETE = 'user_delete',
  RATING = 'rating',
  PAYMENT_DUE_REQUEST_ACCEPTED = 'payment_due_request_accepted',
  PAYMENT_DUE_REQUEST_REJECTED = 'payment_due_request_rejected',
  ACCOUNT_BLOCK_BY_REQUEST = 'account_block_due_to_cancellation',
}

export enum NotifyToAdminStatus {
  Pending = 0,
  Requested = 1,
}
