/* eslint-disable @typescript-eslint/no-explicit-any */

import { Token } from '../models/tokens.model';
import { FindOptions } from 'sequelize/types';
import config from '../config';
import bcrypt from 'bcryptjs';
import { Op } from 'sequelize';
import * as _ from 'lodash';

const createToken = async (_data: object): Promise<Token> => {
  try {
    const userToken = new Token(_data);
    await userToken.save();
    return userToken;
  } catch (error) {
    throw new Error(error);
  }
};

const destroyToken = async (token: string): Promise<boolean> => {
  try {
    const deleteToken = await Token.destroy({
      where: {
        access_token: token,
      },
    });
    if (deleteToken === 1) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    throw new Error(error);
  }
};

const destroyTokensByUserId = async (user_id: number): Promise<boolean> => {
  try {
    const deleteToken = await Token.destroy({
      where: {
        user_id,
      },
    });
    if (deleteToken === 1) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    throw new Error(error);
  }
};

const findTokenByDeviceID = async (_deviceId: string): Promise<Token> => {
  const query: FindOptions = {
    where: {
      device_id: _deviceId,
    },
  };
  try {
    const tokenData = await Token.findOne(query);
    return tokenData;
  } catch (error) {
    throw new Error(error);
  }
};

const encryptPassword = async (password: string): Promise<string> => {
  if (password) {
    const salt = await bcrypt.genSalt(config.BCRYPT_ROUND_FOR_PASSWORD);

    return await bcrypt.hash(password, salt);
  }
};

const comparePassword = async (plaintextPassword: string, hashFromDb: string): Promise<boolean> => {
  const data = await bcrypt.compare(plaintextPassword, hashFromDb);
  return data;
};

const updateToken = async (access_token: string, data: object) => {
  try {
    await Token.update(data, { where: { access_token } });
  } catch (error) {
    throw new Error(error);
  }
};
const getAllUserTokens = async (user_ids: Array<number>) => {
  const userTokens = await Token.findAll({
    where: {
      user_id: { [Op.in]: user_ids },
      // user_type: actor,
      // user_language: language_code,
    },
  });
  const _tokens = userTokens.map(token => {
    return token.access_token;
  });

  return _tokens;
};
const updateTokenByField = async (_field: string, _value: string | number, data: object): Promise<any> => {
  const whereCondition = {};

  if (_field === 'user_id') {
    _.set(whereCondition, 'user_id', _value);
  }

  const query = {
    where: whereCondition,
  };

  try {
    await Token.update(data, query);
    return true;
  } catch (error) {
    throw new Error(error);
  }
};
export {
  createToken,
  findTokenByDeviceID,
  encryptPassword,
  comparePassword,
  destroyToken,
  updateToken,
  destroyTokensByUserId,
  getAllUserTokens,
  updateTokenByField,
};
