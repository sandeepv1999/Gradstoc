import { Router } from 'express';
import { list, get, exportBookingData, refundBooking, allCancelList } from './controllers';

const router = Router();

export const booking = () => router.use([list(), get(), exportBookingData(), refundBooking(), allCancelList()]);
