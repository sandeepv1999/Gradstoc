/* eslint-disable @typescript-eslint/no-explicit-any */
//********************************************************************************
//Title : Booking Controller
//Developer:Arshad Shaikh
//Email:arshad@peerbits.com
//Company:Peerbits Solution
//Project:Alhaan
//Created By : Arshad Shaikh
//Created Date : 27-01-2021
//Updated Date :
//Updated By :
//********************************************************************************
import * as userService from '../../../utils/user';
import * as bookingService from '../../../utils/booking';
import * as categoryService from '../../../utils/category';
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import { FileUpload } from '../../../services/fileUpload';
import config from '../../../config';
import { Category } from '../../../models/category.model';
import { Booking } from '../../../models/bookings.model';
import { User } from '../../../models/users.model';
import { Op, Sequelize } from 'sequelize';
import { CategoryTranslation } from '../../../models/categoryTranslation.model';
import { Language } from '../../../models/language.model';
import * as _ from 'lodash';
import { BookingCategory } from '../../../models/bookingCategory.model';
import { BookingAddress } from '../../../models/bookingAddresses.model';
import {
  BookingType,
  BookingStatus,
  Actors,
  RefundStatus,
  Languages,
  LanguageCodes,
  PushNotificaitonTypes,
} from '../../../utils/constants';
import moment from 'moment';
import * as pushService from '../../../services/notification.service';

const router = Router();
const validator = createValidator();

const fileUploadObj = new FileUpload(config);
const s3FileUpload = fileUploadObj.imageUploadS3();

//  ---------------- |||| CREATE |||| -----------------------

export const createCategoryBodySchema = Joi.object({
  // en_name: Joi.string().required(),
  // ar_name: Joi.string().required(),
  sound: Joi.string(),
  image: Joi.string(),
  names: Joi.string(),
});
//  ---------------- |||| GET BY ID |||| -----------------------

const getBookingBodySchema = Joi.object({
  id: Joi.string().required(),
});
interface CreateCategoryRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    // en_name: string;
    // ar_name: string;
    sound: string;
    image: string;
    names: string;
  };
}

export const createCategoryHandler = async (req: ValidatedRequest<CreateCategoryRequestSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const categoryNames: any[] = JSON.parse(body.names);

    const categoryObj: Category = {} as Category;
    if (req.files) {
      console.log(req.files);
      categoryObj.icon_url = req.files['image'][0].location;
      categoryObj.sound_url = req.files['sound'][0].location;
    }
    categoryObj.i_by = user.id;

    const category = await categoryService.createCategory(categoryObj);

    const data = categoryNames.map(elem => {
      return {
        category_id: category.id,
        language_code: elem.language_code,
        name: elem.category_name,
      };
    });

    await categoryService.createTranslation(data);

    // await categoryService.createTranslation([
    //   {
    //     category_id: category.id,
    //     language_code: 'en',
    //     name: body.en_name,
    //   },
    //   {
    //     category_id: category.id,
    //     language_code: 'ar',
    //     name: body.ar_name,
    //   },
    // ]);

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Category Created Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const bookingListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
  start_date: Joi.string().allow('', null),
  end_date: Joi.string().allow('', null),
});

interface BookingListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
    start_date: string;
    end_date: string;
  };
}

export const bookingListHandler: RequestHandler = async (req: ValidatedRequest<BookingListRequestSchema>, res) => {
  try {
    console.log('**bookinglist***');
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}
    let where: any = {};
    // let musicialWhere: any = {};
    // let translationWhere: any = { language_code: 'en' };

    if (body.search_text && body.search_text != null) {
      where = {
        [Op.or]: [
          { id: { [Op.like]: '%' + body.search_text + '%' } },
          Sequelize.where(Sequelize.fn('', Sequelize.col('`musician`.`en_full_name`')), {
            [Op.like]: '%' + body.search_text + '%',
          }),
          ,
        ],
      };
    }
    if (body.statusFilter != null) {
      where.status = { [Op.eq]: body.statusFilter };
    }
    if (body.start_date && body.end_date) {
      where.booking_date = { [Op.between]: [body.start_date, body.end_date] };
      //   where.booking_date = {
      //     [Op.and]: [
      //       Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`Booking`.`booking_date`'), '%Y-%m-%d'), {
      //         [Op.gte]: body.start_date,
      //       }),
      //       Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`Booking`.`booking_date`'), '%Y-%m-%d'), {
      //         [Op.lte]: body.end_date,
      //       }),
      //     ],
      //   };
    }
    where.is_active = 1;
    where.is_deleted = 0;

    const bookings = await Booking.findAndCountAll({
      include: [
        {
          model: User,
          as: 'musician',
          attributes: ['id', 'en_full_name', 'image'],
        },
        {
          model: User,
          as: 'customer',
          attributes: ['id', 'en_full_name', 'image'],
        },
        {
          model: BookingCategory,
          as: 'booking_category',
          where: {
            language_code: 'en',
          },
          attributes: ['id', 'name'],
        },
      ],
      where: where,
      offset: start,
      limit: limit,
      distinct: false,
      subQuery: false,
      order: [['id', 'DESC']],
      attributes: [
        'id',
        ['booking_date', 'booking_date'],
        ['event_date', 'date'],
        'start_time',
        'end_time',
        'hours',
        'status',
        'admin_earning',
        'cancellation_fee',
        'refund_amount',
        'refund_description',
        'is_refunded',
        'refund_status',
        ['is_fixed', 'booked_type'],
        ['total_amount', 'amount'],
        [Sequelize.fn('', Sequelize.col('`musician`.`en_full_name`')), 'musician_name'],
        [Sequelize.fn('', Sequelize.col('`booking_category`.`name`')), 'category_name'],
        [Sequelize.fn('', Sequelize.col('`customer`.`en_full_name`')), 'customer_name'],
      ],
      logging: true,
    });
    // console.log(bookings);
    if (bookings.rows.length > 0) {
      if (bookings.rows.length >= limit) {
        bookings.rows.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', bookings, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', bookings },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const allCancelListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  // statusFilter: Joi.number().allow(null),
  start_date: Joi.string().allow('', null),
  end_date: Joi.string().allow('', null),
});

interface AllCancelListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    // statusFilter: number;
    start_date: string;
    end_date: string;
  };
}

export const allCancelListHandler: RequestHandler = async (req: ValidatedRequest<AllCancelListRequestSchema>, res) => {
  try {
    console.log('**bookinglist***');
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}
    let where: any = {};
    // let musicialWhere: any = {};
    // let translationWhere: any = { language_code: 'en' };

    if (body.search_text && body.search_text != null) {
      where = {
        [Op.or]: [
          { id: { [Op.like]: '%' + body.search_text + '%' } },
          Sequelize.where(Sequelize.fn('', Sequelize.col('`customer`.`en_full_name`')), {
            [Op.like]: '%' + body.search_text + '%',
          }),
          ,
        ],
      };
    }
    // if (body.statusFilter != null) {
    //   where.status = { [Op.eq]: body.statusFilter };
    // }
    if (body.start_date && body.end_date) {
      where.booking_date = { [Op.between]: [body.start_date, body.end_date] };
      //   where.booking_date = {
      //     [Op.and]: [
      //       Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`Booking`.`booking_date`'), '%Y-%m-%d'), {
      //         [Op.gte]: body.start_date,
      //       }),
      //       Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`Booking`.`booking_date`'), '%Y-%m-%d'), {
      //         [Op.lte]: body.end_date,
      //       }),
      //     ],
      //   };
    }
    where.status = {
      [Op.in]: [BookingStatus.cancelledByAdmin, BookingStatus.cancelledByMusician, BookingStatus.cancelledByUser],
    };
    where.is_active = 1;
    where.is_deleted = 0;

    const bookings = await Booking.findAndCountAll({
      include: [
        {
          model: User,
          as: 'musician',
          attributes: ['id', 'en_full_name', 'image'],
        },
        {
          model: User,
          as: 'customer',
          attributes: ['id', 'en_full_name', 'image'],
        },
        {
          model: BookingCategory,
          as: 'booking_category',
          where: {
            language_code: 'en',
          },
          attributes: ['id', 'name'],
        },
      ],
      where: where,
      offset: start,
      limit: limit,
      distinct: false,
      subQuery: false,
      order: [['id', 'DESC']],
      attributes: [
        'id',
        ['booking_date', 'booking_date'],
        ['event_date', 'date'],
        'start_time',
        'end_time',
        'hours',
        'status',
        'admin_earning',
        'cancellation_fee',
        'refund_amount',
        'refund_description',
        'is_refunded',
        'refund_status',
        ['is_fixed', 'booked_type'],
        ['total_amount', 'amount'],
        [Sequelize.fn('', Sequelize.col('`musician`.`en_full_name`')), 'musician_name'],
        [Sequelize.fn('', Sequelize.col('`booking_category`.`name`')), 'category_name'],
        [Sequelize.fn('', Sequelize.col('`customer`.`en_full_name`')), 'customer_name'],
      ],
      logging: true,
    });
    // console.log(bookings);
    if (bookings.rows.length > 0) {
      if (bookings.rows.length >= limit) {
        bookings.rows.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', bookings, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', bookings },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

const exportsHandler: RequestHandler = async (req, res) => {
  // console.log('========>4');

  try {
    console.log('********In Handler *************');
    await userService.exportBooking(res);
  } catch (error) {
    // console.log('********In Handler *************');
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};
//  ---------------- |||| GET BY ID |||| -----------------------

// const getCategoryBodySchema = {
//   id: Joi.string().required(),
// };

interface GetBookingRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getBookingHandler: RequestHandler = async (req: ValidatedRequest<GetBookingRequestSchema>, res) => {
  try {
    console.log('getBookingHandler');
    const id = parseInt(req.params.id);

    // const musician = await userService.getUserByField('id', id);

    const booking = await Booking.findOne({
      include: [
        {
          model: User,
          as: 'musician',
          attributes: ['id', 'en_full_name', 'image'],
        },
        {
          model: User,
          as: 'customer',
          attributes: ['id', 'en_full_name', 'image'],
        },
        {
          model: BookingCategory,
          as: 'booking_category',
          where: {
            language_code: 'en',
          },
          attributes: ['id', 'name'],
        },
        {
          model: BookingAddress,
          as: 'booking_address',
          attributes: ['id', 'address', 'landmark', 'city', 'state', 'country'],
        },
      ],
      where: { id },
      attributes: [
        'id',
        ['booking_date', 'booking_date'],
        ['event_date', 'date'],
        'start_time',
        'end_time',
        'hours',
        'status',
        'admin_earning',
        ['is_fixed', 'booked_type'],
        ['total_amount', 'amount'],
        [Sequelize.fn('', Sequelize.col('`musician`.`en_full_name`')), 'musician_name'],
        [Sequelize.fn('', Sequelize.col('`booking_category`.`name`')), 'category_name'],
        [Sequelize.fn('', Sequelize.col('`customer`.`en_full_name`')), 'customer_name'],
        [
          Sequelize.fn(
            'concat',
            Sequelize.col('`booking_address`.`address`'),
            ', ',
            Sequelize.col('`booking_address`.`landmark`'),
            ', ',
            Sequelize.col('`booking_address`.`city`'),
            ', ',
            Sequelize.col('`booking_address`.`state`'),
            ', ',
            Sequelize.col('`booking_address`.`country`'),
          ),
          'address',
        ],
      ],
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', booking },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

export const refundBookingBodySchema = Joi.object({
  id: Joi.number().required(),
  description: Joi.string().allow('', null),
});
interface RefundBookingRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    description: string;
  };
}
export const refundBookingHandler: RequestHandler = async (req: ValidatedRequest<RefundBookingRequestSchema>, res) => {
  try {
    console.log('**Refund Booking***');
    const body = req.body;
    const user = req.userData;
    const id = Number(body.id);
    const where: any = {};
    where.is_deleted = 0;
    where.id = id;
    const booking = await Booking.findOne({
      where: where,
    });
    if (!booking) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Booking not found' },
      });
    }
    // already refunded
    if (booking.is_refunded == RefundStatus.COMPLETED) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Booking already refunded' },
      });
    }
    // console.log(booking);
    const bookingObj: Booking = {} as Booking;
    bookingObj.is_refunded = 1;
    bookingObj.refund_status = RefundStatus.COMPLETED;
    bookingObj.refund_description = req.body.description;
    bookingObj.refund_amount = booking.total_amount;
    bookingObj.refund_date = moment().unix();
    bookingObj.u_by = user.id;
    bookingObj.updatedAt = new Date();

    await bookingService.updateBookingByField('id', id, bookingObj);

    const musicianData: any = [];
    musicianData['company_name'] = req.body.description ? req.body.description : '';
    musicianData['proposal_name'] = '';
    musicianData['user_name'] = '';
    musicianData['candidate_id'] = 0;
    musicianData['proposal_id'] = 0;
    musicianData['booking_id'] = booking.id;
    console.log(musicianData);
    //send push
    await pushService.sendNotification(
      PushNotificaitonTypes.PAYMENT_REFUND,
      [booking.user_id],
      Actors.Customer,
      musicianData,
      user.id,
      null,
    );

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success' },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};
//  ---------------- |||| EXPORT  |||| -----------------------
export const exportBookingData = () => router.get('/export/:type', mainAuthMiddleware, handleError(exportsHandler));
//  ---------------- |||| ROUTES |||| -----------------------
export const create = () =>
  router.post(
    '/create',
    s3FileUpload.fields([
      { name: 'image', maxCount: 1 },
      { name: 'sound', maxCount: 1 },
    ]),
    validator.body(createCategoryBodySchema),
    mainAuthMiddleware,
    handleError(createCategoryHandler),
  );

export const list = () =>
  router.post('/', validator.body(bookingListBodySchema), mainAuthMiddleware, handleError(bookingListHandler));

export const allCancelList = () =>
  router.post(
    '/allcancellist',
    validator.body(allCancelListBodySchema),
    mainAuthMiddleware,
    handleError(allCancelListHandler),
  );

export const get = () =>
  router.get('/:id', validator.params(getBookingBodySchema), mainAuthMiddleware, handleError(getBookingHandler));

// export const getAll = () => router.post('/getAllCategories', mainAuthMiddleware, handleError(getAllCategories));

//refund booking
export const refundBooking = () =>
  router.post(
    '/refundbooking',
    validator.body(refundBookingBodySchema),
    mainAuthMiddleware,
    handleError(refundBookingHandler),
  );
