import { Router } from 'express';
import { get, edit, getDashboardData } from './controllers';

const router = Router();

export const settings = () => router.use([get(), edit(), getDashboardData()]);
