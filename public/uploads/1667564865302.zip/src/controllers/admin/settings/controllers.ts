import * as Joi from '@hapi/joi';
import { ValidatedRequestSchema, ContainerTypes, createValidator } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import handleError from '../../../middlewares/handle-error';
import { Settings } from '../../../models/settings.model';
import { FileUpload } from '../../../services/fileUpload';
import config from '../../../config';
import { Booking } from '../../../models/bookings.model';
import { MusicianPayments } from '../../../models/musicianPayments.model';
import { Op, QueryTypes, Sequelize } from 'sequelize';
import moment from 'moment';
import {
  BookingType,
  BookingStatus,
  Actors,
  RefundStatus,
  Languages,
  LanguageCodes,
  PushNotificaitonTypes,
} from '../../../utils/constants';
import { setUpSequelize } from '../../../db/sql/connection';
import { User } from '../../../models/users.model';

const connection: Sequelize = setUpSequelize();
const router = Router();
const validator = createValidator();

const fileUploadObj = new FileUpload(config);
const s3FileUpload = fileUploadObj.imageUploadS3();

//  ---------------- |||| EDIT |||| -----------------------
export const editsettingsBodySchema = Joi.object({
  page_size: Joi.string().required(),
  cancellation_charge: Joi.string().required(),
  admin_commission: Joi.string().required(),
  app_logo: Joi.string(),
  instagram_link: Joi.string(),
  facebook_link: Joi.string(),
  twitter_link: Joi.string(),
});

interface EditsettingsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    page_size: string;
    cancellation_charge: string;
    admin_commission: string;
    app_logo: string;
    instagram_link: string;
    facebook_link: string;
    twitter_link: string;
  };
}

export const editsettings = async (req, res) => {
  try {
    const body = req.body;

    // const en_obj = {
    //   title: body.en_name,
    //   content: body.en_content,
    //   u_by: user.id,
    // };

    // const ar_obj = {
    //   title: body.ar_name,
    //   content: body.ar_content,
    //   u_by: user.id,
    // };

    await Settings.update({ value: parseInt(body.page_size) }, { where: { key: 'page_size' } });
    await Settings.update({ value: body.cancellation_charge }, { where: { key: 'cancellation_charge' } });
    await Settings.update({ value: body.admin_commission }, { where: { key: 'admin_commission' } });
    await Settings.update({ value: body.instagram_link }, { where: { key: 'instagram_link' } });
    await Settings.update({ value: body.facebook_link }, { where: { key: 'facebook_link' } });
    await Settings.update({ value: body.twitter_link }, { where: { key: 'twitter_link' } });
    if (req.file) {
      await Settings.update({ value: req.file.location }, { where: { key: 'app_logo' } });
    }
    // await Settings.update({ value: body.page_size }, { where: { key: 'page_size' } });
    const settings = await Settings.findOne({ where: { key: 'page_size' } });
    return res.send({
      success: 1,
      error: [],
      data: { message: 'settings Updated Successfully', settings },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

export const getsettings: RequestHandler = async (req, res) => {
  try {
    const settings = await Settings.findAll();

    if (!settings) {
      return res.send({ success: 0, error: { message: 'No record found' } });
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', settings },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

export const getDashboardDataHandler: RequestHandler = async (req, res) => {
  try {
    //today requests
    const fromDate = moment()
      .utc()
      .startOf('day')
      .unix();
    const toDate = moment()
      .utc()
      .endOf('day')
      .unix();
    const where: any = {};

    where.event_date = {
      [Op.gte]: fromDate,
      [Op.lte]: toDate,
    };

    where.is_deleted = 0;
    const bookings = await Booking.count({
      where: where,
      attributes: ['id'],
      logging: true,
    });

    //request_awaiting_confirmation
    const confirmWhere: any = {};
    confirmWhere.is_deleted = 0;
    confirmWhere.status = BookingStatus.Pending;
    const awaitingConfirmBookings = await Booking.count({
      where: confirmWhere,
      attributes: ['id'],
      logging: true,
    });

    //bookings_to_be_completed
    const totbCompletedWhere: any = {};
    totbCompletedWhere.is_deleted = 0;
    totbCompletedWhere.status = BookingStatus.Confirmed;
    const tobeCompletedBookings = await Booking.count({
      where: totbCompletedWhere,
      attributes: ['id'],
      logging: true,
    });

    //completed_bookings
    const completedWhere: any = {};
    completedWhere.is_deleted = 0;
    completedWhere.status = BookingStatus.Completed;
    const completedBookings = await Booking.count({
      where: completedWhere,
      attributes: ['id'],
      logging: true,
    });

    //payment_due_to_musician
    let due_to_admin = 0;
    const sql =
      'SELECT  sum(outstanding_amount) AS `amount` FROM `musician_payments` AS `MusicianPayments` WHERE `MusicianPayments`.`is_deleted` = 0 AND `MusicianPayments`.`outstanding_amount` IS NOT NULL AND `MusicianPayments`.`paid_amount` = 0; ';
    const result: any = await connection.query(sql, { type: QueryTypes.SELECT });

    console.log('*****************');
    console.log(result[0].amount);
    console.log('*****************');
    due_to_admin = result[0].amount ? result[0].amount : 0;

    //booking_cancelled_by_user
    const cancellByUserWhere: any = {};
    cancellByUserWhere.is_deleted = 0;
    cancellByUserWhere.status = BookingStatus.cancelledByUser;
    const cancellByUserBookings = await Booking.count({
      where: cancellByUserWhere,
      attributes: ['id'],
      logging: true,
    });

    //booking_cancelled_by_musician
    const cancellByMusicianWhere: any = {};
    cancellByMusicianWhere.is_deleted = 0;
    cancellByMusicianWhere.status = {
      [Op.or]: [BookingStatus.cancelledByMusician, BookingStatus.rejectededByMusician],
    };
    const cancellByMusicianBookings = await Booking.count({
      where: cancellByMusicianWhere,
      attributes: ['id'],
      logging: true,
    });

    //user_registered
    const userWhere: any = {};
    userWhere.is_deleted = 0;
    userWhere.actor = Actors.Customer;
    const userBookings = await User.count({
      where: userWhere,
      logging: true,
    });

    //musician_registered
    const musicianWhere: any = {};
    musicianWhere.is_deleted = 0;
    musicianWhere.actor = Actors.Musician;
    const musicianBookings = await User.count({
      where: musicianWhere,
      logging: true,
    });

    //booking_accepted
    const acceptedWhere: any = {};
    acceptedWhere.is_deleted = 0;
    acceptedWhere.status = BookingStatus.Confirmed;
    const acceptedBookings = await Booking.count({
      where: acceptedWhere,
      attributes: ['id'],
      logging: true,
    });

    //booking_rejected
    const rejectedWhere: any = {};
    rejectedWhere.is_deleted = 0;
    rejectedWhere.status = BookingStatus.rejectededByMusician;
    const rejectedBookings = await Booking.count({
      where: rejectedWhere,
      attributes: ['id'],
      logging: true,
    });

    const data = {
      today_request: bookings ? bookings : 0,
      request_awaiting_confirmation: awaitingConfirmBookings ? awaitingConfirmBookings : 0,
      bookings_to_be_completed: tobeCompletedBookings ? tobeCompletedBookings : 0,
      completed_bookings: completedBookings ? completedBookings : 0,
      payment_due_to_musician: due_to_admin ? parseFloat(String(due_to_admin)).toFixed(2) : '0',
      booking_cancelled_by_user: cancellByUserBookings ? cancellByUserBookings : 0,
      booking_cancelled_by_musician: cancellByMusicianBookings ? cancellByMusicianBookings : 0,
      user_registered: userBookings ? userBookings : 0,
      musician_registered: musicianBookings ? musicianBookings : 0,
      request_rejected: rejectedBookings,
      request_accepted: acceptedBookings,
    };

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', data },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};
//  ---------------- |||| ROUTES |||| -----------------------

export const get = () => router.get('/', mainAuthMiddleware, handleError(getsettings));

export const edit = () =>
  router.patch(
    '/',
    s3FileUpload.single('app_logo'),
    validator.body(editsettingsBodySchema),
    mainAuthMiddleware,
    handleError(editsettings),
  );

export const getDashboardData: any = () =>
  router.get('/getDashboardata', mainAuthMiddleware, handleError(getDashboardDataHandler));
