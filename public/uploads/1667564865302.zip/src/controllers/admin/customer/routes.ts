import { Router } from 'express';
import {
  createCustomer,
  customerList,
  changeCustomerStatus,
  deleteCustomer,
  get,
  getAdress,
  edit,
  exportCustomer,
} from './controllers';
const router = Router();

export const customer = () =>
  router.use([
    createCustomer(),
    customerList(),
    changeCustomerStatus(),
    deleteCustomer(),
    exportCustomer(),
    get(),
    getAdress(),
    edit(),
  ]);
