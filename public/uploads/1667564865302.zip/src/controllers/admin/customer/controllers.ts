/* eslint-disable @typescript-eslint/no-explicit-any */
import * as userService from '../../../utils/user';
import { NotFoundError } from '../../../errors';
import { RequestHandler, Router } from 'express';
import * as Joi from '@hapi/joi';
import * as _ from 'lodash';
import { FileUpload } from '../../../services/fileUpload';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import { createValidator } from 'express-joi-validation';
import config from '../../../config';
import {
  Languages,
  LanguageCodes,
  MusicianPaymentRequest,
  PushNotificaitonTypes,
  Actors,
} from '../../../utils/constants';

// import { Email } from '../../../services/email';
import * as emailService from '../../../services/email.service';
import { User } from '../../../models/users.model';
import { UserAddress } from '../../../models/userAddresses.model';
import { Op, Sequelize } from 'sequelize';
import * as pushService from '../../../services/notification.service';
import * as authService from '../../../utils/auth';

import { City } from '../../../models/city.model';
import { Country } from '../../../models/country.model';
import { State } from '../../../models/state.model';

const router = Router();
const validator = createValidator();
const fileUploadObj = new FileUpload(config);
const s3FileUpload = fileUploadObj.imageUploadS3();

//  ---------------- |||| CREATE |||| -----------------------
export const createCustomerBodySchema = Joi.object({
  en_full_name: Joi.string().required(),
  email: Joi.string().allow('', null),
  password: Joi.string().required(),
  phone_number: Joi.string().required(),
  address_type: Joi.string().required(),
  address: Joi.string().required(),
  landmark: Joi.string().required(),
  city: Joi.string().required(),
  state: Joi.string().required(),
  lat: Joi.number().required(),
  lng: Joi.number().required(),
  contact_person: Joi.string().required(),
  country: Joi.string().required(),
  image: Joi.string()
    .allow('')
    .allow(null),
});
export const createCustomerHandler = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;

    const saveCustomerData = await userService.createUser({
      en_full_name: body.en_full_name,
      actor: 3,
      email: body.email,
      password: body.password,
      phone_number: body.phone_number,
      image: req.file ? req.file.location : null,
      i_by: user.id,
    });

    await userService.createAddress({
      user_id: saveCustomerData.id,
      contact_person: body.contact_person || saveCustomerData.en_full_name,
      address_type: body.address_type,
      address: body.address,
      landmark: body.landmark,
      city_id: body.city,
      state_id: body.state,
      lat: body.lat,
      lng: body.lng,
      country_id: body.country,
      is_default: 1,
      i_by: user.id,
    });

    if (body.email) {
      emailService.sendMusicianRegistrationEmail(body, 'registration_customer');
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Customer create successfully' },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const customerListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
  suspensionFilter: Joi.number().allow(null),
  start_date: Joi.string().allow('', null),
  end_date: Joi.string().allow('', null),
});

interface CustomerListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
    suspensionFilter: string;
    start_date: string;
    end_date: string;
  };
}

export const customerListHandler: RequestHandler = async (req: ValidatedRequest<CustomerListRequestSchema>, res) => {
  try {
    const body = req.body;
    let Where: any = {};
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);
    let is_last = 1;

    if (body.search_text && body.search_text != null) {
      Where = {
        [Op.or]: [
          { en_full_name: { [Op.like]: '%' + body.search_text + '%' } },
          { email: { [Op.like]: '%' + body.search_text + '%' } },
          { phone_number: { [Op.like]: '%' + body.search_text + '%' } },
        ],
      };
    }
    if (body.statusFilter != null) {
      Where.is_active = { [Op.eq]: body.statusFilter };
    }

    // console.log('SDate', body.start_date);
    // console.log('EDate', body.end_date);

    if (body.start_date && body.end_date) {
      // Where.createdAt = { [Op.between]: [body.start_date, body.end_date] };
      Where.createdAt = {
        [Op.and]: [
          Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`User`.`createdAt`'), '%Y-%m-%d'), {
            [Op.gte]: body.start_date,
          }),
          Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`User`.`createdAt`'), '%Y-%m-%d'), {
            [Op.lte]: body.end_date,
          }),
        ],
      };
    }

    //   [Sequelize.Op.and]: [
    //     Sequelize.where(Sequelize.fn('date_format', Sequelize.fn('from_unixtime',Sequelize.col('order_date')), '%Y-%m-%d'),{[Op.gte]:moment.unix(body.start_date).format('YYYY-MM-DD')    }),
    //     Sequelize.where(Sequelize.fn('date_format', Sequelize.fn('from_unixtime',Sequelize.col('order_date')), '%Y-%m-%d'),{[Op.lte]:moment.unix(body.end_date).format('YYYY-MM-DD')    })
    // ],

    _.set(Where, 'actor', 3);
    _.set(Where, 'is_deleted', 0);
    _.set(Where, 'is_profile_completed', 1);
    _.set(Where, 'is_bank_completed', 1);
    _.set(Where, 'is_address_completed', 1);

    // const { status } = req.query;
    // if (status) {
    //   _.set(Where, 'is_active', status);
    // }

    const customers = await User.findAndCountAll({
      where: Where,
      include: [
        { model: UserAddress, as: 'addresses', where: { is_active: 1, is_deleted: 0, is_default: 1 }, required: false },
      ],
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
      distinct: true,
    });

    if (customers.rows.length > 0) {
      if (customers.rows.length >= limit) {
        customers.rows.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', customers, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', customers },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE STATUS |||| -----------------------
const changeCustomerStatusSchema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangeCustomerStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    status: number;
  };
}

const changeCustomerStatusHandler: RequestHandler = async (req: ValidatedRequest<ChangeCustomerStatusSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const Customer = await userService.updateUserByField('id', body.id, {
      is_active: body.status,
      u_by: user.id,
    });
    if (!Customer) {
      throw new NotFoundError();
    }
    //delete token of this user
    if (body.status == 0) {
      //send push
      await pushService.sendNotification(
        PushNotificaitonTypes.USER_INACTIVE,
        [body.id],
        Actors.Customer,
        null,
        user.id,
        null,
      );
      //delete token
      let firebaseIds = await authService.getAllUserTokens([body.id]);
      console.log(firebaseIds);
      // firebaseIds.map(data => {
      // await authService.destroyToken(data);
      // });
      firebaseIds = await Promise.all(
        firebaseIds.map(
          async (elem): Promise<any> => {
            // console.log(elem);
            await authService.destroyToken(elem);
          },
        ),
      );
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Record updated successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| DELETE |||| -----------------------
// const deleteCustomerParamsSchema = {
//   id: Joi.number().required(),
// };

// const deleteCustomerParamsSchema = {
//   params: {
//     id: Joi.number().required(),
//   },
// };
interface CustomerDeleteSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteCustomerHandler: RequestHandler = async (req: ValidatedRequest<CustomerDeleteSchema>, res) => {
  try {
    console.log('****************');
    const { id } = req.params;
    if (!id) {
      return res.send({
        success: 1,
        error: { message: 'id Params required' },
      });
    }
    const user = req.userData;
    await userService.updateUserByField('id', id, {
      is_deleted: 1,
      u_by: user.id,
    });
    // if (!Customer) {
    //   return res.send({
    //     success: 1,
    //     error: { message: 'Customer not found for particular id' },
    //   });
    // }
    //delete token of this user
    //send push
    await pushService.sendNotification(
      PushNotificaitonTypes.USER_DELETE,
      [Number(id)],
      Actors.Customer,
      null,
      user.id,
      null,
    );
    //delete token
    let firebaseIds = await authService.getAllUserTokens([Number(id)]);
    console.log(firebaseIds);
    // firebaseIds.map(data => {
    // await authService.destroyToken(data);
    // });
    firebaseIds = await Promise.all(
      firebaseIds.map(
        async (elem): Promise<any> => {
          // console.log(elem);
          await authService.destroyToken(elem);
        },
      ),
    );
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Customer deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

const getCustomerBodySchema = Joi.object({
  id: Joi.string().required(),
});

interface GetCustomerRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getCustomer: RequestHandler = async (req: ValidatedRequest<GetCustomerRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);
    const include = ['address', 'bankdetails'];
    const customer = await userService.getUserByField('id', id, include);

    // const customer = await User.findOne({
    //   where: { id },
    //   include: [
    //     {
    //       model: UserAddress,
    //       where: { is_default: 1 },
    //       as: 'addresses',
    //       required: false,
    //     },
    //   ],
    //   attributes: ['id', 'en_full_name', 'email', 'dial_code', 'phone_number', 'image', 'is_active'],
    // });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', customer },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| EDIT CUSTOMER |||| -----------------------

export const editCustomerBodySchema = Joi.object({
  en_full_name: Joi.string().required(),
  email: Joi.string().required(),
  phone_number: Joi.string().required(),
  address_type: Joi.string().required(),
  address: Joi.string().required(),
  landmark: Joi.string().required(),
  city: Joi.string().required(),
  state: Joi.string().required(),
  lat: Joi.number().required(),
  lng: Joi.number().required(),
  contact_person: Joi.string().required(),
  country: Joi.string().required(),
  image: Joi.string(),
});
export const editCustomerHandler = async (req, res) => {
  try {
    const body = req.body;
    const { id } = req.params;
    const user = req.userData;

    const customerObj = {
      en_full_name: body.en_full_name,
      email: body.email,
      phone_number: body.phone_number,
      image: req.file ? req.file.location : body.image == 'null' ? null : body.image,
      u_by: user.id,
    };

    await userService.updateUserByField('id', id, customerObj);

    await UserAddress.update(
      {
        address_type: body.address_type,
        address: body.address,
        landmark: body.landmark,
        city_id: body.city,
        state_id: body.state,
        lat: body.lat,
        lng: body.lng,
        country_id: body.country,
        u_by: user.id,
      },
      { where: { is_default: 1, user_id: id, is_active: 1, is_deleted: 0 } },
    );

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Customer updated successfully' },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| EXPORT CUSTOMER |||| -----------------------

const exportHandler: RequestHandler = async (req, res) => {
  try {
    console.log('********In Handler *************');
    await userService.exportUsers(res);
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const getAdressBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  // search_text: Joi.string()
  //   .allow('')
  //   .allow(null),
  // statusFilter: Joi.number().allow(null),
  // suspensionFilter: Joi.number().allow(null),
  // start_date: Joi.string().allow('', null),
  // end_date: Joi.string().allow('', null),
});

interface GetAdressRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    // search_text: string;
    // statusFilter: number;
    // suspensionFilter: string;
    // start_date: string;
    // end_date: string;
  };
}

export const getAdressHandler: RequestHandler = async (req: ValidatedRequest<GetAdressRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);
    const body = req.body;
    const Where: any = {};
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);
    let is_last = 1;

    //   [Sequelize.Op.and]: [
    //     Sequelize.where(Sequelize.fn('date_format', Sequelize.fn('from_unixtime',Sequelize.col('order_date')), '%Y-%m-%d'),{[Op.gte]:moment.unix(body.start_date).format('YYYY-MM-DD')    }),
    //     Sequelize.where(Sequelize.fn('date_format', Sequelize.fn('from_unixtime',Sequelize.col('order_date')), '%Y-%m-%d'),{[Op.lte]:moment.unix(body.end_date).format('YYYY-MM-DD')    })
    // ],

    _.set(Where, 'user_id', id);
    _.set(Where, 'is_deleted', 0);
    _.set(Where, 'is_active', 1);
    // _.set(Where, 'is_profile_completed', 1);
    // _.set(Where, 'is_bank_completed', 1);
    // _.set(Where, 'is_address_completed', 1);

    // const { status } = req.query;
    // if (status) {
    //   _.set(Where, 'is_active', status);
    // }

    const customers = await UserAddress.findAndCountAll({
      where: Where,
      include: [
        {
          model: City,
          as: 'city',
        },
        {
          model: State,
          as: 'state',
        },
        {
          model: Country,
          as: 'country',
        },
      ],
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
      // distinct: true,
    });

    if (customers.rows.length > 0) {
      if (customers.rows.length >= limit) {
        customers.rows.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', customers, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', customers },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------
export const createCustomer: any = () =>
  router.post(
    '/create',
    s3FileUpload.single('image'),
    validator.body(createCustomerBodySchema),
    mainAuthMiddleware,
    handleError(createCustomerHandler),
  );

export const customerList = () =>
  router.post('/', validator.body(customerListBodySchema), mainAuthMiddleware, handleError(customerListHandler));

export const changeCustomerStatus: any = () =>
  router.post(
    '/changeStatus',
    validator.body(changeCustomerStatusSchema),
    mainAuthMiddleware,
    handleError(changeCustomerStatusHandler),
  );

export const deleteCustomer = () =>
  router.delete(
    '/:id',
    // validator(),
    // validator.params(deleteMusicianParamsSchema),
    mainAuthMiddleware,
    handleError(deleteCustomerHandler),
  );

export const get = () =>
  router.get('/:id', validator.params(getCustomerBodySchema), mainAuthMiddleware, handleError(getCustomer));

export const getAdress = () =>
  router.post('/getAdress/:id', validator.body(getAdressBodySchema), mainAuthMiddleware, handleError(getAdressHandler));

export const edit: any = () =>
  router.patch(
    '/:id',
    s3FileUpload.single('image'),
    validator.body(editCustomerBodySchema),
    mainAuthMiddleware,
    handleError(editCustomerHandler),
  );

export const exportCustomer = () => router.get('/export', mainAuthMiddleware, handleError(exportHandler));
