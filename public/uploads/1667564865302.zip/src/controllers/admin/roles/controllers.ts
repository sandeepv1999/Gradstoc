import Joi = require('@hapi/joi');
import * as _ from 'lodash';
import { RequestHandler, Router } from 'express';
import { createValidator, ValidatedRequestSchema, ContainerTypes, ValidatedRequest } from 'express-joi-validation';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';

import { AuthItems } from '../../../models/authItems.model';
import { reOrder } from '../../../utils/user';
import { Roles } from '../../../models/roles.model';
import { Op } from 'sequelize';

const router = Router();
const validator = createValidator();

export const authItems: RequestHandler = async (req, res) => {
  try {
    const permissions = await AuthItems.findAll();
    const data = await reOrder(permissions);
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', data },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CREATE |||| -----------------------

export const createRoleBodySchema = Joi.object({
  role_name: Joi.string().required(),
  auth_items: Joi.string().required(),
});

interface CreateRoleRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    role_name: string;
    auth_items: string;
  };
}

export const createRoleHandler = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;

    await Roles.create({ title: body.role_name, auth_item: body.auth_items, i_by: user.id });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Role Created Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const rolesListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string().allow('', null),
});

interface RolesListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
  };
}

export const RolesListHandler: RequestHandler = async (req: ValidatedRequest<RolesListRequestSchema>, res) => {
  try {
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}
    const where = { is_deleted: 0 };
    if (body.search_text) {
      _.set(where, 'title', { [Op.like]: body.search_text });
    }

    const _Roles = await Roles.findAndCountAll({
      where: where,
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
    });

    if (_Roles.rows.length > 0) {
      if (_Roles.rows.length >= limit) {
        _Roles.rows.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', roles: _Roles, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', roles: _Roles },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

interface GetRoleRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getRoleHandler: RequestHandler = async (req: ValidatedRequest<GetRoleRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);

    const role = await Roles.findOne({ where: { id } });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', role },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| DELETE |||| -----------------------

interface DeleteRoleSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteRoleHandler: RequestHandler = async (req: ValidatedRequest<DeleteRoleSchema>, res) => {
  try {
    console.log('****************');
    const { id } = req.params;
    const user = req.userData;

    await Roles.update(
      {
        is_deleted: 1,
        u_by: user.id,
      },
      { where: { id: id } },
    );

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Role deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| EDIT |||| -----------------------

export const editRoleBodySchema = Joi.object({
  role_name: Joi.string().required(),
  auth_items: Joi.string().required(),
});

interface EditRoleRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    role_name: string;
    auth_items: string;
  };
}

export const editRoleHandler = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const { id } = req.params;

    await Roles.update(
      {
        title: body.role_name,
        auth_item: body.auth_items,
        u_by: user.id,
      },
      { where: { id: id } },
    );

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Role Updated Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE STATUS |||| -----------------------
const changeRoleStatusSchema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangeRoleStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    status: number;
  };
}

const changeRoleStatusHandler: RequestHandler = async (req: ValidatedRequest<ChangeRoleStatusSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;

    await Roles.update(
      {
        is_active: body.status,
        u_by: user.id,
      },
      { where: { id: body.id } },
    );

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Record updated successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------

export const getAllRolesHandler: RequestHandler = async (req, res) => {
  try {
    // const body = req.body;

    // const start = Number(body.start ? body.start : 0);
    // const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    // let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}
    // const where = { is_deleted: 0 };
    // if (body.search_text) {
    //   _.set(where, 'title', { [Op.like]: body.search_text });
    // }

    const _Roles = await Roles.findAndCountAll({
      where: { is_deleted: false },
      order: [['id', 'DESC']],
    });

    if (_Roles.rows.length > 0) {
      //   if (_Roles.rows.length >= limit) {
      //     _Roles.rows.pop();
      //     is_last = 0;
      //   }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', roles: _Roles },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', roles: _Roles },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------

export const getAuthItems = () => router.get('/authItems', mainAuthMiddleware, handleError(authItems));

export const createRole = () =>
  router.post('/create', validator.body(createRoleBodySchema), mainAuthMiddleware, handleError(createRoleHandler));

export const getRoles = () =>
  router.post('/', validator.body(rolesListBodySchema), mainAuthMiddleware, handleError(RolesListHandler));

export const getRole = () => router.get('/:id', mainAuthMiddleware, handleError(getRoleHandler));

export const deleteRole = () => router.delete('/:id', mainAuthMiddleware, handleError(deleteRoleHandler));

export const updateRole = () =>
  router.patch('/:id', validator.body(editRoleBodySchema), mainAuthMiddleware, handleError(editRoleHandler));

export const changeStatus = () =>
  router.post(
    '/changeStatus',
    validator.body(changeRoleStatusSchema),
    mainAuthMiddleware,
    handleError(changeRoleStatusHandler),
  );
export const getAll = () => router.get('/', mainAuthMiddleware, handleError(getAllRolesHandler));
