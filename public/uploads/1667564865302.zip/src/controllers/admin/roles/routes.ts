import { Router } from 'express';
import {
  getAuthItems,
  createRole,
  getRoles,
  getRole,
  deleteRole,
  updateRole,
  changeStatus,
  getAll,
} from './controllers';

const router = Router();

export const roles = () =>
  router.use([
    getAll(),
    getAuthItems(),
    createRole(),
    getRoles(),
    getRole(),
    deleteRole(),
    updateRole(),
    changeStatus(),
  ]);
