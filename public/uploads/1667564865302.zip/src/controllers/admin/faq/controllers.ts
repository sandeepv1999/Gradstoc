/* eslint-disable @typescript-eslint/no-explicit-any */

import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema, createValidator } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';

import { FAQ } from '../../../models/faq.model';
import { FAQTranslation } from '../../../models/faqTranslation.model';
import * as faqService from '../../../utils/faq';

const router = Router();
const validator = createValidator();

//  ---------------- |||| CREATE |||| -----------------------

export const createFAQBodySchema = Joi.object({
  // en_question: Joi.string().required(),
  // ar_question: Joi.string().required(),
  // en_answer: Joi.string().required(),
  // ar_answer: Joi.string().required(),
  languages: Joi.string(),
  actor: Joi.number().required(),
});

interface CreateFAQRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    // en_question: string;
    // ar_question: string;
    // en_answer: string;
    // ar_answer: string;
    languages: string;
    actor: number;
  };
}

export const createFAQHandler = async (req: ValidatedRequest<CreateFAQRequestSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const faqs: any[] = JSON.parse(body.languages);
    console.log(faqs);
    const FAQObj: FAQ = {} as FAQ;

    FAQObj.actor = body.actor;
    FAQObj.i_by = user.id;
    console.log(FAQObj);

    const faq = await faqService.createFaq(FAQObj);

    const data = faqs.map(elem => {
      return {
        faq_id: faq.id,
        language_code: elem.language_code,
        question: elem.question,
        answer: elem.answer,
      };
    });

    await faqService.createFaqTranslation(data);

    // await faqService.createFaqTranslation([
    //   {
    //     faq_id: faq_id.id,
    //     language_code: 'en',
    //     question: body.en_question,
    //     answer: body.en_answer,
    //   },
    //   {
    //     faq_id: faq.id,
    //     language_code: 'ar',
    //     question: body.ar_question,
    //     answer: body.ar_answer,
    //   },
    // ]);

    return res.send({
      success: 1,
      error: [],
      data: { message: 'FAQ Created Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const faqListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  actor: Joi.number().required(),
  language_code: Joi.string().required(),
});

interface FAQListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    actor: number;
    language_code: string;
  };
}

export const FAQListHandler: RequestHandler = async (req: ValidatedRequest<FAQListRequestSchema>, res) => {
  try {
    const body = req.body;

    // const start = Number(body.start ? body.start : 0);
    // const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    // let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}
    const where: any = {};

    where.is_deleted = 0;
    where.actor = body.actor;

    const FAQs = await FAQ.findAndCountAll({
      include: [
        {
          model: FAQTranslation,
          where: { language_code: body.language_code },
          as: 'translation',
        },
      ],
      where: where,
      // offset: start,
      // limit: limit,
      distinct: true,
      order: [['id', 'DESC']],
    });

    if (FAQs.rows.length > 0) {
      // if (FAQs.rows.length >= limit) {
      //   FAQs.rows.pop();
      //   is_last = 0;
      // }
      return res.send({
        success: 1,
        error: [],
        data: {
          message: 'Success',
          FAQs,
          // is_last
        },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', FAQs },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

// const getFAQBodySchema = {
//   id: Joi.string().required(),
// };

interface GetFAQRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getFAQHandler: RequestHandler = async (req: ValidatedRequest<GetFAQRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);

    const faq = await FAQ.findOne({
      include: [
        {
          model: FAQTranslation,
          as: 'translation',
        },
      ],
      where: { id },
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', faq },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| DELETE |||| -----------------------
// const deleteFaqparamsSchema = {
//   id: Joi.string().required(),
// };

interface FaqDeleteSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteFaqHandler: RequestHandler = async (req: ValidatedRequest<FaqDeleteSchema>, res) => {
  try {
    console.log('****************');
    const { id } = req.params;
    const user = req.userData;
    const faq = await faqService.updateFAQByField('id', id, {
      is_deleted: 1,
      u_by: user.id,
    });
    if (!faq) {
      return res.send({ success: 0, data: {}, error: { message: 'No record found' } });
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'FAQ deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

export const editFAQBodySchema = Joi.object({
  // en_question: Joi.string().required(),
  // ar_question: Joi.string().required(),
  // en_answer: Joi.string().required(),
  // ar_answer: Joi.string().required(),
  languages: Joi.string(),
});

interface EditFAQRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    // en_question: string;
    // ar_question: string;
    // en_answer: string;
    // ar_answer: string;
    languages: string;
  };
}

export const editFAQHandler = async (req: ValidatedRequest<EditFAQRequestSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const { id } = req.params;
    const faqs: any[] = JSON.parse(body.languages);

    console.log(body);

    const FAQObj: FAQ = {} as FAQ;

    FAQObj.u_by = user.id;

    await faqService.updateFAQByField('id', id, FAQObj);

    const data = faqs.map(elem => {
      return {
        faq_id: id,
        language_code: elem.language_code,
        question: elem.question,
        answer: elem.answer,
      };
    });
    await FAQTranslation.destroy({ where: { faq_id: id } });

    await faqService.createFaqTranslation(data);

    // await FAQTranslation.update(
    //   { question: body.en_question, answer: body.en_answer },
    //   { where: { faq_id: id, language_code: 'en' } },
    // );
    // await FAQTranslation.update(
    //   { question: body.ar_question, answer: body.ar_answer },
    //   { where: { faq_id: id, language_code: 'ar' } },
    // );

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Category Updated Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------
export const create = () =>
  router.post('/create', validator.body(createFAQBodySchema), mainAuthMiddleware, handleError(createFAQHandler));

export const list = () =>
  router.post('/', validator.body(faqListBodySchema), mainAuthMiddleware, handleError(FAQListHandler));

export const get = () =>
  router.get(
    '/:id',
    // validator.params(getMusicianBodySchema),
    mainAuthMiddleware,
    handleError(getFAQHandler),
  );

export const deleteFaq = () =>
  router.delete(
    '/:id',
    // validator.params(deleteMusicianParamsSchema),
    mainAuthMiddleware,
    handleError(deleteFaqHandler),
  );

export const edit = () =>
  router.patch(
    '/:id',
    // validator.params({ id: Joi.number().required }),
    validator.body(editFAQBodySchema),
    mainAuthMiddleware,
    handleError(editFAQHandler),
  );
