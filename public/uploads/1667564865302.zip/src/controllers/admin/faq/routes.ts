import { Router } from 'express';
import { list, get, edit, deleteFaq, create } from './controllers';

const router = Router();

export const faq = () => router.use([create(), list(), get(), edit(), deleteFaq()]);
