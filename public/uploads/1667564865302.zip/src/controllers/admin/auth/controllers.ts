/* eslint-disable @typescript-eslint/no-explicit-any */
import * as userService from '../../../utils/user';
import * as authService from '../../../utils/auth';
import { RequestHandler, Router } from 'express';
import * as Joi from '@hapi/joi';
import bcrypt from 'bcryptjs';
import * as _ from 'lodash';
import { RandomService } from '../../../services/random';
import { FileUpload } from '../../../services/fileUpload';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import { createValidator } from 'express-joi-validation';
import config from '../../../config';
import { User } from '../../../models/users.model';
import * as emailService from '../../../services/email.service';
import { Roles } from '../../../models/roles.model';
import { AuthItems } from '../../../models/authItems.model';
import { Op } from 'sequelize';
import { Settings } from '../../../models/settings.model';

const router = Router();
const validator = createValidator();
const fileUploadObj = new FileUpload(config);
const s3FileUpload = fileUploadObj.imageUploadS3();

// ---------------- |||| CREATE ROOT ADMIN |||| -----------------------
/**
 * USE FOR CREATE ROOD ADMIN FOR ADMIN PANEL.
 */

export const createRootAdminHandler: RequestHandler = async (req, res) => {
  const data = req.body;
  const saveCustomerData = await userService.createUser({
    en_full_name: data.en_full_name,
    actor: 1,
    email: data.email,
    password: data.password,
    dial_code: data.dial_code,
    phone_number: data.phone_number,
    image: data.image,
    user_language: data.user_language,
    is_notification: data.is_notification,
    is_profile_completed: data.is_profile_completed,
    is_password_created: data.is_password_created,
    email_verification_token: data.email_verification_token,
    forgot_password_token: data.forgot_password_token,
    forgot_password_token_timeout: data.forgot_password_token_timeout,
    otp: data.otp,
    is_email_verified: data.is_email_verified,
    is_phone_verified: data.is_phone_verified,
    is_suspended: data.is_suspended,
    suspension_time: data.suspension_time,
    is_active: data.is_active,
    is_deleted: data.is_deleted,
    i_by: data.i_by,
    u_by: data.u_by,
  });
  return res.send({
    success: 1,
    error: [],
    data: { message: 'success', user: saveCustomerData },
  });
};

// ---------------- |||| GET TOKEN |||| -----------------------
export const getTokenBodySchema = Joi.object({
  device_id: Joi.string(),
  device_type: Joi.string().required(),
  user_language: Joi.string(),
});

interface GetTokenRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    device_id: string;
    device_type: string;
    user_language: string;
  };
}

export const tokenHandler: RequestHandler = async (req: ValidatedRequest<GetTokenRequestSchema>, res) => {
  const data = req.body;
  const generateToken = new RandomService();
  /**
   * ---------------------------------------------
   * CREATE TOKEN
   * DESC : 64 BYTES TOKEN
   *        FIND TOKEN IN DB [USING device_id] ->
   *        IF FIND ->  SEND EXISTING TOKEN
   *        ELSE -> GENERATE NEW
   * ---------------------------------------------
   */
  if (data.device_id && data.device_type) {
    try {
      const findTokenByDeviceIdData = await authService.findTokenByDeviceID(data.device_id);
      if (_.isNil(findTokenByDeviceIdData)) {
        try {
          const createTokenData = await authService.createToken({
            device_id: data.device_id,
            device_type: data.device_type,
            access_token: generateToken.salt(),
          });
          return res.send({
            success: 1,
            error: [],
            data: { message: 'success', auth: { token: createTokenData.access_token, type: 'Bearer' } },
          });
        } catch (error) {
          return res.status(500).send({ success: 0, error: { message: error.message } });
        }
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'success', auth: { token: findTokenByDeviceIdData.access_token, type: 'Bearer' } },
      });
    } catch (error) {
      return res.status(500).send({ success: 0, error: { message: error.message } });
    }
  }

  try {
    const createTokenData = await authService.createToken({
      device_id: data.device_id,
      device_type: data.device_type,
      access_token: generateToken.salt(),
      user_language: data.user_language,
    });
    return res.send({
      success: 1,
      error: [],
      data: { message: 'success', auth: { token: createTokenData.access_token, type: 'Bearer' } },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

// ---------------- |||| LOGIN |||| -----------------------
export const loginBodySchema = Joi.object({
  email: Joi.string().required(),
  password: Joi.string().required(),
  device_type: Joi.string().required(),
  device_id: Joi.string(),
});

interface LoginRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    email: string;
    password: string;
    device_type: string;
    device_id: string;
  };
}

export const loginHandler: RequestHandler = async (req: ValidatedRequest<LoginRequestSchema>, res) => {
  const data = req.body;

  try {
    // const getUserByEmailData = await userService.getUserByField('email', data.email);

    const getUserByEmailData = await User.scope('login').findOne({ where: { email: data.email } });

    if (_.isNil(getUserByEmailData)) {
      return res.send({ success: 0, error: { message: 'User Not Found' } });
    }

    if (await bcrypt.compare(data.password, getUserByEmailData.password)) {
      // ADD USER ID & TOKEN  IN TOKEN TABLE
      const generateToken = new RandomService();
      const token = generateToken.salt();
      await authService.createToken({
        access_token: token,
        user_id: getUserByEmailData.id,
        device_type: data.device_type,
        device_id: data.device_id,
      });
      const settings = await Settings.findOne({ where: { key: 'page_size' } });
      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: 'success',
          auth: { token: token, type: 'Bearer' },
          user: { data: getUserByEmailData },
          settings,
        },
      });
    } else {
      return res.status(200).send({ success: 0, error: { message: 'Invalid Password' } });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

export const logoutHandler: RequestHandler = async (req, res) => {
  try {
    const tokenWithType: any = req.headers['authorization'] ? req.headers['authorization'] : null;
    const token = tokenWithType ? tokenWithType.split(' ')[1] : null;
    const logout = await authService.destroyToken(token);
    if (logout) {
      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: 'logout successfully',
        },
      });
    } else {
      return res.status(403).send({
        success: 0,
        error: {
          message: 'already logout',
        },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

// ---------------- |||| CHANGE PASSWORD |||| -----------------------
export const changePasswordBodySchema = Joi.object({
  old_password: Joi.string().required(),
  new_password: Joi.string().required(),
});

interface ChangePasswordRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    old_password: string;
    new_password: string;
  };
}

export const changePasswordHandler: RequestHandler = async (
  req: ValidatedRequest<ChangePasswordRequestSchema>,
  res,
) => {
  try {
    const data = req.body;
    const userData = req.userData;

    if (await authService.comparePassword(data.old_password, userData.password)) {
      const newPassword = await authService.encryptPassword(data.new_password);
      const userUpdatedData = await userService.updateUserByField('id', userData.id, {
        password: newPassword,
      });
      if (!userUpdatedData) {
        return res.send({ success: 0, error: { message: 'User Not Found' } });
      } else {
        return res.status(200).send({
          success: 1,
          error: [],
          data: {
            message: 'Password changed successfully',
          },
        });
      }
    } else {
      return res.status(403).send({
        success: 0,
        error: { message: 'You have entered wrong old password.' },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};
// ---------------- |||| GET PROFILE |||| -----------------------

export const profileHandler: RequestHandler = async (req, res) => {
  const userData = req.userData;
  let permissions = [];
  await User.findOne({
    include: [
      {
        model: Roles,
        as: 'roles',
      },
    ],
    where: { id: userData.id },
  }).then(async user => {
    permissions = user.roles
      ? user.roles.auth_item.split(',').map(x => {
          return parseInt(x);
        })
      : [];

    console.log('********************');
    console.log(permissions);
    console.log('********************');

    const authItems = await AuthItems.findAll({ where: { id: { [Op.in]: permissions } } });
    const settings = await Settings.findOne({ where: { key: 'page_size' } });
    const data: any = user.toJSON();
    data.permissions = authItems;

    return res.send({
      success: 1,
      error: [],
      data: {
        message: 'success',
        user: { data },
        settings,
      },
    });
  });
};

// ---------------- |||| EDIT PROFILE [ADMIN] |||| -----------------------

export const editAdminBodySchema = Joi.object({
  en_full_name: Joi.string().required(),
  phone_number: Joi.string().required(),
  image: Joi.string(),
});

interface EditAdminProfileRequestSchema1 extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    en_full_name: string;
    phone_number: string;
  };
  file: any;
}

export const editAdminProfileHandler: RequestHandler = async (req: any, res: any) => {
  const data = req.body;
  const userData = req.userData;
  const dataObj: any = {
    en_full_name: data.en_full_name,
    phone_number: data.phone_number,
    // image: req.file ? req.file.location : ,
  };

  if (req.file) {
    dataObj.image = req.file.location;
  }

  const updateUserByFieldData = await userService.updateUserByField('id', userData.id, dataObj);
  return res.send({
    success: 1,
    error: [],
    data: { message: 'Profile updated successfully', user: updateUserByFieldData },
  });
};

// ---------------- |||| FORGOT PASSWORD |||| -----------------------
export const forgotPasswordBodySchema = Joi.object({
  email: Joi.string().required(),
});

interface ForgotPasswordRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    email: string;
  };
}

export const forgotPasswordHandler: RequestHandler = async (
  req: ValidatedRequest<ForgotPasswordRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const host = req.headers.host;
    const user = await User.findOne({
      where: {
        email: body.email,
      },
    });

    if (!user) {
      return res.send({ success: 0, error: { message: 'No user registered with this email' } });
    }
    const forgotPasswordToken = await userService.generateEmailToken();
    const userUpdated = await userService.updateUserByField('id', user.id, {
      forgot_password_token: forgotPasswordToken,
    });

    await emailService.sendForgotPasswordEmail(userUpdated, host);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: 'Forgot password link has been sent to your email',
      },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

// ---------------- |||| RESET PASSWORD |||| -----------------------
export const resetPasswordBodySchema = Joi.object({
  token: Joi.string().required(),
  password: Joi.string().required(),
});

interface ResetPasswordRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    token: string;
    password: string;
  };
}

export const resetPasswordHandler: RequestHandler = async (req: ValidatedRequest<ResetPasswordRequestSchema>, res) => {
  try {
    const data = req.body;

    const User = await userService.getUserByField('forgot_password_token', data.token);

    if (!User) {
      return res.send({ success: 0, error: { message: 'Fotgot password link has been expired' } });
    }

    const newPassword = await authService.encryptPassword(data.password);
    const userUpdatedData = await userService.updateUserByField('id', User.id, {
      password: newPassword,
      forgot_password_token: null,
    });
    if (!userUpdatedData) {
      return res.send({ success: 0, error: { message: 'User Not Found' } });
    } else {
      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: 'Your password has been changed successfully, Please login with new password',
          actor: User.actor,
        },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

// ---------------- |||| VERIFY EMAIL |||| -----------------------
export const verifyEmailHandler: RequestHandler = async (req, res) => {
  try {
    const { token } = req.query;

    const user = await User.findOne({
      where: {
        email_verification_token: token,
        is_deleted: 0,
      },
    });

    if (!user) {
      return res.send({ success: 0, error: { message: 'Invalid Token' } });
    }
    // const forgotPasswordToken = await userService.generateEmailToken();
    const userUpdated = await userService.updateUserByField('id', user.id, {
      email_verification_token: null,
      is_email_verified: 1,
    });

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: 'Email verified successfully.',
      },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------
export const rootAdmin: any = () => router.post('/createRootAdmin', handleError(createRootAdminHandler));
export const login: any = () => router.post('/login', validator.body(loginBodySchema), handleError(loginHandler));
export const logout: any = () => router.get('/logout', mainAuthMiddleware, handleError(logoutHandler));
export const changePassword: any = () =>
  router.post(
    '/changePassword',
    validator.body(changePasswordBodySchema),
    mainAuthMiddleware,
    handleError(changePasswordHandler),
  );

export const profile: any = () => router.get('/getProfile', mainAuthMiddleware, handleError(profileHandler));
export const editAdminProfile: any = () =>
  router.post(
    '/editAdminProfile',
    s3FileUpload.single('image'),
    validator.body(editAdminBodySchema),
    mainAuthMiddleware,
    handleError(editAdminProfileHandler),
  );
export const forgotPassword: any = () => router.post('/forgotPassword', handleError(forgotPasswordHandler));
export const resetPassword: any = () => router.post('/resetPassword', handleError(resetPasswordHandler));
export const verifyEmail: any = () => router.get('/verifyEmail', handleError(verifyEmailHandler));
