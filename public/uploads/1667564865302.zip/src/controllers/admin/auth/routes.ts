/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import {
  rootAdmin,
  login,
  logout,
  changePassword,
  profile,
  editAdminProfile,
  forgotPassword,
  resetPassword,
  verifyEmail,
} from './controllers';

const router = Router();

export const auth: any = () =>
  router.use([
    rootAdmin(),
    login(),
    logout(),
    changePassword(),
    profile(),
    editAdminProfile(),
    forgotPassword(),
    resetPassword(),
    verifyEmail(),
  ]);
