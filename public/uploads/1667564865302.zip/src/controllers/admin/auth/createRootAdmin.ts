import * as userService from '../../../utils/user';
import { RequestHandler } from 'express';

export const createRootAdmin: RequestHandler = async (req, res) => {
  const data = req.body;
  const saveCustomerData = await userService.createUser({
    en_full_name: data.en_full_name,
    actor: 1,
    email: data.email,
    password: data.password,
    dial_code: data.dial_code,
    phone_number: data.phone_number,
    image: data.image,
    user_language: data.user_language,
    is_notification: data.is_notification,
    is_profile_completed: data.is_profile_completed,
    is_password_created: data.is_password_created,
    email_verification_token: data.email_verification_token,
    forgot_password_token: data.forgot_password_token,
    forgot_password_token_timeout: data.forgot_password_token_timeout,
    otp: data.otp,
    is_email_verified: data.is_email_verified,
    is_phone_verified: data.is_phone_verified,
    is_suspended: data.is_suspended,
    suspension_time: data.suspension_time,
    is_active: data.is_active,
    is_deleted: data.is_deleted,
    i_by: data.i_by,
    u_by: data.u_by,
  });
  console.log('saveCustomerData', saveCustomerData);
  return res.send({
    success: 1,
    error: [],
    data: { message: 'success', user: saveCustomerData },
  });
};
