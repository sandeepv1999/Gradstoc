import { Router } from 'express';
import { users, send, getSentNotifications, getRecivedNotifications, deleteNotification } from './controllers';

const router = Router();

export const notifications = () =>
  router.use([users(), send(), getSentNotifications(), getRecivedNotifications(), deleteNotification()]);
