/* eslint-disable @typescript-eslint/no-explicit-any */
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import { User } from '../../../models/users.model';
import { Sequelize, Transaction, Op } from 'sequelize';
import { forEach } from 'p-iteration';
import { Notifications } from '../../../models/notification.model';
import { NotificationTranslation } from '../../../models/notificationTranslation.model';
import * as pushService from '../../../services/notification.service';
import { Actors, BookingStatus, BookingType, LanguageCodes, PushNotificaitonTypes } from '../../../utils/constants';

import { setUpSequelize } from '../../../db/sql/connection';
const router = Router();
const validator = createValidator();
const sequelize: Sequelize = setUpSequelize();

//  ---------------- |||| GET ALL USERS BY ACTOR |||| -----------------------

export const getUsersBodySchema = Joi.object({
  start: Joi.number(),
  limit: Joi.number(),
  actor: Joi.number(),
  user_ids: Joi.string()
    .allow('')
    .allow(null),
});

interface GetAllUsersRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    actor: number;
    user_ids: string;
  };
}

export const getAllUsers: RequestHandler = async (req: ValidatedRequest<GetAllUsersRequestSchema>, res) => {
  try {
    const body = req.body;

    // const start = Number(body.start ? body.start : 0);
    // const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    const is_last = 1;

    const where: any = { is_deleted: 0 };

    // const where: any = {};

    if (body.actor) {
      where.actor = body.actor;
    }

    if (body.user_ids) {
      const ids = body.user_ids.split(',').map(x => {
        return parseInt(x);
      });
      where.id = { [Op.in]: ids };
    }

    const users = await User.findAndCountAll({
      where: where,
      order: [['id', 'DESC']],
      attributes: ['id', 'en_full_name', 'image'],
    });

    if (users.rows.length > 0) {
      // if (users.rows.length >= limit) {
      //   users.rows.pop();
      //   is_last = 0;
      // }

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', users, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', users },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| Send Notification |||| -----------------------

export const sendNotificationBodySchema = Joi.object({
  notify: Joi.number().required(),
  users: Joi.string().allow(null, ''),
  en_title: Joi.string(),
  ar_title: Joi.string(),
  en_content: Joi.string(),
  ar_content: Joi.string(),
});

interface SendNotificationRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    notify: number;
    users: string;
    en_title: string;
    ar_title: string;
    en_content: string;
    ar_content: string;
  };
}

export const sendNotification: RequestHandler = async (req: ValidatedRequest<SendNotificationRequestSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;

    let where: any;
    let pushData = [];
    const UserIds = [],
      notificationData = [],
      deviceIds = [];
    if (body.notify == 1 || body.notify == 2) {
      where = { is_deleted: 0, actor: body.notify == 1 ? 3 : 4 };
    }
    if (body.notify == 3 || body.notify == 4) {
      // body.notify -> 3 -> Customer and 4 -> Musician
      where = { is_deleted: 0, actor: body.notify };
      const users = body.users
        ? body.users.split(',').map(x => {
            return parseInt(x);
          })
        : [];
      where.id = { [Op.in]: users };
    }

    const Users: User[] = await User.scope('withToken').findAll({ where });

    if (Users) {
      await forEach(Users, async user => {
        UserIds.push(user.id);
        await forEach(user.tokens, async token => {
          deviceIds.push(token.device_id);
        });
      });
    }

    // const notification = await Notifications.create({
    //   from_id: user.id,
    //   receiver_ids: UserIds.join(),
    //   to_type: req.body.notify,
    //   notification_type: 'admin_notification',
    //   redirection_id: 0,
    //   i_by: user.id,
    // });

    // await NotificationTranslation.bulkCreate([
    //   {
    //     notification_id: notification.id,
    //     language_code: 'en',
    //     title: body.en_title,
    //     message: body.en_content,
    //   },
    //   {
    //     notification_id: notification.id,
    //     language_code: 'ar',
    //     title: body.ar_title,
    //     message: body.ar_content,
    //   },
    // ]);
    //send push

    pushData['title'] = body.ar_title;
    pushData['body'] = body.ar_content;
    pushData['message'] = body.ar_content;
    pushData['language_code'] = 'ar';
    pushData['notification_type'] = 'admin_notification';
    notificationData.push(pushData);
    pushData = [];
    pushData['title'] = body.en_title;
    pushData['body'] = body.en_content;
    pushData['message'] = body.en_content;
    pushData['language_code'] = 'en';
    pushData['notification_type'] = 'admin_notification';
    notificationData.push(pushData);

    await pushService.sendNotification(
      PushNotificaitonTypes.ADMIN_NOTIFICATION,
      UserIds,
      null,
      null,
      1,
      notificationData,
    );
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Notification Sent Successfully', Users },
    });
    // });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET NOTIFICATION LIST |||| -----------------------

export const sentNotificationListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
});

interface SentNotificationListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
  };
}

export const sentNotificationList: RequestHandler = async (
  req: ValidatedRequest<SentNotificationListRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const user = req.userData;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}

    const where: any = {
      is_deleted: 0,
      from_id: user.id,
      [Op.and]: [Sequelize.where(Sequelize.fn('!FIND_IN_SET', user.id, Sequelize.col('deleted_by')), { [Op.gte]: 1 })],
    };
    let translateWhere: any = {};

    if (body.search_text && body.search_text != null) {
      translateWhere = {
        [Op.or]: [
          { title: { [Op.like]: '%' + body.search_text + '%' } },
          { message: { [Op.like]: '%' + body.search_text + '%' } },
        ],
      };
    }

    const notifications = await Notifications.findAndCountAll({
      where: where,
      include: [{ model: NotificationTranslation, as: 'translation', where: translateWhere }],
      order: [['id', 'DESC']],
      offset: start,
      limit: limit,
      distinct: true,
    });

    if (notifications.rows.length > 0) {
      if (notifications.rows.length >= limit) {
        notifications.rows.pop();
        is_last = 0;
      }

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', notifications, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', notifications },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET NOTIFICATION LIST |||| -----------------------

export const recivedNotificationListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  is_read: Joi.allow(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  // page: Joi.number().allow('', null),
});

interface RecivedNotificationListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    is_read: number;
    search_text: string;
    // page: number;
  };
}

export const recivedNotificationList: RequestHandler = async (
  req: ValidatedRequest<RecivedNotificationListRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const user = req.userData;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;
    const where: any = {
      is_deleted: 0,
      [Op.and]: [
        Sequelize.where(Sequelize.fn('FIND_IN_SET', user.id, Sequelize.col('receiver_ids')), { [Op.gte]: 1 }),
        Sequelize.where(Sequelize.fn('!FIND_IN_SET', user.id, Sequelize.col('deleted_by')), { [Op.gte]: 1 }),
      ],
    };
    let translateWhere: any = {};

    if (body.search_text && body.search_text != null) {
      translateWhere = {
        [Op.or]: [
          { title: { [Op.like]: '%' + body.search_text + '%' } },
          { message: { [Op.like]: '%' + body.search_text + '%' } },
        ],
      };
    }

    // where = {
    //   ...where,
    //   [Op.and]: [
    //     // Sequelize.where(Sequelize.col('message'), { [Op.like]: `%${body.search_text.trim()}%` }),
    //     Sequelize.where(Sequelize.fn('FIND_IN_SET', user.id, Sequelize.col('receiver_ids')), { [Op.gte]: 1 }),
    //     Sequelize.where(Sequelize.fn('!FIND_IN_SET', user.id, Sequelize.col('deleted_by')), { [Op.gte]: 1 }),
    //   ],
    // };
    // _.set(where, [Op.and], [{ message: { [Op.like]: '%' + body.search_text + '%' } }]);

    const notifications = await Notifications.findAndCountAll({
      where: where,
      include: [{ model: NotificationTranslation, as: 'translation', where: translateWhere }],
      // attributes: [
      //   'id',
      //   'notification_type',
      //   'redirection_id',

      //   'createdAt',
      //   [Sequelize.fn('FIND_IN_SET', user.id, Sequelize.col('read_by')), 'is_read'],
      // ],
      order: [['id', 'DESC']],
      offset: start,
      limit: limit,
      distinct: true,
    });
    console.log('notifications.rows.length', notifications);
    // const notificationList = [];
    // await forEach(notifications.rows, (notification: any) => {
    //   notificationList.push({
    //     id: notification.id,
    //     notification_type: notification.notification_type,
    //     redirection_id: notification.redirection_id,
    //     is_read: notification.get('is_read'),
    //     title: notification.title,
    //     message: notification.message,
    //     createdAt: notification.createdAt,
    //   });
    // });

    // const page = {
    //   start: Number(body.page - 1) * req.pageSize ? Number(body.page - 1) * req.pageSize : 1,
    //   end: (Number(body.page - 1) * req.pageSize ? Number(body.page - 1) * req.pageSize : 0) + notifications.rows.length,
    //   totalEntrys: notifications.count,
    // };

    if (notifications.rows.length > 0) {
      if (notifications.rows.length >= limit) {
        notifications.rows.pop();
        is_last = 0;
      }

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', notifications, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', notifications },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};
//  ---------------- |||| GET NOTIFICATION LIST |||| -----------------------

export const deleteRecivedNotificationsSchema = Joi.object({
  ids: Joi.string().required(),
});

interface DeleteRecivedNotificationsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    ids: string;
  };
}

export const deleteNotifications: RequestHandler = async (
  req: ValidatedRequest<DeleteRecivedNotificationsRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const user = req.userData;
    const Ids = body.ids.split(',');

    const notifications = await Notifications.findAll({
      where: {
        id: { [Op.in]: Ids },
      },
    });

    const updatedNotifications = notifications.map(notifications => {
      return {
        id: notifications.id,
        from_id: notifications.from_id,
        receiver_ids: notifications.receiver_ids,
        to_type: notifications.to_type,
        notification_type: notifications.notification_type,
        redirection_id: notifications.redirection_id,
        read_by: notifications.read_by,
        deleted_by: notifications.deleted_by ? notifications.deleted_by + ',' + user.id : user.id,
        i_by: notifications.i_by,
        u_by: user.id,
        createdAt: notifications.createdAt,
        updatedAt: new Date(),
      };
    });

    if (notifications.length > 0) {
      await Notifications.destroy({
        where: { id: { [Op.in]: Ids } },
      });

      await Notifications.bulkCreate(updatedNotifications);
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success' },
    });
  } catch (error) {
    return res.send({
      success: 0,
      error: [],
      data: { message: 'No records found' },
    });
  }
};
//  ---------------- |||| ROUTES |||| -----------------------

export const users = () =>
  router.post('/getUsers', validator.body(getUsersBodySchema), mainAuthMiddleware, handleError(getAllUsers));
export const getSentNotifications = () =>
  router.post(
    '/sent',
    validator.body(sentNotificationListBodySchema),
    mainAuthMiddleware,
    handleError(sentNotificationList),
  );
export const send = () =>
  router.post('/', validator.body(sendNotificationBodySchema), mainAuthMiddleware, handleError(sendNotification));

export const getRecivedNotifications = () =>
  router.post(
    '/receive',
    validator.body(recivedNotificationListBodySchema),
    mainAuthMiddleware,
    handleError(recivedNotificationList),
  );

export const deleteNotification = () =>
  router.post(
    '/delete',
    validator.body(deleteRecivedNotificationsSchema),
    mainAuthMiddleware,
    handleError(deleteNotifications),
  );
