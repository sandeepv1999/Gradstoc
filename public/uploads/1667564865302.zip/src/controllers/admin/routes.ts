import { Router } from 'express';
import { auth } from './auth/routes';
import { musician } from './musician/routes';
import { customer } from './customer/routes';
import { category } from './category/routes';
import { booking } from './booking/routes';
import { reasons } from './resons/routes';
import { cms } from './cms/routes';
import { faq } from './faq/routes';
import { settings } from './settings/routes';
import { banners } from './app-banners/routes';
import { notifications } from './notification/routes';
import { subAdmin } from './sub-admin/routes';
import { roles } from './roles/routes';
import { common } from '../mobile/v1/common/routes';

const router = Router();

router.use('/auth', auth());
router.use('/musician', musician());
router.use('/category', category());
router.use('/customer', customer());
router.use('/reasons', reasons());
router.use('/cms', cms());
router.use('/faq', faq());
router.use('/settings', settings());
router.use('/banners', banners());
router.use('/notifications', notifications());
router.use('/subAdmin', subAdmin());
router.use('/common', common());
router.use('/booking', booking());

router.use('/roles', roles());

router.get('/status', (req, res) => res.json({ status: 'ADMIN UP' }));
export default router;
