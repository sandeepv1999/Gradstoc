import * as Joi from '@hapi/joi';
import { ValidatedRequestSchema, ContainerTypes, ValidatedRequest, createValidator } from 'express-joi-validation';
import * as reasonsService from '../../../utils/reasons';
import { RequestHandler, Router } from 'express';
import { Reason } from '../../../models/reason.model';
import { Op } from 'sequelize';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import handleError from '../../../middlewares/handle-error';

const router = Router();
const validator = createValidator();

//  ---------------- |||| CREATE |||| -----------------------
export const createReasonBodySchema = Joi.object({
  reason: Joi.string().required(),
  type: Joi.number().required(),
  actor: Joi.number(),
});

interface CreateReasonRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    reason: string;
    type: number;
    actor: number;
  };
}

export const createReason = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;

    const obj = {
      actor: body.actor,
      reason: body.reason,
      type: body.type,
      i_by: user.id,
    };

    await reasonsService.createReason(obj);

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Reason Created Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| EDIT |||| -----------------------
export const editReasonBodySchema = Joi.object({
  reason: Joi.string().required(),
  type: Joi.number().required(),
  actor: Joi.number(),
});

interface EditReasonRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    reason: string;
    type: number;
    actor: number;
  };
}

export const editReason = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const { id } = req.params;

    const obj = {
      actor: body.actor,
      reason: body.reason,
      type: body.type,
      u_by: user.id,
    };

    await reasonsService.updateReasonByField('id', id, obj);

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Reason Updated Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const reasonsListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
  type: Joi.number()
    .required()
    .allow(null),
  actor: Joi.number().allow(null),
});

interface ReasonsListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
    type: number;
    actor: number;
  };
}

export const reasonsList: RequestHandler = async (req: ValidatedRequest<ReasonsListRequestSchema>, res) => {
  try {
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    /* eslint-disable @typescript-eslint/no-explicit-any */
    const where: any = {};

    where.is_deleted = 0;
    where.type = body.type;

    if (body.statusFilter) {
      where.is_active = { [Op.eq]: body.statusFilter };
    }
    if (body.search_text) {
      // where.reason = { [Op.eq]: body.search_text };
      where.reason = { [Op.like]: '%' + body.search_text + '%' };
    }

    if (body.actor) {
      where.actor = body.actor;
    }

    const reasons = await Reason.findAndCountAll({
      where: where,
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
    });

    if (reasons.rows.length > 0) {
      if (reasons.rows.length >= limit) {
        reasons.rows.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', reasons, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No Record found', reasons, is_last },
      });
      // return res.status(404).send({ success: 0, error: { message: 'No record found' } });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

// const getReasonsBodySchema = Joi.object({
//   id: Joi.string().required(),
// });

interface GetReasonsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getReason: RequestHandler = async (req: ValidatedRequest<GetReasonsRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);

    const reason = await Reason.findOne({
      where: { id },
    });

    if (!reason) {
      return res.send({ success: 0, error: { message: 'No record found' } });
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', reason },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| DELETE |||| -----------------------
// const deleteReasonParamsSchema = {
//   id: Joi.string().required(),
// };

interface ReasonDeleteSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteReasonHandler: RequestHandler = async (req: ValidatedRequest<ReasonDeleteSchema>, res) => {
  try {
    const { id } = req.params;
    const user = req.userData;
    const reason = await reasonsService.updateReasonByField('id', id, {
      is_deleted: 1,
      u_by: user.id,
    });
    if (!reason) {
      return res.send({ success: 0, error: { message: 'No record found' } });
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Reason deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE STATUS |||| -----------------------
const changeReasonStatusSchema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangeReasonStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    status: number;
  };
}

const changeReasonStatusHandler: RequestHandler = async (req: ValidatedRequest<ChangeReasonStatusSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const Reason = await reasonsService.updateReasonByField('id', body.id, {
      is_active: body.status,
      u_by: user.id,
    });
    if (!Reason) {
      return res.send({ success: 0, error: { message: 'No record found' } });
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Record updated successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------
export const create = () =>
  router.post('/create', validator.body(createReasonBodySchema), mainAuthMiddleware, handleError(createReason));

export const list = () =>
  router.post('/', validator.body(reasonsListBodySchema), mainAuthMiddleware, handleError(reasonsList));
export const get = () =>
  router.get(
    '/:id',
    // validator.params(getReasonsBodySchema),
    mainAuthMiddleware,
    handleError(getReason),
  );
export const deleteMusician = () =>
  router.delete(
    '/:id',
    // validator.params(deleteMusicianParamsSchema),
    mainAuthMiddleware,
    handleError(deleteReasonHandler),
  );

export const changeStatus = () =>
  router.post(
    '/changeStatus',
    validator.body(changeReasonStatusSchema),
    mainAuthMiddleware,
    handleError(changeReasonStatusHandler),
  );

export const edit = () =>
  router.patch(
    '/:id',
    // validator.params({ id: Joi.number().required }),
    validator.body(editReasonBodySchema),
    mainAuthMiddleware,
    handleError(editReason),
  );
