import { Router } from 'express';
import { create, list, get, deleteMusician, changeStatus, edit } from './controllers';

const router = Router();

export const reasons = () => router.use([create(), list(), get(), deleteMusician(), changeStatus(), edit()]);
