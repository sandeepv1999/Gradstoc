import { Router } from 'express';
import { create, list, get, deleteCategory, edit, changeStatus, getAll } from './controllers';

const router = Router();

export const category = () => router.use([create(), list(), get(), deleteCategory(), edit(), changeStatus(), getAll()]);
