/* eslint-disable @typescript-eslint/no-explicit-any */

import * as categoryService from '../../../utils/category';
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import { FileUpload } from '../../../services/fileUpload';
import config from '../../../config';
import { Category } from '../../../models/category.model';
import { Op, Sequelize } from 'sequelize';
import { CategoryTranslation } from '../../../models/categoryTranslation.model';
import { Language } from '../../../models/language.model';

const router = Router();
const validator = createValidator();

const fileUploadObj = new FileUpload(config);
const s3FileUpload = fileUploadObj.imageUploadS3();

//  ---------------- |||| CREATE |||| -----------------------

export const createCategoryBodySchema = Joi.object({
  // en_name: Joi.string().required(),
  // ar_name: Joi.string().required(),
  sound: Joi.string(),
  image: Joi.string(),
  names: Joi.string(),
});

interface CreateCategoryRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    // en_name: string;
    // ar_name: string;
    sound: string;
    image: string;
    names: string;
  };
}

export const createCategoryHandler = async (req: ValidatedRequest<CreateCategoryRequestSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const categoryNames: any[] = JSON.parse(body.names);

    const categoryObj: Category = {} as Category;
    if (req.files) {
      console.log(req.files);
      categoryObj.icon_url = req.files['image'][0].location;
      categoryObj.sound_url = req.files['sound'][0].location;
    }
    categoryObj.i_by = user.id;

    const category = await categoryService.createCategory(categoryObj);

    const data = categoryNames.map(elem => {
      return {
        category_id: category.id,
        language_code: elem.language_code,
        name: elem.category_name,
      };
    });

    await categoryService.createTranslation(data);

    // await categoryService.createTranslation([
    //   {
    //     category_id: category.id,
    //     language_code: 'en',
    //     name: body.en_name,
    //   },
    //   {
    //     category_id: category.id,
    //     language_code: 'ar',
    //     name: body.ar_name,
    //   },
    // ]);

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Category Created Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const categoryListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
});

interface CategoryListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
  };
}

export const categoryListHandler: RequestHandler = async (req: ValidatedRequest<CategoryListRequestSchema>, res) => {
  try {
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}
    const where: any = {};
    let translationWhere: any = { language_code: 'en' };

    if (body.search_text && body.search_text != null) {
      translationWhere = {
        ...translationWhere,
        [Op.or]: [{ name: { [Op.like]: '%' + body.search_text + '%' } }],
      };
    }
    if (body.statusFilter != null) {
      where.is_active = { [Op.eq]: body.statusFilter };
    }
    where.is_deleted = 0;

    const categories = await Category.findAndCountAll({
      include: [
        {
          model: CategoryTranslation,
          // include: [
          //   {
          //     model: Language,
          //     as: 'language',
          //   },
          // ],
          where: translationWhere,
          as: 'translation',
          // attributes: [
          //   'id',
          //   'category_id',
          //   'language_code',
          //   'name',
          //   // [Sequelize.fn('', Sequelize.col('`translation.name`')), 'name'],
          //   // [Sequelize.fn('', Sequelize.col('`translation.language.name`')), 'language_name'],
          // ],
        },
      ],
      where: where,
      offset: start,
      limit: limit,
      distinct: true,
      subQuery: false,
      order: [['id', 'DESC']],
    });

    if (categories.rows.length > 0) {
      if (categories.rows.length >= limit) {
        categories.rows.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', categories, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', categories },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

// const getCategoryBodySchema = {
//   id: Joi.string().required(),
// };

interface GetCategoryRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getCategoryHandler: RequestHandler = async (req: ValidatedRequest<GetCategoryRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);

    // const musician = await userService.getUserByField('id', id);

    const category = await Category.findOne({
      include: [
        {
          model: CategoryTranslation,
          include: [
            {
              model: Language,
              as: 'language',
            },
          ],
          as: 'translation',
          attributes: [
            'id',
            'category_id',
            'language_code',
            // 'name',
            [Sequelize.fn('', Sequelize.col('`translation.name`')), 'name'],
            [Sequelize.fn('', Sequelize.col('`translation.language.name`')), 'language_name'],
          ],
        },
      ],
      where: { id },
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', category },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| DELETE |||| -----------------------
// const deleteCategoryaramsSchema = {
//   id: Joi.string().required(),
// };

interface CategoryDeleteSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteCategoryHandler: RequestHandler = async (req: ValidatedRequest<CategoryDeleteSchema>, res) => {
  try {
    console.log('****************');
    const { id } = req.params;
    const user = req.userData;
    const category = await categoryService.updateCategoryByField('id', id, {
      is_deleted: 1,
      u_by: user.id,
    });
    if (!category) {
      return res.send({ success: 0, data: {}, error: { message: 'No record found' } });
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Category deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE STATUS |||| -----------------------
const changeCategoryStatusSchema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangeCategoryStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    status: number;
  };
}

const changeCategoryStatusHandler: RequestHandler = async (req: ValidatedRequest<ChangeCategoryStatusSchema>, res) => {
  try {
    console.log('****************');
    const body = req.body;
    const user = req.userData;
    const musician = await categoryService.updateCategoryByField('id', body.id, {
      is_active: body.status,
      u_by: user.id,
    });
    if (!musician) {
      return res.send({ success: 0, data: {}, error: { message: 'No record found' } });
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Category deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};
//  ---------------- |||| EDIT |||| -----------------------
export const editCategoryBodySchema = Joi.object({
  // en_name: Joi.string().required(),
  // ar_name: Joi.string().required(),
  sound: Joi.string(),
  image: Joi.string(),
  names: Joi.string(),
});

interface EditCategoryRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    // en_name: string;
    // ar_name: string;
    sound: string;
    image: string;
    names: string;
  };
}

export const editCategoryHandler = async (req: ValidatedRequest<EditCategoryRequestSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const { id } = req.params;

    const categoryNames: any[] = JSON.parse(body.names);

    // console.log(req.file.location);

    console.log(req.files);
    console.log(body);

    const categoryObj: Category = {} as Category;
    if (req.files) {
      console.log(req.files);
      categoryObj.icon_url = req.files['image'] ? req.files['image'][0].location : body.image;
      categoryObj.sound_url = req.files['sound'] ? req.files['sound'][0].location : body.sound;
    }
    categoryObj.u_by = user.id;

    await categoryService.updateCategoryByField('id', id, categoryObj);

    const data = categoryNames.map(elem => {
      return {
        category_id: id,
        language_code: elem.language_code,
        name: elem.category_name,
      };
    });

    await CategoryTranslation.destroy({ where: { category_id: id } });

    await categoryService.createTranslation(data);

    // await CategoryTranslation.update({ name: body.en_name }, { where: { category_id: id, language_code: 'en' } });
    // await CategoryTranslation.update({ name: body.ar_name }, { where: { category_id: id, language_code: 'ar' } });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Category Updated Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET ALL CATEGORIES |||| -----------------------

export const getAllCategories = async (req, res) => {
  try {
    console.log('*************');
    const categories = await Category.findAndCountAll({
      include: [
        {
          model: CategoryTranslation,
          where: { language_code: 'en' },
          as: 'translation',
        },
      ],
      where: { is_active: 1, is_deleted: 0 },
      order: [['id', 'DESC']],
    });
    const arrCategories = [];

    categories.rows.map(elem => {
      const data = {
        id: elem.id,
        name: elem.translation[0].name,
      };
      arrCategories.push(data);
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', categories: arrCategories },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------
export const create = () =>
  router.post(
    '/create',
    s3FileUpload.fields([
      { name: 'image', maxCount: 1 },
      { name: 'sound', maxCount: 1 },
    ]),
    validator.body(createCategoryBodySchema),
    mainAuthMiddleware,
    handleError(createCategoryHandler),
  );

export const list = () =>
  router.post('/', validator.body(categoryListBodySchema), mainAuthMiddleware, handleError(categoryListHandler));

export const get = () =>
  router.get(
    '/:id',
    // validator.params(getMusicianBodySchema),
    mainAuthMiddleware,
    handleError(getCategoryHandler),
  );

export const deleteCategory = () =>
  router.delete(
    '/:id',
    // validator.params(deleteMusicianParamsSchema),
    mainAuthMiddleware,
    handleError(deleteCategoryHandler),
  );

export const changeStatus = () =>
  router.post(
    '/changeStatus',
    validator.body(changeCategoryStatusSchema),
    mainAuthMiddleware,
    handleError(changeCategoryStatusHandler),
  );

export const edit = () =>
  router.patch(
    '/:id',
    s3FileUpload.fields([
      { name: 'image', maxCount: 1 },
      { name: 'sound', maxCount: 1 },
    ]),
    // validator.params({ id: Joi.number().required }),
    validator.body(editCategoryBodySchema),
    mainAuthMiddleware,
    handleError(editCategoryHandler),
  );

export const getAll = () => router.post('/getAllCategories', mainAuthMiddleware, handleError(getAllCategories));
