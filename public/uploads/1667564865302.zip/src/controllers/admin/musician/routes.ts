import { Router } from 'express';
import {
  create,
  list,
  get,
  deleteReview,
  deleteMusician,
  changeStatus,
  changeSuspension,
  edit,
  getPortfolios,
  changePortfolioStatus,
  exportMusician,
  getRatings,
  paymentmanagementList,
  paymentrequestList,
  acceptPaymentRequest,
  paymentHistoryList,
} from './controllers';

const router = Router();

export const musician = () =>
  router.use([
    create(),
    list(),
    exportMusician(),
    get(),
    deleteReview(),
    deleteMusician(),
    changeStatus(),
    changeSuspension(),
    edit(),
    getPortfolios(),
    getRatings(),
    changePortfolioStatus(),
    paymentmanagementList(),
    paymentrequestList(),
    acceptPaymentRequest(),
    paymentHistoryList(),
  ]);
