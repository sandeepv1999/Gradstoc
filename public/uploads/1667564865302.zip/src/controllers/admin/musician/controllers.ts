/* eslint-disable @typescript-eslint/no-explicit-any */
import * as userService from '../../../utils/user';
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import { FileUpload } from '../../../services/fileUpload';
import config from '../../../config';
import { User } from '../../../models/users.model';
import { NotFoundError } from '../../../errors';
import moment from 'moment';
import { Op, Sequelize } from 'sequelize';
import * as _ from 'lodash';
import { setUpSequelize } from '../../../db/sql/connection';
import * as emailService from '../../../services/email.service';
import { CategoryTranslation } from '../../../models/categoryTranslation.model';
import { MusicianPortfolio } from '../../../models/musicianPortfolio.model';
import { UserAddress } from '../../../models/userAddresses.model';
import { UserDetails } from '../../../models/userDetails.model';

import { forEach } from 'p-iteration';
import { MusicianCategories } from '../../../models/musicianCategories.model';
import { Rating } from '../../../models/rating.model';
import { Category } from '../../../models/category.model';
import {
  Languages,
  LanguageCodes,
  MusicianPaymentRequest,
  PushNotificaitonTypes,
  Actors,
} from '../../../utils/constants';
import { PaymentRequest } from '../../../models/paymentRequest.model';
import { MusicianPayments } from '../../../models/musicianPayments.model';
import * as pushService from '../../../services/notification.service';
import * as authService from '../../../utils/auth';

const sequelize: Sequelize = setUpSequelize();
const router = Router();
const validator = createValidator();

const fileUploadObj = new FileUpload(config);
const s3FileUpload = fileUploadObj.imageUploadS3();

//  ---------------- |||| CREATE |||| -----------------------

export const createMusicianBodySchema = Joi.object({
  en_full_name: Joi.string().required(),
  email: Joi.string().required(),
  password: Joi.string().required(),
  phone_number: Joi.string().required(),
  categories: Joi.string(),
  can_set_price: Joi.boolean(),
  can_set_price_type: Joi.number(),
  hourly_price: Joi.number(),
  fixed_price: Joi.number(),
  image: Joi.string()
    .allow('')
    .allow(null),
  dial_code: Joi.string(),
});

interface CreateMusicianRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    en_full_name: string;
    email: string;
    password: string;
    phone_number: string;
    categories: string;
    can_set_price: boolean;
    can_set_price_type: number;
    hourly_price: number;
    fixed_price: number;
    image: string;
    dial_code: string;
  };
}

export const createMusician = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const emailVerificationToken = await userService.generateEmailToken();

    const musician = await userService.createUser({
      en_full_name: body.en_full_name,
      actor: 4,
      email: body.email,
      password: body.password,
      dial_code: body.dial_code ? body.dial_code : '+966',
      phone_number: body.phone_number,
      image: req.file ? req.file.location : null,
      // email_verification_token: emailVerificationToken,
      is_email_verified: 1,
      i_by: user.id,
    });

    await userService.createUserDetails({
      user_id: musician.id,
      hourly_rate: body.hourly_price ? body.hourly_price : 0,
      fix_rate: body.fixed_price ? body.fixed_price : 0,
      can_set_price: body.can_set_price,
      can_set_price_type: body.can_set_price_type,
      categories: body.categories,
      i_by: user.id,
      u_by: user.id,
    });

    const categories = body.categories.split(',');
    const data = [];
    categories.forEach(element => {
      data.push({
        musician_id: musician.id,
        category_id: element,
      });
    });

    await userService.createMusicianCategories(data);

    emailService.sendMusicianRegistrationEmail(body, 'registration_musician');

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Musician Created Successfully' },
    });
  } catch (error) {
    return res.status(500).send({
      success: 0,
      error: { message: error.message },
      data: {},
    });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const musicianListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
  suspensionFilter: Joi.number().allow(null),
  start_date: Joi.string().allow('', null),
  end_date: Joi.string().allow('', null),
});

interface MusicianListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
    suspensionFilter: string;
    start_date: string;
    end_date: string;
  };
}

export const musicianList: RequestHandler = async (req: ValidatedRequest<MusicianListRequestSchema>, res) => {
  try {
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}

    let where: any = {};

    if (body.search_text && body.search_text != null) {
      where = {
        [Op.or]: [
          { en_full_name: { [Op.like]: '%' + body.search_text + '%' } },
          { email: { [Op.like]: '%' + body.search_text + '%' } },
          { phone_number: { [Op.like]: '%' + body.search_text + '%' } },
        ],
      };
    }
    if (body.statusFilter != null) {
      where.is_active = { [Op.eq]: body.statusFilter };
    }
    if (body.suspensionFilter != null) {
      where.is_suspended = { [Op.eq]: body.suspensionFilter };
    }

    if (body.start_date && body.end_date) {
      // where.createdAt = { [Op.between]: [body.start_date, body.end_date] };
      where.createdAt = {
        [Op.and]: [
          Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`User`.`createdAt`'), '%Y-%m-%d'), {
            [Op.gte]: body.start_date,
          }),
          Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`User`.`createdAt`'), '%Y-%m-%d'), {
            [Op.lte]: body.end_date,
          }),
        ],
      };
    }

    where.is_deleted = 0;
    where.actor = 4;

    const musicians = await User.findAndCountAll({
      where: where,
      include: [
        { model: UserAddress, as: 'addresses', where: { is_active: 1, is_deleted: 0, is_default: 1 }, required: false },
        {
          model: UserDetails,
          as: 'details',
          required: false,
        },
        // {
        //   model: MusicianCategories,
        //   as: 'musician_categories',
        //   include: [
        //     {
        //       model: Category,
        //       as: 'category',
        //       where: { is_deleted: 0, is_active: 1 },
        //       include: [
        //         {
        //           model: CategoryTranslation,
        //           where: { language_code: LanguageCodes.ENGLISH },
        //           as: 'translation',
        //         },
        //       ],
        //     },
        //   ],
        //   // include: [
        //   //   {
        //   //     model: CategoryTranslation,
        //   //     where: { language_code: 'en' },
        //   //     as: 'category',
        //   //     required: false,
        //   //   },
        //   // ],
        //   required: false,
        // },
      ],
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
      distinct: true,
    });

    if (musicians.rows.length > 0) {
      if (musicians.rows.length >= limit) {
        musicians.rows.pop();
        is_last = 0;
      }
      const _musicians = { count: musicians.count, rows: [] };

      // await forEach(musicians.rows, async element => {
      //   const _element: any = element.toJSON();
      //   const categories = [];
      //   element.musician_categories.forEach((elem: any) => {
      //     categories.push(elem.category.translation[0].name);
      //   });
      //   _element.categort_name = categories.toString();
      //   delete _element['musician_categories'];
      //   _musicians.rows.push(_element);
      // });

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', musicians: musicians, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', musicians },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

// const getMusicianBodySchema = {
//   id: Joi.string().required(),
// };

interface GetMusicianRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getMusician: RequestHandler = async (req: ValidatedRequest<GetMusicianRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);
    const include = ['address', 'userdetails', 'musician_categories', 'bankdetails'];
    const musician = await userService.getUserByField('id', id, include);

    if (!musician) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', data: {} },
      });
    }
    const musicianData = musician.toJSON();
    const categories = [];
    musician.musician_categories.forEach((elem: any) => {
      categories.push(elem.category.translation[0].name);
    });
    _.set(musicianData, 'categories', categories);

    const outstandingMusicians = await User.findOne({
      where: { id: id },
      attributes: [
        [
          Sequelize.literal(
            '(SELECT SUM(outstanding_amount	) FROM musician_payments WHERE musician_id = User.id AND is_deleted = 0)',
          ),
          'outstanding_amount',
        ],
      ],
    });
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', musician: musicianData, outstanding_amount: outstandingMusicians },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| DELETE |||| -----------------------
// const deleteMusicianParamsSchema = {
//   id: Joi.string().required(),
// };

interface MusicianDeleteSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteMusicianHandler: RequestHandler = async (req: ValidatedRequest<MusicianDeleteSchema>, res) => {
  try {
    console.log('****************');
    const { id } = req.params;
    const user = req.userData;
    await userService.updateUserByField('id', id, {
      is_deleted: 1,
      u_by: user.id,
    });
    // if (!musician) {
    //   throw new NotFoundError();
    // }
    //delete token of this user
    //send push
    await pushService.sendNotification(
      PushNotificaitonTypes.USER_DELETE,
      [Number(id)],
      Actors.Musician,
      null,
      user.id,
      null,
    );
    //delete token
    let firebaseIds = await authService.getAllUserTokens([Number(id)]);
    console.log(firebaseIds);
    // firebaseIds.map(data => {
    // await authService.destroyToken(data);
    // });
    firebaseIds = await Promise.all(
      firebaseIds.map(
        async (elem): Promise<any> => {
          // console.log(elem);
          await authService.destroyToken(elem);
        },
      ),
    );

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Musician deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE STATUS |||| -----------------------
const changeMusicianStatusSchema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangeMusicianStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    status: number;
  };
}

const changeMusicianStatusHandler: RequestHandler = async (req: ValidatedRequest<ChangeMusicianStatusSchema>, res) => {
  try {
    console.log('****************');
    const body = req.body;
    const user = req.userData;
    const musician = await userService.updateUserByField('id', body.id, {
      is_active: body.status,
      u_by: user.id,
    });
    if (!musician) {
      throw new NotFoundError();
    }
    //delete token of this user
    if (body.status == 0) {
      //send push
      await pushService.sendNotification(
        PushNotificaitonTypes.USER_INACTIVE,
        [body.id],
        Actors.Musician,
        null,
        user.id,
        null,
      );
      //delete token
      let firebaseIds = await authService.getAllUserTokens([body.id]);
      console.log(firebaseIds);
      // firebaseIds.map(data => {
      // await authService.destroyToken(data);
      // });
      firebaseIds = await Promise.all(
        firebaseIds.map(
          async (elem): Promise<any> => {
            // console.log(elem);
            await authService.destroyToken(elem);
          },
        ),
      );
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Record updated successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE SUSPENSION |||| -----------------------
const changeMusicianSuspensionSchema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangeMusicianSuspensionSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const changeMusicianSuspensionHandler: RequestHandler = async (
  req: ValidatedRequest<ChangeMusicianSuspensionSchema>,
  res,
) => {
  try {
    console.log('****************');
    const body = req.body;
    const user = req.userData;
    let suspension_time;
    if (body.status == 1) {
      suspension_time = moment()
        .add('24', 'hours')
        .unix();
    }
    const musician = await userService.updateUserByField('id', body.id, {
      is_suspended: body.status,
      suspension_time: suspension_time,
      u_by: user.id,
    });
    if (!musician) {
      throw new NotFoundError();
    }
    //delete token of this user
    if (body.status == 1) {
      //send push
      await pushService.sendNotification(
        PushNotificaitonTypes.USER_BLOCK,
        [body.id],
        Actors.Musician,
        null,
        user.id,
        null,
      );
      //delete token
      let firebaseIds = await authService.getAllUserTokens([body.id]);
      console.log(firebaseIds);
      // firebaseIds.map(data => {
      // await authService.destroyToken(data);
      // });
      firebaseIds = await Promise.all(
        firebaseIds.map(
          async (elem): Promise<any> => {
            // console.log(elem);
            await authService.destroyToken(elem);
          },
        ),
      );
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Record updated successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| EDIT MUSICIAN |||| -----------------------

export const editMusicianBodySchema = Joi.object({
  en_full_name: Joi.string().required(),
  email: Joi.string().required(),
  // password: Joi.string().required(),
  phone_number: Joi.string().required(),
  categories: Joi.string(),
  can_set_price: Joi.boolean(),
  can_set_price_type: Joi.number(),
  hourly_price: Joi.number().allow(null),
  fixed_price: Joi.number().allow(null),
  image: Joi.string().allow(null),
  dial_code: Joi.string(),
});

interface EditMusicianRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    en_full_name: string;
    email: string;
    password: string;
    phone_number: string;
    categories: string;
    can_set_price: boolean;
    can_set_price_type: number;
    hourly_price: number;
    fixed_price: number;
    image: string;
    dial_code: string;
  };
}

export const editMusicianHandler = async (req: ValidatedRequest<EditMusicianRequestSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const { id } = req.params;
    const file: any = req.file;
    // console.log(req.file.location);

    const musician = await userService.updateUserByField('id', id, {
      en_full_name: body.en_full_name,
      email: body.email,
      dial_code: body.dial_code ? body.dial_code : '+966',
      phone_number: body.phone_number,
      image: file ? file.location : body.image == 'null' ? null : body.image,
      u_by: user.id,
    });

    const musicianDetails = await UserDetails.findOne({ where: { user_id: id } });

    console.log('***************** -> ', body.can_set_price);

    await userService.updateUserDetailsByField('user_id', id, {
      user_id: musician.id,
      hourly_rate: body.can_set_price ? musicianDetails.hourly_rate : body.hourly_price,
      fix_rate: body.can_set_price ? musicianDetails.fix_rate : body.fixed_price,
      can_set_price: body.can_set_price,
      can_set_price_type: body.can_set_price_type,
      categories: body.categories,
      u_by: user.id,
    });

    const categories = body.categories.split(',');
    const data = [];
    categories.forEach(element => {
      data.push({
        musician_id: musician.id,
        category_id: element,
      });
    });

    await userService.updateMusicianCategories(id, data);

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Musician Updated Successfully', musician },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET MUSICIAN PORTFOLIO |||| -----------------------

interface GetMusicianPortfolioRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: number;
  };
}

export const getMusicianPortfolioHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const portfolios = await userService.getAllPortfolioByMusician(id);

    if (portfolios.count == 0) {
      return res.send({
        success: 0,
        error: { message: 'No record found' },
        data: {},
      });
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', portfolios },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE PORTFOLIO STATUS |||| -----------------------
const changePortfolioStatuschema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangePortfolioStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: string;
    status: number;
  };
}

const changePortfolioStatusHandler: RequestHandler = async (
  req: ValidatedRequest<ChangePortfolioStatusSchema>,
  res,
) => {
  try {
    console.log('****************');
    const body = req.body;
    const user = req.userData;
    const portfolio = await MusicianPortfolio.findOne({
      where: { id: body.id },
    });
    await MusicianPortfolio.update(
      {
        is_approved: body.status,
        u_by: user.id,
      },
      {
        where: {
          id: body.id,
        },
      },
    );
    let notiType = PushNotificaitonTypes.PORTFOLIO_APPROVED;
    if (body.status == 2) {
      notiType = PushNotificaitonTypes.PORTFOLIO_UNAPPROVED;
    }

    //send push
    await pushService.sendNotification(notiType, [portfolio.user_id], Actors.Musician, null, user.id, null);

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Record updated successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| EXPORT  |||| -----------------------

const exportHandler: RequestHandler = async (req, res) => {
  try {
    console.log('********In Handler *************');
    await userService.exportMusician(res);
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET RATINGS BY MUSICIAN |||| -----------------------

interface GetRatingsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getRatingsHandler: RequestHandler = async (req: ValidatedRequest<GetRatingsRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);

    // const ratings = await userService.getUserByField('id', id, include);

    const ratings = await Rating.findAndCountAll({
      // include: [
      //   {
      //     model: User,
      //     as: 'user',
      //     attributes: ['id', 'en_full_name', 'image'],
      //     required: false,
      //   },
      // ],
      where: {
        musician_id: id,
      },
      attributes: [
        'id',
        'user_id',
        'musician_id',
        'booking_id',
        'rating',
        'comments',
        'createdAt',
        // [Sequelize.fn('COUNT', Sequelize.col('id')), 'total_rating'],
        [
          Sequelize.literal(
            '(SELECT AVG(`rating`) FROM rating WHERE musician_id = Rating.musician_id AND is_deleted = 0)',
          ),
          'avg_rating',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = Rating.musician_id AND rating = 5 AND is_deleted = 0)`,
          ),
          'five_star_count',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = Rating.musician_id AND rating = 4 AND is_deleted = 0)`,
          ),
          'four_star_count',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = Rating.musician_id AND rating = 3 AND is_deleted = 0)`,
          ),
          'three_star_count',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = Rating.musician_id AND rating = 2 AND is_deleted = 0)`,
          ),
          'two_star_count',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = Rating.musician_id AND rating = 1 AND is_deleted = 0)`,
          ),
          'one_star_count',
        ],
        [
          Sequelize.literal('(SELECT en_full_name FROM users WHERE id = Rating.user_id AND is_deleted = 0)'),
          'en_full_name',
        ],
        [Sequelize.literal('(SELECT image FROM users WHERE id = Rating.user_id AND is_deleted = 0)'), 'image'],
      ],
    });

    if (!ratings) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', data: {} },
      });
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', ratings },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};
//  ---------------- |||| DELETE RATING |||| -----------------------
interface ReviewDeleteSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteReviewHandler: RequestHandler = async (req: ValidatedRequest<ReviewDeleteSchema>, res) => {
  try {
    console.log('****************');
    const { id } = req.params;
    const user = req.userData;

    await Rating.update({ is_deleted: 1, u_by: user.id }, { where: { id } });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Review deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------
export const create = () =>
  router.post(
    '/create',
    s3FileUpload.single('image'),
    validator.body(createMusicianBodySchema),
    mainAuthMiddleware,
    handleError(createMusician),
  );

//  ---------------- |||| Payment Management list |||| -----------------------
export const paymentManagementListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
  suspensionFilter: Joi.number().allow(null),
  start_date: Joi.string().allow('', null),
  end_date: Joi.string().allow('', null),
});

interface PaymentManagementListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
    suspensionFilter: string;
    start_date: string;
    end_date: string;
  };
}

export const paymentmanagementListHandler: RequestHandler = async (
  req: ValidatedRequest<PaymentManagementListRequestSchema>,
  res,
) => {
  try {
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}

    let where: any = {};

    if (body.search_text && body.search_text != null) {
      where = {
        [Op.or]: [
          { en_full_name: { [Op.like]: '%' + body.search_text + '%' } },
          { email: { [Op.like]: '%' + body.search_text + '%' } },
          { phone_number: { [Op.like]: '%' + body.search_text + '%' } },
        ],
      };
    }
    if (body.statusFilter != null) {
      where.is_active = { [Op.eq]: body.statusFilter };
    }
    if (body.suspensionFilter != null) {
      where.is_suspended = { [Op.eq]: body.suspensionFilter };
    }

    if (body.start_date && body.end_date) {
      // where.createdAt = { [Op.between]: [body.start_date, body.end_date] };
      where.createdAt = {
        [Op.and]: [
          Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`User`.`createdAt`'), '%Y-%m-%d'), {
            [Op.gte]: body.start_date,
          }),
          Sequelize.where(Sequelize.fn('date_format', Sequelize.col('`User`.`createdAt`'), '%Y-%m-%d'), {
            [Op.lte]: body.end_date,
          }),
        ],
      };
    }

    where.is_deleted = 0;
    where.actor = 4;

    const musicians = await User.findAndCountAll({
      where: where,
      include: [
        // { model: UserAddress, as: 'addresses', where: { is_active: 1, is_deleted: 0, is_default: 1 }, required: false },
        {
          model: UserDetails,
          as: 'details',
          required: false,
        },
      ],
      attributes: [
        'id',
        [Sequelize.fn('', Sequelize.col('en_full_name')), 'name'],
        'email',
        'image',
        [
          Sequelize.literal('(SELECT COUNT(*) FROM bookings WHERE musician_id = User.id AND is_deleted = 0)'),
          'total_booking',
        ],
        [
          Sequelize.literal(
            '(SELECT SUM(paid_amount) FROM musician_payments WHERE musician_id = User.id AND is_deleted = 0)',
          ),
          'paid_amount',
        ],
        [
          Sequelize.literal(
            '(SELECT SUM(outstanding_amount	) FROM musician_payments WHERE musician_id = User.id AND is_deleted = 0)',
          ),
          'outstanding_amount',
        ],
        [
          Sequelize.literal(
            '(SELECT COUNT(*) FROM payment_request WHERE musician_id = User.id AND is_deleted = 0 AND is_approved = 0)',
          ),
          'payment_request',
        ],
        [Sequelize.fn('', Sequelize.col('details.total_earnings')), 'total_earnings'],
      ],
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
      distinct: true,
      // logging: true,
    });

    if (musicians.rows.length > 0) {
      if (musicians.rows.length >= limit) {
        musicians.rows.pop();
        is_last = 0;
      }
      const _musicians = { count: musicians.count, rows: [] };

      // await forEach(musicians.rows, async element => {
      //   const _element: any = element.toJSON();
      //   const categories = [];
      //   element.musician_categories.forEach((elem: any) => {
      //     categories.push(elem.category.translation[0].name);
      //   });
      //   _element.categort_name = categories.toString();
      //   delete _element['musician_categories'];
      //   _musicians.rows.push(_element);
      // });

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', musicians: musicians, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', musicians },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| Payment Request list |||| -----------------------
export const paymentRequestListBodySchema = Joi.object({
  id: Joi.number().required(),
  start: Joi.number().required(),
  limit: Joi.number(),
});

interface PaymentRequestListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    start: number;
    limit: number;
  };
}

export const paymentrequestListHandler: RequestHandler = async (
  req: ValidatedRequest<PaymentRequestListRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const id = Number(body.id);
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}

    const where: any = {};
    where.is_deleted = 0;
    where.musician_id = id;
    where.is_approved = MusicianPaymentRequest.PENDING;

    const musicians = await PaymentRequest.findAndCountAll({
      where: where,
      include: [],
      attributes: ['id', 'amount', 'description', 'subject', 'message'],
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
      distinct: true,
      // logging: true,
    });

    if (musicians.rows.length > 0) {
      if (musicians.rows.length >= limit) {
        musicians.rows.pop();
        is_last = 0;
      }
      const _musicians = { count: musicians.count, rows: [] };

      // await forEach(musicians.rows, async element => {
      //   const _element: any = element.toJSON();
      //   const categories = [];
      //   element.musician_categories.forEach((elem: any) => {
      //     categories.push(elem.category.translation[0].name);
      //   });
      //   _element.categort_name = categories.toString();
      //   delete _element['musician_categories'];
      //   _musicians.rows.push(_element);
      // });

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', list: musicians, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', list: musicians },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| Accept Musician Payment Request  |||| -----------------------
export const acceptPaymentRequestBodySchema = Joi.object({
  id: Joi.number().required(),
  type: Joi.number().required(), //1=mark as paid,2=Declined
  amount: Joi.number().allow(null),
  description: Joi.string().allow('', null),
});

interface AcceptPaymentRequestRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    type: number;
    amount: number;
    description: string;
  };
}

export const acceptPaymentRequestHandler: RequestHandler = async (
  req: ValidatedRequest<AcceptPaymentRequestRequestSchema>,
  res,
) => {
  try {
    const user = req.userData;
    const body = req.body;
    const id = Number(body.id);
    const type = Number(body.type);
    const amount = Number(body.amount ? body.amount : 0);
    const description = body.description ? body.description : '';

    const where: any = {};
    where.is_deleted = 0;
    where.id = id;
    const paymentRequest = await PaymentRequest.findOne({
      where: where,
    });
    if (!paymentRequest) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Request not found' },
      });
    }

    // already refunded
    if (paymentRequest.is_approved != MusicianPaymentRequest.PENDING) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Request already accepted' },
      });
    }
    if (amount > paymentRequest.amount) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Amount is greater than requested amount' },
      });
    }

    // console.log(musicianData);
    sequelize
      .transaction(async t => {
        await PaymentRequest.update(
          {
            is_approved: type,
            u_date: new Date(),
            u_by: user.id,
          },
          { where: { id: id }, transaction: t },
        );

        if (type == 1) {
          // const objMusicianPayments = {} as MusicianPayments;
          // objMusicianPayments.booking_id = paymentRequest.booking_id;
          // objMusicianPayments.musician_id = paymentRequest.musician_id;
          // objMusicianPayments.paid_amount = amount;
          // objMusicianPayments.outstanding_amount = paymentRequest.amount - amount;
          // objMusicianPayments.description = description;
          // objMusicianPayments.payment_date = moment()
          //   .unix()
          //   .toString();
          // objMusicianPayments.i_date = new Date();
          // objMusicianPayments.i_by = user.id;
          // objMusicianPayments.u_date = new Date();
          // objMusicianPayments.u_by = user.id;

          // await MusicianPayments.create(objMusicianPayments, { transaction: t });
          await MusicianPayments.update(
            {
              paid_amount: amount,
              outstanding_amount: paymentRequest.amount - amount,
              description: description,
              payment_date: moment()
                .unix()
                .toString(),
              u_date: new Date(),
              u_by: user.id,
            },
            {
              where: { is_deleted: 0, booking_id: paymentRequest.booking_id, musician_id: paymentRequest.musician_id },
              transaction: t,
            },
          );

          const musicianData = await User.findOne({
            where: { id: paymentRequest.musician_id },
            attributes: [
              'id',
              [
                Sequelize.literal(
                  '(SELECT SUM(paid_amount) FROM musician_payments WHERE musician_id = User.id AND is_deleted = 0)',
                ),
                'paid_amount',
              ],
            ],

            logging: true,
          });
          await UserDetails.update(
            {
              total_earnings: musicianData.get('paid_amount'),
              updatedAt: new Date(),
              u_by: user.id,
            },
            { where: { user_id: paymentRequest.musician_id }, logging: true, transaction: t },
          );
        }

        let notiType = PushNotificaitonTypes.PAYMENT_DUE_REQUEST_ACCEPTED;
        if (body.type == 2) {
          notiType = PushNotificaitonTypes.PAYMENT_DUE_REQUEST_REJECTED;
        }

        //send push
        await pushService.sendNotification(
          notiType,
          [paymentRequest.musician_id],
          Actors.Musician,
          null,
          user.id,
          null,
        );
      })
      .then(() => {
        return res.send({
          success: 1,
          error: [],
          data: { message: 'Success' },
        });
      })
      .catch(err => {
        console.log(err);
        return res.status(500).send({ success: 0, error: { message: err.message } });
      });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| Payment History list |||| -----------------------
export const paymentHistoryListBodySchema = Joi.object({
  id: Joi.number().required(),
  start: Joi.number().required(),
  limit: Joi.number(),
});

interface PaymentHistoryListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    start: number;
    limit: number;
  };
}

export const paymentHistoryListHandler: RequestHandler = async (
  req: ValidatedRequest<PaymentHistoryListRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const id = Number(body.id);
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    // const where:any = {actor: 4, is_deleted: 0}

    const where: any = {};
    where.is_deleted = 0;
    where.musician_id = id;

    const musicians = await MusicianPayments.findAndCountAll({
      where: where,
      include: [],
      attributes: ['id', ['paid_amount', 'amount'], 'description', 'payment_date'],
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
      distinct: true,
      // logging: true,
    });

    if (musicians.rows.length > 0) {
      if (musicians.rows.length >= limit) {
        musicians.rows.pop();
        is_last = 0;
      }
      const _musicians = { count: musicians.count, rows: [] };

      // await forEach(musicians.rows, async element => {
      //   const _element: any = element.toJSON();
      //   const categories = [];
      //   element.musician_categories.forEach((elem: any) => {
      //     categories.push(elem.category.translation[0].name);
      //   });
      //   _element.categort_name = categories.toString();
      //   delete _element['musician_categories'];
      //   _musicians.rows.push(_element);
      // });

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', list: musicians, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', musicians },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

export const exportMusician = () => router.get('/export', mainAuthMiddleware, handleError(exportHandler));

export const list = () =>
  router.post('/', validator.body(musicianListBodySchema), mainAuthMiddleware, handleError(musicianList));
export const get = () =>
  router.get(
    '/:id',
    // validator.params(getMusicianBodySchema),
    mainAuthMiddleware,
    handleError(getMusician),
  );

export const deleteReview = () =>
  router.delete(
    '/deleteReview/:id',
    // validator.params(deleteMusicianParamsSchema),
    mainAuthMiddleware,
    handleError(deleteReviewHandler),
  );

export const deleteMusician = () =>
  router.delete(
    '/:id',
    // validator.params(deleteMusicianParamsSchema),
    mainAuthMiddleware,
    handleError(deleteMusicianHandler),
  );

export const changeStatus = () =>
  router.post(
    '/changeStatus',
    validator.body(changeMusicianStatusSchema),
    mainAuthMiddleware,
    handleError(changeMusicianStatusHandler),
  );

export const changeSuspension = () =>
  router.post(
    '/changeSuspension',
    validator.body(changeMusicianSuspensionSchema),
    mainAuthMiddleware,
    handleError(changeMusicianSuspensionHandler),
  );

export const edit = () =>
  router.patch(
    '/:id',
    s3FileUpload.single('image'),
    // validator.params({ id: Joi.number().required }),
    validator.body(editMusicianBodySchema),
    mainAuthMiddleware,
    handleError(editMusicianHandler),
  );
export const getPortfolios = () =>
  router.get('/getPortfolios/:id', mainAuthMiddleware, handleError(getMusicianPortfolioHandler));

export const changePortfolioStatus = () =>
  router.post(
    '/changePortfolioStatus',
    validator.body(changePortfolioStatuschema),
    mainAuthMiddleware,
    handleError(changePortfolioStatusHandler),
  );

export const getRatings = () => router.get('/getRatings/:id', mainAuthMiddleware, handleError(getRatingsHandler));

export const paymentmanagementList = () =>
  router.post(
    '/paymentmanagementlist',
    validator.body(paymentManagementListBodySchema),
    mainAuthMiddleware,
    handleError(paymentmanagementListHandler),
  );

export const paymentrequestList = () =>
  router.post(
    '/paymentrequestlist',
    validator.body(paymentRequestListBodySchema),
    mainAuthMiddleware,
    handleError(paymentrequestListHandler),
  );

export const acceptPaymentRequest = () =>
  router.post(
    '/acceptPaymentRequest',
    validator.body(acceptPaymentRequestBodySchema),
    mainAuthMiddleware,
    handleError(acceptPaymentRequestHandler),
  );

export const paymentHistoryList = () =>
  router.post(
    '/paymentHistorylist',
    validator.body(paymentHistoryListBodySchema),
    mainAuthMiddleware,
    handleError(paymentHistoryListHandler),
  );
