/* eslint-disable @typescript-eslint/no-explicit-any */

import * as Joi from '@hapi/joi';
import { ValidatedRequestSchema, ContainerTypes, ValidatedRequest, createValidator } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import { CMS } from '../../../models/cms.model';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import handleError from '../../../middlewares/handle-error';
import { CMSTranslation } from '../../../models/cmsTranslation.model';
import { Language } from '../../../models/language.model';
import { Sequelize } from 'sequelize';

const router = Router();
const validator = createValidator();

//  ---------------- |||| LIST |||| -----------------------
export const cmsListBodySchema = Joi.object({
  actor: Joi.number().allow(null),
});

interface CmsListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    actor: number;
  };
}

export const cmsList: RequestHandler = async (req: ValidatedRequest<CmsListRequestSchema>, res) => {
  try {
    const body = req.body;

    const where: any = {};
    where.is_deleted = 0;
    where.actor = body.actor;

    const cms = await CMS.findAndCountAll({
      include: [
        {
          model: CMSTranslation,
          where: {
            language_code: 'en',
          },
          as: 'translation',
        },
      ],
      where: where,
      order: [['id', 'DESC']],
    });

    if (cms.rows.length > 0) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', cms },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No Record found', cms },
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| EDIT |||| -----------------------
export const editcmsBodySchema = Joi.object({
  // en_name: Joi.string().required(),
  // ar_name: Joi.string().required(),
  // en_content: Joi.string().required(),
  // ar_content: Joi.string().required(),
  languages: Joi.string(),
});

interface EditCmsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    // en_name: string;
    // ar_name: string;
    // en_content: string;
    // ar_content: string;
    languages: string;
  };
}

export const editcms = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const { id } = req.params;
    const data: any[] = JSON.parse(body.languages);

    const cms: CMS = {} as CMS;

    cms.actor = body.actor;
    cms.u_by = user.id;
    console.log(cms);

    await CMS.update(cms, { where: { id } });

    const obj = data.map(elem => {
      return {
        cms_id: id,
        language_code: elem.language_code,
        title: elem.cms_name,
        content: elem.cms_content,
      };
    });

    await CMSTranslation.destroy({ where: { cms_id: id } });

    await CMSTranslation.bulkCreate(obj);

    // const en_obj = {
    //   title: body.en_name,
    //   content: body.en_content,
    //   u_by: user.id,
    // };

    // const ar_obj = {
    //   title: body.ar_name,
    //   content: body.ar_content,
    //   u_by: user.id,
    // };

    // await CMSTranslation.update(en_obj, { where: { cms_id: id, language_code: 'en' } });
    // await CMSTranslation.update(ar_obj, { where: { cms_id: id, language_code: 'ar' } });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'CMS Updated Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

// const getcmssBodySchema = {
//   id: Joi.string().required(),
// };

interface GetCmsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getcms: RequestHandler = async (req: ValidatedRequest<GetCmsRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);

    const cms = await CMS.findOne({
      include: [
        {
          model: CMSTranslation,
          as: 'translation',
          include: [
            {
              model: Language,
              as: 'language',
            },
          ],
          attributes: [
            'id',
            'cms_id',
            'language_code',
            // 'name',
            [Sequelize.fn('', Sequelize.col('`translation.title`')), 'title'],
            [Sequelize.fn('', Sequelize.col('`translation.content`')), 'content'],
            [Sequelize.fn('', Sequelize.col('`translation.language.name`')), 'language_name'],
          ],
        },
      ],
      where: { id },
    });

    if (!cms) {
      return res.send({ success: 0, error: { message: 'No record found' } });
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', cms },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID AND LANGUAGE |||| -----------------------

const getcmsPageBodySchema = Joi.object({
  id: Joi.number().required(),
  language_code: Joi.string().required(),
});

interface GetCmsPageRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    language_code: string;
  };
}

export const getcmsPage: RequestHandler = async (req: ValidatedRequest<GetCmsPageRequestSchema>, res) => {
  try {
    const id = req.body.id;
    const cms = await CMSTranslation.findOne({
      where: { cms_id: id, language_code: req.body.language_code },
    });

    if (!cms) {
      return res.send({ success: 0, error: { message: 'No record found' } });
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', cms },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------

export const list = () => router.post('/', validator.body(cmsListBodySchema), mainAuthMiddleware, handleError(cmsList));

export const get = () =>
  router.get(
    '/:id',
    // validator.params(getcmssBodySchema),
    mainAuthMiddleware,
    handleError(getcms),
  );

export const edit = () =>
  router.patch(
    '/:id',
    // validator.params({ id: Joi.number().required }),
    validator.body(editcmsBodySchema),
    mainAuthMiddleware,
    handleError(editcms),
  );

export const getCMSPage = () =>
  router.post('/getCMSPage', validator.body(getcmsPageBodySchema), handleError(getcmsPage));
