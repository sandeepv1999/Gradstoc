import { Router } from 'express';
import { list, get, edit, getCMSPage } from './controllers';

const router = Router();

export const cms = () => router.use([list(), get(), edit(), getCMSPage()]);
