import { Router } from 'express';
import { create, list, get, deleteCategory, edit, changeStatus } from './controllers';

const router = Router();

export const banners = () => router.use([create(), list(), get(), deleteCategory(), edit(), changeStatus()]);
