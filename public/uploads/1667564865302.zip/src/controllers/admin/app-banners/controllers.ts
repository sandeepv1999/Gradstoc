/* eslint-disable @typescript-eslint/no-explicit-any */

import * as bannerService from '../../../utils/app-banners';
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import { FileUpload } from '../../../services/fileUpload';
import config from '../../../config';
import { AppBanners } from '../../../models/appBanner.model';
import { Op } from 'sequelize';

const router = Router();
const validator = createValidator();

const fileUploadObj = new FileUpload(config);
const s3FileUpload = fileUploadObj.imageUploadS3();


//  ---------------- |||| CREATE |||| -----------------------

export const createBannerBodySchema = Joi.object({
  image: Joi.string(),
  image_type: Joi.string(),
});

interface CreateBannerRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    image: string;
    image_type: string;
  };
}

export const createBannerHandler = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;

    console.log("reqqqqqqqqqqqqqqqqqqqqqqq",req.body,"---",req.file);
    
    const obj: AppBanners = {} as AppBanners;
    if (req.file) {
      obj.banner_url = req.file.location;
    }
    obj.is_active = 0;
    obj.i_by = user.id;
    obj.imageType = req.body.image_type;
    console.log(obj);

    await bannerService.createBanner(obj);

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Banner Created Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const bannerListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
});

interface BannerListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
  };
}

export const bannerListHandler: RequestHandler = async (req: ValidatedRequest<BannerListRequestSchema>, res) => {
  try {
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    const where = { is_deleted: 0 };

    const banners = await AppBanners.findAndCountAll({
      where: where,
      offset: start,
      limit: limit,
      order: [
        ['is_active', 'DESC'],
        ['id', 'DESC'],
      ],
    });

    if (banners.rows.length > 0) {
      if (banners.rows.length >= limit) {
        banners.rows.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', banners, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', banners },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

// const getCategoryBodySchema = {
//   id: Joi.string().required(),
// };

interface GetBannerRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getBannerHandler: RequestHandler = async (req: ValidatedRequest<GetBannerRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);

    // const musician = await userService.getUserByField('id', id);

    const banner = await AppBanners.findOne({
      where: { id },
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', banner },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| DELETE |||| -----------------------
// const deleteCategoryaramsSchema = {
//   id: Joi.string().required(),
// };

interface BannerDeleteSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteBannerHandler: RequestHandler = async (req: ValidatedRequest<BannerDeleteSchema>, res) => {
  try {
    console.log('****************');
    const { id } = req.params;
    const user = req.userData;
    const banner = await bannerService.updateBannerByField('id', id, {
      is_deleted: 1,
      u_by: user.id,
    });
    if (!banner) {
      return res.send({ success: 0, data: {}, error: { message: 'No record found' } });
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Banner deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE STATUS |||| -----------------------
const changeBannerStatusSchema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangeBannerStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    status: number;
  };
}

const changeBannerStatusHandler: RequestHandler = async (req: ValidatedRequest<ChangeBannerStatusSchema>, res) => {
  try {
    console.log('****************');
    const body = req.body;
    const user = req.userData;

    console.log("bodyyyy",body);
    console.log("req.userData",user);

    const activeBanner = await bannerService.updateBannerByField('id', body.id, {
      is_active: body.status,
      u_by: user.id,
    });
    // await AppBanners.update({ is_active: 0, u_by: user.id }, { where: { id: { [Op.ne]: body.id } } }); //commented on 21 june 2022

    if (!activeBanner) {
      return res.send({ success: 0, data: {}, error: { message: 'No record found' } });
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Record updated successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

export const editBannerBodySchema = Joi.object({
  image: Joi.string(),
});

interface EditBannerRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    image: string;
  };
}

export const editBannerHandler = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const { id } = req.params;
    // console.log(req.file.location);

    console.log(req.file);
    console.log(body);

    await bannerService.updateBannerByField('id', id, {
      banner_url: req.file ? req.file.location : body.image,
      u_by: user.id,
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Banner Updated Successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------
export const create = () =>
  router.post(
    '/create',
    s3FileUpload.single('image'),
    validator.body(createBannerBodySchema),
    mainAuthMiddleware,
    handleError(createBannerHandler),
  );

export const list = () =>
  router.post('/', validator.body(bannerListBodySchema), mainAuthMiddleware, handleError(bannerListHandler));

export const get = () => router.get('/:id', mainAuthMiddleware, handleError(getBannerHandler));

export const deleteCategory = () => router.delete('/:id', mainAuthMiddleware, handleError(deleteBannerHandler));

export const changeStatus = () =>
  router.post(
    '/changeStatus',
    validator.body(changeBannerStatusSchema),
    mainAuthMiddleware,
    handleError(changeBannerStatusHandler),
  );

export const edit = () =>
  router.patch(
    '/:id',
    s3FileUpload.single('image'),
    validator.body(editBannerBodySchema),
    mainAuthMiddleware,
    handleError(editBannerHandler),
  );
