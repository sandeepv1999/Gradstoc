/* eslint-disable @typescript-eslint/no-explicit-any */

import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import { Op } from 'sequelize';

import handleError from '../../../middlewares/handle-error';
import { mainAuthMiddleware } from '../../../middlewares/auth.middleware';
import config from '../../../config';
import {
  Languages,
  LanguageCodes,
  MusicianPaymentRequest,
  PushNotificaitonTypes,
  Actors,
} from '../../../utils/constants';

import { FileUpload } from '../../../services/fileUpload';
import * as emailService from '../../../services/email.service';
import * as userService from '../../../utils/user';

import { User } from '../../../models/users.model';
import * as pushService from '../../../services/notification.service';
import * as authService from '../../../utils/auth';

const router = Router();
const validator = createValidator();

const fileUploadObj = new FileUpload(config);
const s3FileUpload = fileUploadObj.imageUploadS3();

//  ---------------- |||| CREATE |||| -----------------------

export const createSubAdminBodySchema = Joi.object({
  name: Joi.string().required(),
  phone_number: Joi.number().required(),
  email: Joi.string().required(),
  role: Joi.number().required(),
  dial_code: Joi.string()
    .allow('')
    .allow(null),
});

interface CreateSubAdminRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    name: string;
    phone_number: string;
    email: string;
    role: string;
    dial_code: string;
  };
}

export const createSubAdmin = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    // const emailVerificationToken = await userService.generateEmailToken();
    const randomstring = Math.random()
      .toString(36)
      .slice(-8);
    body.password = randomstring;
    await userService.createUser({
      en_full_name: body.name,
      actor: 2,
      email: body.email,
      password: randomstring,
      dial_code: body.dial_code ? body.dial_code : '+966',
      phone_number: body.phone_number,
      role: body.role,
      i_by: user.id,
    });

    emailService.sendMusicianRegistrationEmail(body, 'registration_sub_admin');

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Sub Admin Created Successfully' },
    });
  } catch (error) {
    return res.status(500).send({
      success: 0,
      error: { message: error.message },
      data: {},
    });
  }
};

//  ---------------- |||| LIST |||| -----------------------
export const subAdminListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
});

interface SubAdminListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
  };
}

export const subAdminList: RequestHandler = async (req: ValidatedRequest<SubAdminListRequestSchema>, res) => {
  try {
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;

    let where: any = {};

    if (body.search_text && body.search_text != null) {
      where = {
        [Op.or]: [
          { en_full_name: { [Op.like]: '%' + body.search_text + '%' } },
          { email: { [Op.like]: '%' + body.search_text + '%' } },
          { phone_number: { [Op.like]: '%' + body.search_text + '%' } },
        ],
      };
    }
    if (body.statusFilter != null) {
      where.is_active = { [Op.eq]: body.statusFilter };
    }

    where.is_deleted = 0;
    where.actor = 2;

    const subAdmins = await User.findAndCountAll({
      where: where,
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
    });

    if (subAdmins.rows.length > 0) {
      if (subAdmins.rows.length >= limit) {
        subAdmins.rows.pop();
        is_last = 0;
      }

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', subAdmins, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', subAdmins },
      });
    }
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| GET BY ID |||| -----------------------

interface GetSubAdminRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

export const getSubAdmin: RequestHandler = async (req: ValidatedRequest<GetSubAdminRequestSchema>, res) => {
  try {
    const id = parseInt(req.params.id);
    const subAdmin = await userService.getUserByField('id', id);

    if (!subAdmin) {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No records found', data: {} },
      });
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', subAdmin },
    });
  } catch (error) {
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| DELETE |||| -----------------------

interface SubAdminDeleteSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    id: string;
  };
}

const deleteSubAdminHandler: RequestHandler = async (req: ValidatedRequest<SubAdminDeleteSchema>, res) => {
  try {
    console.log('****************');
    const { id } = req.params;
    const user = req.userData;
    await userService.updateUserByField('id', id, { is_deleted: 1, u_by: user.id });
    //delete token of this user
    //send push
    await pushService.sendNotification(
      PushNotificaitonTypes.USER_DELETE,
      [Number(id)],
      Actors.SubAdmin,
      null,
      user.id,
      null,
    );
    //delete token
    let firebaseIds = await authService.getAllUserTokens([Number(id)]);
    console.log(firebaseIds);
    // firebaseIds.map(data => {
    // await authService.destroyToken(data);
    // });
    firebaseIds = await Promise.all(
      firebaseIds.map(
        async (elem): Promise<any> => {
          // console.log(elem);
          await authService.destroyToken(elem);
        },
      ),
    );
    return res.send({
      success: 1,
      error: [],
      data: { message: 'SubAdmin deleted successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CHANGE STATUS |||| -----------------------
const changeSubAdminStatusSchema = Joi.object({
  id: Joi.number().required(),
  status: Joi.number().required(),
});

interface ChangeSubAdminStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    status: number;
  };
}

const changeSubAdminStatusHandler: RequestHandler = async (req: ValidatedRequest<ChangeSubAdminStatusSchema>, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    await userService.updateUserByField('id', body.id, { is_active: body.status, u_by: user.id });
    //delete token of this user
    if (body.status == 0) {
      //send push
      await pushService.sendNotification(
        PushNotificaitonTypes.USER_INACTIVE,
        [body.id],
        Actors.SubAdmin,
        null,
        user.id,
        null,
      );
      //delete token
      let firebaseIds = await authService.getAllUserTokens([body.id]);
      console.log(firebaseIds);
      // firebaseIds.map(data => {
      // await authService.destroyToken(data);
      // });
      firebaseIds = await Promise.all(
        firebaseIds.map(
          async (elem): Promise<any> => {
            // console.log(elem);
            await authService.destroyToken(elem);
          },
        ),
      );
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: 'Record updated successfully' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| EDIT SUB ADMIN |||| -----------------------

export const editSubAdminBodySchema = Joi.object({
  name: Joi.string().required(),
  phone_number: Joi.number().required(),
  email: Joi.string().required(),
  role: Joi.number(),
  dial_code: Joi.string()
    .allow('')
    .allow(null),
});

interface EditSubAdminRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    name: string;
    phone_number: string;
    email: string;
    role: number;
    dial_code: string;
  };
}

export const editSubAdminHandler = async (req, res) => {
  try {
    const body = req.body;
    const user = req.userData;
    const { id } = req.params;
    // console.log(req.file.location);

    const subAdmin = await userService.updateUserByField('id', id, {
      en_full_name: body.name,
      email: body.email,
      dial_code: body.dial_code ? body.dial_code : '+966',
      phone_number: body.phone_number,
      role: body.role,
      u_by: user.id,
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Sub Admin Updated Successfully', subAdmin },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| ROUTES |||| -----------------------
export const create = () =>
  router.post(
    '/create',
    s3FileUpload.single('image'),
    validator.body(createSubAdminBodySchema),
    mainAuthMiddleware,
    handleError(createSubAdmin),
  );

export const list = () =>
  router.post('/', validator.body(subAdminListBodySchema), mainAuthMiddleware, handleError(subAdminList));
export const get = () => router.get('/:id', mainAuthMiddleware, handleError(getSubAdmin));
export const deleteSubAdmin = () => router.delete('/:id', mainAuthMiddleware, handleError(deleteSubAdminHandler));

export const changeStatus = () =>
  router.post(
    '/changeStatus',
    validator.body(changeSubAdminStatusSchema),
    mainAuthMiddleware,
    handleError(changeSubAdminStatusHandler),
  );

export const edit = () =>
  router.patch(
    '/:id',
    s3FileUpload.single('image'),
    // validator.params({ id: Joi.number().required }),
    validator.body(editSubAdminBodySchema),
    mainAuthMiddleware,
    handleError(editSubAdminHandler),
  );
