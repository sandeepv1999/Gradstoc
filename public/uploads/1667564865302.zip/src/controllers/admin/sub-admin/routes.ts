import { Router } from 'express';
import { create, list, get, deleteSubAdmin, changeStatus, edit } from './controllers';

const router = Router();

export const subAdmin = () => router.use([create(), list(), get(), deleteSubAdmin(), changeStatus(), edit()]);
