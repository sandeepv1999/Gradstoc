/* eslint-disable @typescript-eslint/no-explicit-any */
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';

import handleError from '../../../../middlewares/handle-error';
import { mainAuthMiddleware, message } from '../../../../middlewares/auth.middleware';
import { ReE } from '../../../../services/util.service';

import * as userService from '../../../../utils/user';
import { UserAddress } from '../../../../models/userAddresses.model';
import { Sequelize } from 'sequelize';
import { City } from '../../../../models/city.model';
import { State } from '../../../../models/state.model';
import { Country } from '../../../../models/country.model';

const router = Router();
const validator = createValidator({ passError: true });

//  ---------------- |||| LIST |||| -----------------------
export const addressListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
});

interface AddressListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
  };
}

export const addressListHandler: RequestHandler = async (req: ValidatedRequest<AddressListRequestSchema>, res) => {
  const language = req.headers.language;
  try {
    const body = req.body;
    const User = req.userData;
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);
    let is_last = 1;

    const Where: any = { is_deleted: 0, is_active: 1, user_id: User.id };

    const address_list = await UserAddress.findAll({
      where: Where,
      include: [
        {
          model: City,
          as: 'city',
        },
        {
          model: State,
          as: 'state',
        },
        {
          model: Country,
          as: 'country',
        },
      ],
      attributes: [
        'id',
        'address',
        'address_type',
        'is_default',
        'city_id',
        'state_id',
        'country_id',
        'landmark',
        [Sequelize.fn('', Sequelize.col('contact_person')), 'contact_person'],
        // [Sequelize.fn('', Sequelize.col('landmark')), 'land_mark'],
        [Sequelize.fn('', Sequelize.col('lat')), 'latitude'],
        [Sequelize.fn('', Sequelize.col('lng')), 'longitude'],
        [Sequelize.fn('', Sequelize.col('`city.name')), 'city_name'],
        [Sequelize.fn('', Sequelize.col('`state.name')), 'state_name'],
        [Sequelize.fn('', Sequelize.col('`country.name')), 'country_name'],
      ],
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
    });

    if (address_list.length > 0) {
      if (address_list.length >= limit) {
        address_list.pop();
        is_last = 0;
      }
      return res.send({
        success: 1,
        error: [],
        data: { message: message(language, 'success'), address_list, is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: message(language, 'no_records_found'), address_list },
      });
    }
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| Add ADDRESS |||| -----------------------
export const createAddressBodySchema = Joi.object({
  address_type: Joi.number().required(),
  address: Joi.string().required(),
  person_name: Joi.string(),
  land_mark: Joi.string().required(),
  latitude: Joi.number().required(),
  longitude: Joi.number().required(),
  city_id: Joi.number().required(),
  state_id: Joi.number().required(),
  country_id: Joi.number().required(),
});

interface CreateAddressRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    address_type: string;
    address: string;
    person_name: string;
    land_mark: string;
    latitude: number;
    longitude: number;
    city_id: number;
    state_id: number;
    country_id: number;
  };
}

export const createAddressHandler: RequestHandler = async (req: ValidatedRequest<CreateAddressRequestSchema>, res) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      user_id: userData.id,
      contact_person: body.person_name ? body.person_name : userData.en_full_name,
      address: body.address,
      landmark: body.land_mark,
      address_type: body.address_type,
      city_id: body.city_id,
      state_id: body.state_id,
      country_id: body.country_id,
      lat: body.latitude,
      lng: body.longitude,
      i_by: userData.id,
    };

    await userService.createAddress(data);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'address_saved_success'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| Edit ADDRESS |||| -----------------------
export const editAddressBodySchema = Joi.object({
  address_id: Joi.number().required(),
  address_type: Joi.number().required(),
  address: Joi.string().required(),
  person_name: Joi.string().required(),
  land_mark: Joi.string().required(),
  latitude: Joi.number().required(),
  longitude: Joi.number().required(),
  city_id: Joi.number().required(),
  state_id: Joi.number().required(),
  country_id: Joi.number().required(),
});

interface EditAddressRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    address_id: number;
    address_type: string;
    address: string;
    person_name: string;
    land_mark: string;
    latitude: number;
    longitude: number;
    city_id: number;
    state_id: number;
    country_id: number;
  };
}

export const editAddressHandler: RequestHandler = async (req: ValidatedRequest<EditAddressRequestSchema>, res) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      user_id: userData.id,
      contact_person: body.person_name,
      address: body.address,
      landmark: body.land_mark,
      address_type: body.address_type,
      city_id: body.city_id,
      state_id: body.state_id,
      country_id: body.country_id,
      lat: body.latitude,
      lng: body.longitude,
      u_by: userData.id,
    };

    await userService.updateUserAddress('id', body.address_id, data);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'address_updated_success'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| Delete ADDRESS |||| -----------------------
export const deleteAddressBodySchema = Joi.object({
  address_id: Joi.number().required(),
});

interface DeleteAddressRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    address_id: number;
  };
}

export const deleteAddressHandler: RequestHandler = async (req: ValidatedRequest<DeleteAddressRequestSchema>, res) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      is_deleted: 1,
      u_by: userData.id,
    };

    await userService.updateUserAddress('id', body.address_id, data);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'address_delete_success'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| ROUTES |||| -----------------------
export const getAddresses: any = () =>
  router.post('/', validator.body(addressListBodySchema), mainAuthMiddleware, handleError(addressListHandler));

export const addAddress: any = () =>
  router.post(
    '/create',
    validator.body(createAddressBodySchema),
    mainAuthMiddleware,
    handleError(createAddressHandler),
  );

export const updateAddress: any = () =>
  router.post('/edit', validator.body(editAddressBodySchema), mainAuthMiddleware, handleError(editAddressHandler));

export const deleteAddress: any = () =>
  router.post(
    '/delete',
    validator.body(deleteAddressBodySchema),
    mainAuthMiddleware,
    handleError(deleteAddressHandler),
  );
