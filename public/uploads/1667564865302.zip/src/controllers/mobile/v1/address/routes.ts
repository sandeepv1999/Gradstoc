/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import { getAddresses, addAddress, updateAddress, deleteAddress } from './controller';

const router = Router();

export const address: any = () => router.use([getAddresses(), addAddress(), updateAddress(), deleteAddress()]);
