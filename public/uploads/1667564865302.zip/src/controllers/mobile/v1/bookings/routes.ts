/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import {
  createBooking,
  Bookings,
  BookingDetail,
  RateBooking,
  CancelBooking,
  AcceptBooking,
  CompleteBooking,
  NotifyToAdmin,
} from './controllers';

const router = Router();

export const booking: any = () =>
  router.use([
    createBooking(),
    Bookings(),
    BookingDetail(),
    RateBooking(),
    CancelBooking(),
    AcceptBooking(),
    CompleteBooking(),
    NotifyToAdmin(),
  ]);
