/* eslint-disable @typescript-eslint/no-explicit-any */
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import * as Joi from '@hapi/joi';

import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import * as userService from '../../../../utils/user';
import * as categoryService from '../../../../utils/category';

import handleError from '../../../../middlewares/handle-error';
import { mainAuthMiddleware, message, simpleAuthMiddleware } from '../../../../middlewares/auth.middleware';
import { ReE } from '../../../../services/util.service';
import { Booking } from '../../../../models/bookings.model';
import moment from 'moment';
import { Settings } from '../../../../models/settings.model';
import { MusicianPayments } from '../../../../models/musicianPayments.model';
import {
  BookingType,
  BookingStatus,
  Actors,
  RefundStatus,
  Languages,
  LanguageCodes,
  PushNotificaitonTypes,
  NotifyToAdminStatus,
} from '../../../../utils/constants';
import { BookingAddress } from '../../../../models/bookingAddresses.model';
import { UserAddress } from '../../../../models/userAddresses.model';
import { BookingCategory } from '../../../..//models/bookingCategory.model';
import { Category } from '../../../../models/category.model';
import { CategoryTranslation } from '../../../../models/categoryTranslation.model';
import { Sequelize, Transaction, Op } from 'sequelize';
import { setUpSequelize } from '../../../../db/sql/connection';
import { User } from '../../../../models/users.model';
import { UserDetails } from '../../../../models/userDetails.model';
import { Rating } from '../../../../models/rating.model';
import { BookingCancellationReason } from '../../../../models/bookingCancellationReason.model';
import { Reason } from '../../../../models/reason.model';
import * as pushService from '../../../../services/notification.service';
import config from '../../../../config';
import { JWT } from '../../../../utils/jwt';
import { Language } from '../../../../models/language.model';
import { forEach, map } from 'p-iteration';

const sequelize: Sequelize = setUpSequelize();

const router = Router();
const validator = createValidator({ passError: true });
const jwt = new JWT(config);

export const createBookingBodySchema = Joi.object({
  musician_id: Joi.number().required(),
  booked_type: Joi.number().required(),
  category_id: Joi.number().required(),
  date: Joi.number().required(),
  start_time: Joi.number().required(),
  hours: Joi.number().required(),
  description: Joi.string(),
  address_id: Joi.number().required(),
  timezone: Joi.string(),
  ipAddress: Joi.string()
    .required()
    .default('0.0.0.0'),
});

interface CreateBookingRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    musician_id: number;
    booked_type: number;
    category_id: number;
    date: number;
    start_time: number;
    hours: number;
    description: string;
    address_id: number;
    timezone: string;
    ipAddress: string;
  };
}

//  ---------------- |||| Create Booking |||| -----------------------
export const createBookingHandler: RequestHandler = async (req: ValidatedRequest<CreateBookingRequestSchema>, res) => {
  const user = req.userData;
  const body = req.body;
  const language = req.headers.language;

  try {
    let totalAmount = 0;
    let adminCommisionAmount = 0;
    let musicianEarning = 0;

    const getBooking = await userService.checkCurrentBookingByUserId(user.id, body.musician_id);

    if (
      getBooking &&
      moment(body.date * 1000).format('DD-MM-yyyy') == moment(getBooking.event_date * 1000).format('DD-MM-yyyy')
    ) {
      return ReE(res, message(language, 'already_made_booking_on_same_day'), 200);
    }
    const musician = await userService.getUserByField('id', body.musician_id, ['userdetails']);
    const adminCommission = await Settings.findOne({ where: { key: 'admin_commission' } });
    const address = await UserAddress.findOne({ where: { id: body.address_id } });
    const category = await Category.findOne({
      where: { id: body.category_id, is_active: 1, is_deleted: 0 },
      include: [{ model: CategoryTranslation, as: 'translation' }],
    });

    console.log(musician);

    if (!musician.details) {
      return ReE(res, message(language, 'musician_details_not_found'), 200);
    }

    if (!adminCommission) {
      return ReE(res, message(language, 'admin_commission_not_found'), 200);
    }

    if (!address) {
      return ReE(res, message(language, 'address_not_found'), 200);
    }
    if (!category) {
      return ReE(res, message(language, 'category_not_found'), 200);
    }

    if (body.booked_type == BookingType.Hourly && musician.details.hourly_rate == 0) {
      return ReE(res, message(language, 'musician_not_working_as_hourly'), 200);
    }

    if (body.booked_type == BookingType.FixedDay && musician.details.fix_rate == 0) {
      return ReE(res, message(language, 'musician_not_working_as_fixed'), 200);
    }

    // Calculate Admin commission and Musician earnings

    if (body.booked_type == BookingType.Hourly) {
      totalAmount = musician.details.hourly_rate * body.hours;
    }

    if (body.booked_type == BookingType.FixedDay) {
      totalAmount = musician.details.fix_rate;
    }

    adminCommisionAmount = (totalAmount * parseFloat(adminCommission.value)) / 100;
    musicianEarning = totalAmount - adminCommisionAmount;

    // Create Booking object
    const _booking = {} as Booking;
    _booking.musician_id = body.musician_id;
    _booking.user_id = user.id;
    _booking.description = body.description;
    _booking.is_fixed = body.booked_type;
    _booking.booking_rate = body.booked_type == 1 ? musician.details.hourly_rate : musician.details.fix_rate;
    _booking.event_date = body.date;
    _booking.start_time = body.start_time.toString();
    _booking.end_time =
      body.booked_type == BookingType.Hourly
        ? moment(body.start_time * 1000)
            .add(body.hours, 'hour')
            .unix()
            .toString()
        : moment(body.start_time * 1000)
            .add(8, 'hour')
            .unix()
            .toString();
    _booking.total_amount = totalAmount;
    _booking.admin_commission_percentage = parseFloat(adminCommission.value);
    _booking.admin_earning = adminCommisionAmount;
    _booking.musician_earning = musicianEarning;
    _booking.status = BookingStatus.Pending;
    _booking.cancelled_by = 0;
    _booking.booking_date = moment().unix();
    _booking.timezone = body.timezone;
    _booking.hours = body.hours;
    _booking.musician_resp_time = 0;
    _booking.is_active = 0;

    const bookingAddress = {} as BookingAddress;
    bookingAddress.contact_person = address.contact_person;
    bookingAddress.address = address.address;
    bookingAddress.address_type = address.address_type;
    bookingAddress.landmark = address.landmark;
    bookingAddress.city = address.city_id;
    bookingAddress.state = address.state_id;
    bookingAddress.country = address.country_id;
    bookingAddress.lat = address.lat;
    bookingAddress.lng = address.lng;

    const _bookingCategories: BookingCategory[] = [];
    category.translation.forEach(elem => {
      const bookingCategory = {} as BookingCategory;
      bookingCategory.name = elem.name;
      bookingCategory.language_code = elem.language_code;
      _bookingCategories.push(bookingCategory);
    });

    let paymentToken = null;
    // Implement Managed Transaction
    await sequelize.transaction(async t => {
      // step 1 -> Create Booking
      const booking = await Booking.create(_booking, { transaction: t });

      // step 2 -> Add booking Address
      bookingAddress.booking_id = booking.id;
      await BookingAddress.create(bookingAddress, { transaction: t });

      // step 3 -> Add Booking Category
      _bookingCategories.map(elem => {
        elem.booking_id = booking.id;
        elem.category_id = category.id;
      });
      await BookingCategory.bulkCreate(_bookingCategories, { transaction: t });

      // Send Push notification to Musician for booking
      //send push
      const musicianData: any = [];
      musicianData['company_name'] = '';
      musicianData['proposal_name'] = '';
      musicianData['user_name'] = '';
      musicianData['candidate_id'] = 0;
      musicianData['proposal_id'] = 0;
      musicianData['booking_id'] = booking.id;

      const paymentData = {
        booking_id: booking.id,
        user_id: user.id,
        name: user.en_full_name,
        email: user.email,
        amount: booking.total_amount,
        currancy: 'SAR',
        country: 'SA',
        ip: body.ipAddress,
      };

      paymentToken = await jwt.signPayload(paymentData);

      await pushService.sendNotification(
        PushNotificaitonTypes.BOOKING_REQUEST,
        [booking.musician_id],
        Actors.Musician,
        musicianData,
        user.id,
        null,
      );
      // After last time execute transaction will commit automatically as well as if any error it will rollback automatically
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success'), booking_id: bookingAddress.booking_id, paymentToken },
    });
  } catch (error) {
    console.log(error);
    // await transaction.rollback();
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const bookingListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number().required(),
  start_date: Joi.number(),
  end_date: Joi.number(),
  booking_type: Joi.number().required(),
});

interface BookingListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    start_date: number;
    end_date: number;
    booking_type: number;
  };
}
//  ---------------- |||| Booking List |||| -----------------------
export const bookingListHandler: RequestHandler = async (req: ValidatedRequest<BookingListRequestSchema>, res) => {
  const user = req.userData;
  const body = req.body;
  const language = req.headers.language;

  const start = Number(body.start ? body.start : 0);
  const limit = Number(body.limit ? Number(body.limit) + 1 : 11);
  console.log(user);
  let is_last = 1;

  try {
    const bookingWhere: any = { user_id: user.id, is_active: 1, is_deleted: 0 };

    if (body.start_date && body.end_date) {
      bookingWhere.booking_date = { [Op.between]: [body.start_date, body.end_date] };
    }
    if (body.booking_type == 6) {
      bookingWhere.status = { [Op.or]: [6, 7] };
    } else {
      bookingWhere.status = body.booking_type;
    }

    let bookings: any = await Booking.findAll({
      where: bookingWhere,
      include: [
        {
          model: User,
          as: 'musician',
        },
        {
          model: BookingAddress,
          as: 'booking_address',
        },
        {
          model: BookingCategory,
          where: { language_code: language },
          as: 'booking_category',
        },
      ],
      order: [['id', 'DESC']],
      attributes: [
        'id',
        ['event_date', 'date'],
        'start_time',
        'end_time',
        ['is_fixed', 'booked_type'],
        ['total_amount', 'amount'],
        [Sequelize.fn('', Sequelize.col('`musician`.`en_full_name`')), 'musician_name'],
        [Sequelize.fn('', Sequelize.col('`booking_address`.`address`')), 'address'],
        [Sequelize.fn('', Sequelize.col('`booking_category`.`name`')), 'category_name'],
      ],
      offset: body.start,
      limit: body.limit,
      logging: true,
    });

    if (bookings.length >= limit) {
      bookings.pop();
      is_last = 0;
    }

    bookings = bookings.map(elem => {
      const elemJSON = elem.toJSON();
      delete elemJSON['musician'];
      delete elemJSON['booking_address'];
      delete elemJSON['booking_category'];
      return elemJSON;
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success'), bookings, is_last },
    });
  } catch (error) {
    console.log(error);
    // await transaction.rollback();
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| Booking Details |||| -----------------------
export const bookingDetailBodySchema = Joi.object({
  booking_id: Joi.number().required(),
});

interface BookingDetailRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    booking_id: number;
  };
}

export const bookingDetailHandler: RequestHandler = async (req: ValidatedRequest<BookingDetailRequestSchema>, res) => {
  const body = req.body;
  const user = req.userData;
  const language = req.headers.language;

  try {
    let booking: any = await Booking.findOne({
      where: { id: body.booking_id, is_deleted: 0, is_active: 1 },
      include: [
        {
          model: User,
          include: [
            {
              model: UserDetails,
              as: 'details',
            },
          ],
          as: 'musician',
          required: false,
        },
        {
          model: User,
          as: 'customer',
          required: false,
        },

        {
          model: BookingAddress,
          as: 'booking_address',
        },
        {
          model: BookingCategory,
          where: { language_code: language },
          as: 'booking_category',
        },
        {
          model: Rating,
          as: 'booking_review',
          required: false,
        },
        {
          model: BookingCancellationReason,
          as: 'booking_cancellation_reson',
          required: false,
        },
      ],
      order: [['id', 'DESC']],
      attributes: [
        'id',
        ['event_date', 'posted_date'],
        'booking_date',
        'start_time',
        'end_time',
        'description',
        'is_refunded',
        'refund_status',
        'notify_to_admin',
        ['is_fixed', 'booked_type'],
        ['total_amount', 'amount'],
        ['status', 'status_code'],
        ['hours', 'total_booked_hour'],
        ['cancelled_date', 'cancel_date'],
        [Sequelize.fn('', Sequelize.col('`musician`.`en_full_name`')), 'musician_name'],
        [Sequelize.fn('', Sequelize.col('`musician`.`image`')), 'image'],
        [Sequelize.fn('', Sequelize.col('`musician`.`dial_code`')), 'dial_code'],
        [Sequelize.fn('', Sequelize.col('`musician`.`phone_number`')), 'phone_number'],

        [Sequelize.fn('', Sequelize.col('`customer`.`en_full_name`')), 'customer_name'],
        [Sequelize.fn('', Sequelize.col('`customer`.`image`')), 'customer_image'],

        [Sequelize.fn('', Sequelize.col('`musician->details`.`hourly_rate`')), 'hourly_rate'],
        [Sequelize.fn('', Sequelize.col('`musician->details`.`fix_rate`')), 'full_day_rate'],

        [Sequelize.fn('', Sequelize.col('`booking_review`.`rating`')), 'rate'],
        [Sequelize.fn('', Sequelize.col('`booking_review`.`comments`')), 'review'],

        [Sequelize.fn('', Sequelize.col('`booking_cancellation_reson`.`reason`')), 'cancel_reason'],

        [Sequelize.fn('', Sequelize.col('`booking_address`.`address`')), 'address'],
        [Sequelize.fn('', Sequelize.col('`booking_address`.`lat`')), 'latitude'],
        [Sequelize.fn('', Sequelize.col('`booking_address`.`lng`')), 'longitude'],
        [Sequelize.fn('', Sequelize.col('`booking_category`.`name`')), 'category_name'],
      ],
    });

    if (!booking) {
      return ReE(res, message(language, 'booking_not_found'), 200);
    }

    booking = booking.toJSON();
    delete booking['musician'];
    delete booking['customer'];
    delete booking['booking_address'];
    delete booking['booking_category'];
    delete booking['booking_review'];
    delete booking['booking_cancellation_reson'];

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success'), booking },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| Rate Booking |||| -----------------------
export const rateBookingBodySchema = Joi.object({
  booking_id: Joi.number().required(),
  rate: Joi.number().required(),
  review: Joi.string().required(),
});

interface RateBookingRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    booking_id: number;
    rate: number;
    review: string;
  };
}

export const rateBookingHandler: RequestHandler = async (req: ValidatedRequest<RateBookingRequestSchema>, res) => {
  const body = req.body;
  const user = req.userData;
  const language = req.headers.language;

  try {
    const booking = await Booking.findOne({
      where: { id: body.booking_id, user_id: user.id },
    });

    if (!booking) {
      return ReE(res, message(language, 'booking_not_found'), 200);
    }

    if (booking.status !== BookingStatus.Completed) {
      return ReE(res, message(language, 'can_not_rate_before_complete_event'), 200);
    }

    const objRating = {} as Rating;
    objRating.booking_id = booking.id;
    objRating.musician_id = booking.musician_id;
    objRating.user_id = user.id;
    objRating.rating = body.rate;
    objRating.comments = body.review;
    objRating.i_by = user.id;

    await sequelize.transaction(async t => {
      await Rating.create(objRating, { transaction: t });

      const getNewRate: any = await Rating.findOne({
        where: { musician_id: booking.musician_id },
        attributes: [[Sequelize.fn('AVG', Sequelize.col('rating')), 'rating']],
      });

      await userService.updateUserDetailsByField('user_id', booking.musician_id, {
        avg_rating: getNewRate.rating,
      });
      const musicianData: any = [];
      musicianData['company_name'] = '';
      musicianData['proposal_name'] = '';
      musicianData['user_name'] = user.en_full_name ?? '';
      musicianData['candidate_id'] = 0;
      musicianData['proposal_id'] = booking.id;
      musicianData['booking_id'] = booking.id;
      // console.log(musicianData);
      //send push
      await pushService.sendNotification(
        PushNotificaitonTypes.RATING,
        [booking.musician_id],
        Actors.Musician,
        musicianData,
        user.id,
        null,
      );
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'rating_saved_success') },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| Cancel Booking |||| -----------------------
export const cancelBookingBodySchema = Joi.object({
  booking_id: Joi.number().required(),
  reason_id: Joi.number().required(),
  type: Joi.number().required(),
  other_reason: Joi.string()
    .allow('')
    .allow(null),
});

interface CancelBookingRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    booking_id: number;
    type: number;
    reason_id: number;
    other_reason: string;
  };
}

export const cancelBookingHandler: RequestHandler = async (req: ValidatedRequest<CancelBookingRequestSchema>, res) => {
  const body = req.body;
  const user = req.userData;
  const language = req.headers.language;
  const token = req.headers.authorization.split(' ')[1];

  try {
    let cancellationReason: Reason;
    if (body.reason_id == 0 && !body.other_reason) {
      return ReE(res, message(language, 'reason_required'), 200);
    }

    const booking = await Booking.findOne({
      where: { id: body.booking_id },
    });

    if (!booking) {
      return ReE(res, message(language, 'booking_not_found'), 200);
    }

    if (booking.status == BookingStatus.Completed) {
      return ReE(res, message(language, 'can_not_cancel_completed_event'), 200);
    }

    const a = moment();
    const b = moment(booking.event_date * 1000);

    const difference = a.diff(b, 'h');

    // if (difference > 2) {
    //   return ReE(res, message(language, 'can_not_cancel_event_before_2_hours'), 200);
    // }

    if (body.reason_id > 0) {
      cancellationReason = await Reason.findOne({ where: { id: body.reason_id } });
    }

    let apiMsg = 'booking_cancelled_success';
    await sequelize.transaction(async t => {
      if (body.type == 1) {
        await Booking.update(
          {
            status: BookingStatus.cancelledByUser,
            cancelled_date: moment().unix(),
            cancelled_by: user.id,
            cancelled_by_actor: Actors.Customer,
            refund_status: RefundStatus.PENDING,
            u_date: new Date(),
            u_by: user.id,
          },
          { where: { id: body.booking_id } },
        );

        const objBookingCancellationReson = {} as BookingCancellationReason;
        objBookingCancellationReson.booking_id = body.booking_id;
        objBookingCancellationReson.language_code = LanguageCodes.ENGLISH;
        if (body.reason_id > 0) {
          objBookingCancellationReson.reason = cancellationReason.reason;
        } else {
          objBookingCancellationReson.reason = body.other_reason;
        }

        await BookingCancellationReason.create(objBookingCancellationReson);
        //send push
        const musicianData: any = [];
        musicianData['company_name'] = '';
        musicianData['proposal_name'] = '';
        musicianData['user_name'] = user.en_full_name ?? '';
        musicianData['candidate_id'] = 0;
        musicianData['proposal_id'] = 0;
        musicianData['booking_id'] = body.booking_id;
        console.log(musicianData);
        await pushService.sendNotification(
          PushNotificaitonTypes.CANCEL_REQUEST,
          [booking.musician_id],
          Actors.Musician,
          musicianData,
          user.id,
          null,
        );
      } else {
        apiMsg = 'booking_rejected_success';
        const responseTime = moment().diff(moment(booking.createdAt), 'minute');
        await Booking.update(
          {
            status: BookingStatus.rejectededByMusician,
            cancelled_date: moment().unix(),
            cancelled_by: user.id,
            u_date: new Date(),
            u_by: user.id,
            musician_resp_time: responseTime,
          },
          { where: { id: body.booking_id } },
        );
        //update cancellation percentage of this musician
        //send push
        const musicianData: any = [];
        musicianData['company_name'] = '';
        musicianData['proposal_name'] = '';
        musicianData['user_name'] = user.en_full_name ?? '';
        musicianData['candidate_id'] = 0;
        musicianData['proposal_id'] = 0;
        musicianData['booking_id'] = body.booking_id;
        console.log(musicianData);
        await pushService.sendNotification(
          PushNotificaitonTypes.REQUEST_REJECTED,
          [booking.user_id],
          Actors.Customer,
          musicianData,
          user.id,
          null,
        );
        const percentage = await userService.updateCancellationPercentage(user.id);
        const blockData = await userService.blockMusician(user.id, token);
      }
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, apiMsg) },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| Accept Booking |||| -----------------------
export const acceptBookingBodySchema = Joi.object({
  booking_id: Joi.number().required(),
});

interface AcceptBookingRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    booking_id: number;
  };
}

export const acceptBookingHandler: RequestHandler = async (req: ValidatedRequest<AcceptBookingRequestSchema>, res) => {
  const body = req.body;
  const user = req.userData;
  const language = req.headers.language;

  try {
    const booking = await Booking.findOne({
      // where: { id: body.booking_id, user_id: user.id },
      where: { id: body.booking_id },
    });

    if (!booking) {
      return ReE(res, message(language, 'booking_not_found'), 200);
    }

    if (booking.status == BookingStatus.Completed) {
      return ReE(res, message(language, 'can_not_accept_completed_event'), 200);
    }
    if (booking.status == BookingStatus.Confirmed) {
      return ReE(res, message(language, 'already_accepted_booking'), 200);
    }

    await sequelize.transaction(async t => {
      const responseTime = moment().diff(moment(booking.createdAt), 'minute');
      await Booking.update(
        {
          status: BookingStatus.Confirmed,
          u_date: new Date(),
          u_by: user.id,
          musician_resp_time: responseTime,
        },
        { where: { id: body.booking_id } },
      );
      const musicianData: any = [];
      musicianData['company_name'] = '';
      musicianData['proposal_name'] = '';
      musicianData['user_name'] = user.en_full_name ?? '';
      musicianData['candidate_id'] = 0;
      musicianData['proposal_id'] = 0;
      musicianData['booking_id'] = booking.id;
      console.log(musicianData);
      //send push
      await pushService.sendNotification(
        PushNotificaitonTypes.REQUEST_ACCEPTED,
        [booking.user_id],
        Actors.Customer,
        musicianData,
        user.id,
        null,
      );
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success_accepted_booking') },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| Complete Booking |||| -----------------------
export const completeBookingBodySchema = Joi.object({
  booking_id: Joi.number().required(),
});

interface CompleteBookingRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    booking_id: number;
  };
}

export const completeBookingHandler: RequestHandler = async (
  req: ValidatedRequest<CompleteBookingRequestSchema>,
  res,
) => {
  const body = req.body;
  const user = req.userData;
  const language = req.headers.language;

  try {
    const booking = await Booking.findOne({
      // where: { id: body.booking_id, user_id: user.id },
      where: { id: body.booking_id },
    });

    if (!booking) {
      return ReE(res, message(language, 'booking_not_found'), 200);
    }

    if (booking.status == BookingStatus.Completed) {
      return ReE(res, message(language, 'already_completed_booking'), 200);
    }
    //check booking date is not future date
    const currDate = moment()
      .utc()
      .unix();
    console.log('currDate', currDate);
    console.log('start_time', booking.start_time);

    if (currDate < parseInt(booking.start_time)) {
      return ReE(res, message(language, 'no_complete_future_booking'), 200);
    }

    await sequelize.transaction(async t => {
      await Booking.update(
        {
          status: BookingStatus.Completed,
          u_date: new Date(),
          u_by: user.id,
        },
        { where: { id: body.booking_id } },
      );
      const objMusicianPayments = {} as MusicianPayments;
      objMusicianPayments.booking_id = body.booking_id;
      objMusicianPayments.musician_id = booking.musician_id;
      objMusicianPayments.paid_amount = 0;
      objMusicianPayments.outstanding_amount = booking.musician_earning;
      objMusicianPayments.payment_date = moment()
        .unix()
        .toString();
      objMusicianPayments.i_date = new Date();
      objMusicianPayments.i_by = user.id;
      objMusicianPayments.u_date = new Date();
      objMusicianPayments.u_by = user.id;

      await MusicianPayments.create(objMusicianPayments, { transaction: t });

      const musicianData: any = [];
      musicianData['company_name'] = '';
      musicianData['proposal_name'] = '';
      musicianData['user_name'] = user.en_full_name ?? '';
      musicianData['candidate_id'] = 0;
      musicianData['proposal_id'] = 0;
      musicianData['booking_id'] = body.booking_id;
      console.log(musicianData);
      //send push
      await pushService.sendNotification(
        PushNotificaitonTypes.REQUEST_COMPLETED,
        [booking.user_id],
        Actors.Customer,
        musicianData,
        user.id,
        null,
      );
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success_completed_booking') },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| notify To Admin |||| -----------------------
export const notifyToAdminBodySchema = Joi.object({
  booking_id: Joi.number().required(),
  title: Joi.string().required(),
  message: Joi.string().required(),
});

interface NotifyToAdminRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    booking_id: number;
    title: string;
    message: string;
  };
}

export const notifyToAdminHandler: RequestHandler = async (req: ValidatedRequest<NotifyToAdminRequestSchema>, res) => {
  const body = req.body;
  const user = req.userData;
  const language = req.headers.language;

  try {
    const UserIds = [];
    const UserData = await User.findOne({
      where: { id: user.id },
    });
    const AdminData = await User.findAll({
      where: { actor: Actors.Admin, is_deleted: 0 },
    });
    if (AdminData) {
      await forEach(AdminData, async user => {
        UserIds.push(user.id);
      });
    }
    const booking = await Booking.findOne({
      // where: { id: body.booking_id, user_id: user.id },
      where: { id: body.booking_id },
    });

    if (!booking) {
      return ReE(res, message(language, 'booking_not_found'), 200);
    }

    if (booking.notify_to_admin == NotifyToAdminStatus.Requested) {
      return ReE(res, message(language, 'already_submitted_request'), 200);
    }

    await sequelize.transaction(async t => {
      await Booking.update(
        {
          notify_to_admin: NotifyToAdminStatus.Requested,
          u_date: new Date(),
          u_by: user.id,
        },
        { where: { id: body.booking_id } },
      );
      //send notification to admin
      const getLanguages = await Language.findAll();
      const type = 'notify_to_admin';
      let notificationData: any = [];
      // console.log('in 2', data);
      notificationData = await map(getLanguages, async language => {
        // let title = 'Request for refund' ;
        // let tmpBody = UserData.en_full_name+' has requested for refund of booking #'+body.booking_id ;
        const title = body.title;
        const tmpBody = body.message;
        const notification_type = type;

        const _notification = {
          title: title,
          body: tmpBody,
          notification_type: notification_type,
          date: moment(),
          to_type: Actors.Admin,
          language_code: language.language_code,

          booking_id: body.booking_id,
        };
        // console.log('>>>>> in 3', _notification);

        return _notification;
      });
      await pushService.saveNotificationData(notificationData, user.id, UserIds);
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success') },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const createBooking: any = () =>
  router.post(
    '/create',
    validator.body(createBookingBodySchema),
    mainAuthMiddleware,
    handleError(createBookingHandler),
  );

export const Bookings: any = () =>
  router.post('/list', validator.body(bookingListBodySchema), mainAuthMiddleware, handleError(bookingListHandler));

export const BookingDetail: any = () =>
  router.post(
    '/detail',
    validator.body(bookingDetailBodySchema),
    mainAuthMiddleware,
    handleError(bookingDetailHandler),
  );

export const RateBooking: any = () =>
  router.post('/rate', validator.body(rateBookingBodySchema), mainAuthMiddleware, handleError(rateBookingHandler));

export const CancelBooking: any = () =>
  router.post(
    '/cancel',
    validator.body(cancelBookingBodySchema),
    mainAuthMiddleware,
    handleError(cancelBookingHandler),
  );

export const AcceptBooking: any = () =>
  router.post(
    '/accept',
    validator.body(acceptBookingBodySchema),
    mainAuthMiddleware,
    handleError(acceptBookingHandler),
  );

export const CompleteBooking: any = () =>
  router.post(
    '/complete',
    validator.body(completeBookingBodySchema),
    mainAuthMiddleware,
    handleError(completeBookingHandler),
  );

export const NotifyToAdmin: any = () =>
  router.post(
    '/notifyToAdmin',
    validator.body(notifyToAdminBodySchema),
    mainAuthMiddleware,
    handleError(notifyToAdminHandler),
  );
