/* eslint-disable @typescript-eslint/no-explicit-any */
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { Sequelize, Op } from 'sequelize';
import * as _ from 'lodash';

import handleError from '../../../../middlewares/handle-error';
import { mainAuthMiddleware, message } from '../../../../middlewares/auth.middleware';
import { ReE } from '../../../../services/util.service';
import { BookingStatus, MusicianPaymentRequest } from '../../../../utils/constants';

import { User } from '../../../../models/users.model';
import { UserDetails } from '../../../../models/userDetails.model';
import { Notifications } from '../../../../models/notification.model';

import { Booking } from '../../../../models/bookings.model';
import { BookingAddress } from '../../../../models/bookingAddresses.model';
import { BookingCategory } from '../../../../models/bookingCategory.model';
import * as userService from '../../../../utils/user';
import { RandomService } from '../../../../services/random';
import { MusicianPayments } from '../../../../models/musicianPayments.model';
import { PaymentRequest } from '../../../../models/paymentRequest.model';
import { setUpSequelize } from '../../../../db/sql/connection';

const sequelize: Sequelize = setUpSequelize();
const router = Router();
const validator = createValidator({ passError: true });

export const homeDataBodySchema = Joi.object({
  from_date: Joi.number(),
  to_date: Joi.number(),
});

interface HomeDataRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    from_date: number;
    to_date: number;
  };
}

export const homeDataHandler: RequestHandler = async (req: ValidatedRequest<HomeDataRequestSchema>, res) => {
  const body = req.body;
  const UserData = req.userData;
  const language = req.headers.language;

  try {
    const notification_unread_count = await Notifications.count({
      where: {
        [Op.and]: [
          Sequelize.where(Sequelize.fn('!FIND_IN_SET', UserData.id, Sequelize.col('deleted_by')), { [Op.gte]: 1 }),
          Sequelize.where(Sequelize.fn('!FIND_IN_SET', UserData.id, Sequelize.col('read_by')), { [Op.gte]: 1 }),
          Sequelize.where(Sequelize.fn('FIND_IN_SET', UserData.id, Sequelize.col('receiver_ids')), { [Op.gte]: 1 }),
        ],
      },
    });

    const user = await User.findOne({
      where: { id: UserData.id },
      include: [{ model: UserDetails, as: 'details' }],
      attributes: [
        'id',
        [Sequelize.fn('', Sequelize.col('details.avg_rating')), 'average_rate'],
        [Sequelize.fn('', Sequelize.col('details.total_earnings')), 'total_earnings'],
        // [Sequelize.fn('', Sequelize.col('details.total_jobs_done')), 'total_jobs'],
        [Sequelize.fn('', Sequelize.col('details.cancellation_percentage')), 'cancellation_percentage'],
        [
          Sequelize.literal(
            '(SELECT COUNT(*) FROM bookings WHERE status=3 and musician_id = User.id AND is_deleted = 0)',
          ),
          'total_jobs',
        ],
      ],
    });
    const newRequestWhere = { is_deleted: 0, is_active: 1, musician_id: user.id, status: BookingStatus.Pending };
    const bookingsWhere = { is_deleted: 0, is_active: 1, musician_id: user.id, status: BookingStatus.Confirmed };
    const historyWhere = {
      is_deleted: 0,
      is_active: 1,
      musician_id: user.id,
      status: {
        [Op.in]: [
          BookingStatus.Completed,
          BookingStatus.cancelledByAdmin,
          BookingStatus.cancelledByMusician,
          BookingStatus.rejectededByMusician,
          BookingStatus.cancelledByUser,
        ],
      },
    };

    if (body.from_date && body.to_date) {
      _.set(newRequestWhere, 'event_date', { [Op.between]: [body.from_date, body.to_date] });
      _.set(bookingsWhere, 'event_date', { [Op.between]: [body.from_date, body.to_date] });
      _.set(historyWhere, 'event_date', { [Op.between]: [body.from_date, body.to_date] });
    }

    let new_request = await Booking.findAll({
      where: newRequestWhere,
      include: [
        {
          model: User,
          as: 'customer',
          attributes: [
            'id',
            ['en_full_name', 'name'],
            'image',
            ['dial_code', 'country_code'],
            ['phone_number', 'mobile_number'],
          ],
        },
        {
          model: BookingAddress,
          as: 'booking_address',
          attributes: ['address', 'city', 'state', 'country', 'landmark', ['lat', 'latitude'], ['lng', 'longitude']],
        },
        {
          model: BookingCategory,
          as: 'booking_category',
          where: { language_code: language },
        },
      ],
      attributes: [
        'id',
        ['event_date', 'date'],
        'booking_date',
        'start_time',
        'end_time',
        'status',
        ['is_fixed', 'booked_type'],
        ['total_amount', 'amount'],
      ],
      order: [['id', 'DESC']],
    });

    let bookings = await Booking.findAll({
      where: bookingsWhere,
      include: [
        {
          model: User,
          as: 'customer',
          attributes: [
            'id',
            ['en_full_name', 'name'],
            'image',
            ['dial_code', 'country_code'],
            ['phone_number', 'mobile_number'],
          ],
        },
        {
          model: BookingAddress,
          as: 'booking_address',
          attributes: ['address', 'city', 'state', 'country', 'landmark', ['lat', 'latitude'], ['lng', 'longitude']],
        },
        {
          model: BookingCategory,
          as: 'booking_category',
          where: { language_code: language },
        },
      ],
      attributes: [
        'id',
        ['event_date', 'date'],
        'booking_date',
        'start_time',
        'end_time',
        'status',
        ['is_fixed', 'booked_type'],
        ['total_amount', 'amount'],
      ],
      order: [['id', 'DESC']],
    });

    let history = await Booking.findAll({
      where: historyWhere,
      include: [
        {
          model: User,
          as: 'customer',
          attributes: [
            'id',
            ['en_full_name', 'name'],
            'image',
            ['dial_code', 'country_code'],
            ['phone_number', 'mobile_number'],
          ],
        },
        {
          model: BookingAddress,
          as: 'booking_address',
          attributes: ['address', 'city', 'state', 'country', 'landmark', ['lat', 'latitude'], ['lng', 'longitude']],
        },
        {
          model: BookingCategory,
          as: 'booking_category',
          where: { language_code: language },
        },
      ],
      attributes: [
        'id',
        ['event_date', 'date'],
        'booking_date',
        'start_time',
        'end_time',
        'status',
        ['is_fixed', 'booked_type'],
        ['total_amount', 'amount'],
      ],
      order: [['id', 'DESC']],
    });

    if (new_request) {
      new_request = new_request.map(elem => {
        const elemJSON: any = elem.toJSON();
        // delete elemJSON['customer'];
        // delete elemJSON['booking_address'];
        // delete elemJSON['booking_category'];
        return elemJSON;
      });
    }

    if (bookings) {
      bookings = bookings.map(elem => {
        const elemJSON: any = elem.toJSON();
        // delete elemJSON['customer'];
        // delete elemJSON['booking_address'];
        // delete elemJSON['booking_category'];
        return elemJSON;
      });
    }

    if (history) {
      history = history.map(elem => {
        const elemJSON: any = elem.toJSON();
        // delete elemJSON['customer'];
        // delete elemJSON['booking_address'];
        // delete elemJSON['booking_category'];
        return elemJSON;
      });
    }

    const data = {
      notification_unread_count,
      new_request,
      bookings,
      history,
      user,
    };
    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success'), data },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| MY REVIEWS |||| -----------------------
export const myReviewsBodySchema = Joi.object({
  rating_type: Joi.number().required(),
  musician_id: Joi.number(),
});

interface MyReviewsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    rating_type: number;
    musician_id: number;
  };
}
export const myReviewsHandler: RequestHandler = async (req: ValidatedRequest<MyReviewsRequestSchema>, res) => {
  const language = req.headers.language;
  try {
    const body = req.body;
    const user = req.userData;
    const token = req.headers.authorization.split(' ')[1];
    const userId = req.body.musician_id
      ? req.body.musician_id
      : user && user != null && user.id != null
      ? user.id
      : null;
    let profile = await userService.getMusicianResponse(userId, language, body.rating_type);

    if (_.isNil(profile)) {
      // return ReE(res, message(language, 'no_user_found'));
      profile = {};
    }

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
        musician: profile,
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| MY Earning |||| -----------------------
export const myEarningBodySchema = Joi.object({});

interface MyEarningRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {};
}
export const myEarningHandler: RequestHandler = async (req: ValidatedRequest<MyEarningRequestSchema>, res) => {
  const language = req.headers.language;
  try {
    // const body = req.body;
    const random = new RandomService();
    const UserData = req.userData;
    const token = req.headers.authorization.split(' ')[1];
    let due_to_admin = 0;
    const user = await User.findOne({
      where: { id: UserData.id },
      include: [{ model: UserDetails, as: 'details' }],
    });
    let dueto = await MusicianPayments.findAll({
      where: {
        is_deleted: 0,
        musician_id: user.id,
        outstanding_amount: {
          [Op.ne]: null,
        },
        // paid_amount: {
        //   [Op.eq]: 0,
        // },
      },
      attributes: ['id', ['payment_date', 'date'], 'booking_id', ['outstanding_amount', 'amount']],
      order: [['id', 'DESC']],
      logging: true,
    });

    let earning = await MusicianPayments.findAll({
      where: {
        is_deleted: 0,
        musician_id: user.id,
        paid_amount: {
          [Op.ne]: 0,
        },
      },
      attributes: ['id', ['payment_date', 'date'], 'booking_id', ['paid_amount', 'amount']],
      order: [['id', 'DESC']],
    });
    if (dueto) {
      // dueto = dueto.map(elem => {
      //   const elemJSON: any = elem.toJSON();
      //   due_to_admin = due_to_admin + elemJSON.amount;
      //   elemJSON.currency = random.getCurrency();
      //   return elemJSON;
      // });

      dueto = await Promise.all(
        dueto.map(
          async (elem): Promise<any> => {
            const elemJSON: any = elem.toJSON();
            due_to_admin = due_to_admin + elemJSON.amount;
            elemJSON.currency = random.getCurrency();
            const paymentRequest = await PaymentRequest.findOne({
              where: { booking_id: elemJSON.booking_id, musician_id: user.id, is_deleted: 0 },
              order: [['id', 'DESC']],
            });
            elemJSON.is_request_submitted = 0;
            if (paymentRequest) {
              elemJSON.is_request_submitted = 1;
              if (paymentRequest.is_approved == MusicianPaymentRequest.DECLINED) {
                elemJSON.is_request_submitted = 0;
              }
            }

            return elemJSON;
          },
        ),
      );
    }
    if (earning) {
      earning = earning.map(elem => {
        const elemJSON: any = elem.toJSON();
        elemJSON.currency = random.getCurrency();
        return elemJSON;
      });
    }
    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
        total_earnings: user.details.total_earnings,
        currency: random.getCurrency(),
        due_to_admin: due_to_admin,
        dueto,
        earning,
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| Request for due amount |||| -----------------------
export const requestForDueAmountBodySchema = Joi.object({
  booking_id: Joi.number().required(),
  subject: Joi.string(),
  message: Joi.string(),
});

interface RequestForDueAmountRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    booking_id: number;
    subject: string;
    message: string;
  };
}

export const requestForDueAmountHandler: RequestHandler = async (
  req: ValidatedRequest<RequestForDueAmountRequestSchema>,
  res,
) => {
  const body = req.body;
  const user = req.userData;
  const language = req.headers.language;

  try {
    const booking = await Booking.findOne({
      // where: { id: body.booking_id, user_id: user.id },
      where: { id: body.booking_id, musician_id: user.id, is_deleted: 0 },
    });

    if (!booking) {
      return ReE(res, message(language, 'booking_not_found'), 200);
    }

    if (booking.status != BookingStatus.Completed) {
      return ReE(res, message(language, 'can_not_request_for_this_booking'), 200);
    }
    const paymentRequest = await PaymentRequest.findOne({
      // where: { id: body.booking_id, user_id: user.id },
      where: { booking_id: body.booking_id, musician_id: user.id, is_deleted: 0 },
      order: [['id', 'DESC']],
    });
    if (paymentRequest) {
      if (paymentRequest.is_approved != MusicianPaymentRequest.DECLINED) {
        return ReE(res, message(language, 'already_submitted_request'), 200);
      }
    }
    await sequelize.transaction(async t => {
      const objMusicianPayments = {} as PaymentRequest;
      objMusicianPayments.booking_id = body.booking_id;
      objMusicianPayments.musician_id = booking.musician_id;
      objMusicianPayments.is_approved = 0;
      objMusicianPayments.amount = booking.musician_earning;
      objMusicianPayments.subject = body.subject;
      objMusicianPayments.message = body.message;
      objMusicianPayments.i_date = new Date();
      objMusicianPayments.i_by = user.id;
      objMusicianPayments.u_date = new Date();
      objMusicianPayments.u_by = user.id;

      await PaymentRequest.create(objMusicianPayments, { transaction: t });
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success') },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};
export const dashboard: any = () =>
  router.post('/dashboard', validator.body(homeDataBodySchema), mainAuthMiddleware, handleError(homeDataHandler));

export const myReviews: any = () =>
  router.post('/myreviews', validator.body(myReviewsBodySchema), mainAuthMiddleware, handleError(myReviewsHandler));

export const myEarning: any = () =>
  router.post('/myearning', validator.body(myEarningBodySchema), mainAuthMiddleware, handleError(myEarningHandler));
export const requestForDueAmount: any = () =>
  router.post(
    '/requestfordueamount',
    validator.body(requestForDueAmountBodySchema),
    mainAuthMiddleware,
    handleError(requestForDueAmountHandler),
  );
