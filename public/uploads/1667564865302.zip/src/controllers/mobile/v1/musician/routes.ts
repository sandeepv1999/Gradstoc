/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import { dashboard, myReviews, myEarning, requestForDueAmount } from './controllers';

const router = Router();

export const musician: any = () => router.use([dashboard(), myReviews(), myEarning(), requestForDueAmount()]);
