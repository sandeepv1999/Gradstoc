import { Router } from 'express';
import { customerAuth } from './customer-auth/routes';
import { address } from './address/routes';
import { common } from './common/routes';
import { musicianAuth } from './musician-auth/routes';
import { portfolio } from './portfolio/routes';
import { customer } from './customer/routes';
import { musician } from './musician/routes';
import { booking } from './bookings/routes';
const router = Router();

router.use('/auth/customer', customerAuth());
router.use('/auth/musician', musicianAuth());
router.use('/address', address());
router.use('/common', common());
router.use('/portfolio', portfolio());
router.use('/customer', customer());
router.use('/musician', musician());
router.use('/booking', booking());

// Health status
router.get('/status', (req, res) => res.json({ status: 'MOBILE V1 UP' }));

export default router;
