import * as Joi from '@hapi/joi';
import * as _ from 'lodash';
import * as authService from '../../../../utils/auth';
import * as smsservice from '../../../../services/sms.service';
import * as userService from '../../../../utils/user';

import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { Messages_ar, Messages_en } from '../../../../utils/message';
/* eslint-disable @typescript-eslint/no-explicit-any */
import { RequestHandler, Router } from 'express';
import { mainAuthMiddleware, message, simpleAuthMiddleware } from '../../../../middlewares/auth.middleware';

import { AccountRequest } from '../../../../models/account_request.model';
import { Actors } from '../../../../utils/constants';
import { RandomService } from '../../../../services/random';
import { ReE } from '../../../../services/util.service';
import { Token } from '../../../../models/tokens.model';
import { User } from '../../../../models/users.model';
import bcrypt from 'bcryptjs';
import { createValidator } from 'express-joi-validation';
import handleError from '../../../../middlewares/handle-error';
import moment from 'moment';
import { sendVerificationEmail } from '../../../../services/email.service';

const router = Router();
const validator = createValidator({ passError: true });

// ---------------- |||| GET TOKEN |||| -----------------------
export const getTokenBodySchema = Joi.object({
  device_id: Joi.string().allow('', null),
  device_type: Joi.string().required(),
});

interface GetTokenRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    device_id: string;
    device_type: string;
  };
}

export const tokenHandler: RequestHandler = async (req: ValidatedRequest<GetTokenRequestSchema>, res) => {
  const data = req.body;
  const language = req.headers.language;
  const generateToken = new RandomService();

  try {
    if (data.device_id) {
      const findTokenByDeviceIdData = await authService.findTokenByDeviceID(data.device_id);
      if (findTokenByDeviceIdData) {
        return res.send({
          success: 1,
          error: [],
          data: {
            message: message(language, 'success'),
            auth: { token: findTokenByDeviceIdData.access_token, type: 'Bearer' },
          },
        });
      }
    }
    const createTokenData = await authService.createToken({
      device_id: data.device_id,
      device_type: data.device_type,
      access_token: generateToken.salt(),
    });
    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success'), auth: { token: createTokenData.access_token, type: 'Bearer' } },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| LOGIN |||| -----------------------
export const loginBodySchema = Joi.object({
  country_code: Joi.string(),
  mobile_number: Joi.number().required(),
  password: Joi.string().required(),
  device_type: Joi.string().required(),
  device_id: Joi.string().allow('', null),
});

interface LoginRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    country_code: string;
    mobile_number: number;
    password: string;
    device_type: string;
    device_id: string;
  };
}

export const loginHandler: RequestHandler = async (req: ValidatedRequest<LoginRequestSchema>, res) => {
  const body = req.body;
  const language = req.headers.language;
  try {
    const getUserByPhone = await User.scope('customerLogin').findOne({
      where: { phone_number: body.mobile_number, actor: Actors.Customer },
    });

    if (_.isNil(getUserByPhone)) {
      return ReE(res, message(language, 'no_user_found'));
    }

    if (!getUserByPhone.is_active) {
      return ReE(res, message(language, 'account_inactive'));
    }

    if (await bcrypt.compare(body.password, getUserByPhone.password)) {
      const token = req.headers.authorization.split(' ')[1];
      const data = {
        user_id: getUserByPhone.id,
        device_type: body.device_type,
        device_id: body.device_id,
        is_notification: 1,
        last_login: moment().unix(),
        user_language: req.headers.language ? req.headers.language : 'en',
      };
      await authService.updateToken(token, data);

      const user: any = getUserByPhone.toJSON();
      if (!user.address) {
        _.set(user, 'address', {});
      }
      if (!user.bank) {
        _.set(user, 'bank', {});
      }

      await Object.keys(user).forEach(key => {
        if (user[key] == undefined && user[key] == null) {
          user[key] = '';
        }
      });

      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: message(language, 'success'),
          auth: { token: token, type: 'Bearer' },
          user,
        },
      });
    } else {
      return ReE(res, message(language, 'wrong_password'), 200);
    }
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| ACCOUNT REQUEST |||| -----------------------
export const accountRequestBodySchema = Joi.object({
  country_code: Joi.string(),
  mobile_number: Joi.number().required(),
});

interface AccountRequestRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    country_code: string;
    mobile_number: number;
  };
}

export const accountRequestHandler: RequestHandler = async (
  req: ValidatedRequest<AccountRequestRequestSchema>,
  res,
) => {
  const body = req.body;
  const language = req.headers.language;
  try {
    const getUserByPhone = await User.findOne({
      where: { phone_number: body.mobile_number, actor: Actors.Customer },
    });

    if (getUserByPhone) {
      return ReE(res, message(language, 'phone_number_already_exists'));
    }

    const OTP = userService.generateOTP();

    const userData = {
      phone_number: body.mobile_number,
      dial_code: body.country_code,
      otp: OTP,
    };

    const accountRequest = await AccountRequest.findOne({
      where: { phone_number: body.mobile_number, dial_code: body.country_code },
    });

    if (accountRequest) {
      await AccountRequest.update(userData, { where: { id: accountRequest.id } });

      const appName = language == 'ar' ? Messages_ar['appName'] : Messages_en['appName'];
      const content = 'Welcome to ' + appName + ', Your new OTP is :' + OTP;
      await smsservice.sendSMS(body.country_code + body.mobile_number, content);
    }

    await AccountRequest.create(userData);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'otp_send_success'),
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| SIGN UP |||| -----------------------
export const signUpBodySchema = Joi.object({
  country_code: Joi.string(),
  mobile_number: Joi.number().required(),
  password: Joi.string().required(),
});

interface SignUpRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    country_code: string;
    mobile_number: number;
    password: string;
  };
}

export const signUpHandler: RequestHandler = async (req: ValidatedRequest<SignUpRequestSchema>, res) => {
  const body = req.body;
  const token = req.headers['authorization'].split(' ')[1];
  const language = req.headers.language;
  try {
    const getUserByPhone = await User.findOne({
      where: { phone_number: body.mobile_number, actor: Actors.Customer },
    });

    if (getUserByPhone) {
      return ReE(res, message(language, 'phone_number_already_exists'));
    }
    const userData = {
      phone_number: body.mobile_number,
      actor: Actors.Customer,
      password: body.password,
      user_language: req.headers.language ? req.headers.language : 'en',
      is_phone_verified: 1,
    };

    const user = await userService.createUser(userData);

    // Set userId with token to default login

    if (user) {
      await Token.update({ user_id: user.id }, { where: { access_token: token } });
      await AccountRequest.destroy({ where: { phone_number: user.phone_number, dial_code: user.dial_code } });
      const _User: any = await User.scope('customerLogin').findOne({
        where: {
          id: user.id,
        },
      });

      if (!_User.address) {
        _.set(_User, 'address', {});
      }
      if (!_User.bank) {
        _.set(_User, 'bank', {});
      }

      await Object.keys(_User).forEach(key => {
        if (_User[key] == undefined && _User[key] == null) {
          _User[key] = '';
        }
      });

      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: message(language, 'register_success'),
          user: _User,
        },
      });
    } else {
      return ReE(res, message(language, 'something_went_wrong'));
    }
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| VERIFY OTP |||| -----------------------
export const verifyOTPBodySchema = Joi.object({
  country_code: Joi.string(),
  mobile_number: Joi.number().required(),
  otp: Joi.number().required(),
});

interface VerifyOTPRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    country_code: string;
    mobile_number: number;
    otp: number;
  };
}

export const verifyOTPUpHandler: RequestHandler = async (req: ValidatedRequest<VerifyOTPRequestSchema>, res) => {
  const body = req.body;
  const language = req.headers.language;
  try {
    const getAccountRequest = await AccountRequest.findOne({
      where: { phone_number: body.mobile_number, dial_code: body.country_code },
    });

    if (!getAccountRequest) {
      const user = await userService.getUserByField('phone_number', body.mobile_number);
      if (!user) {
        return ReE(res, message(language, 'no_user_found'));
      } else {
        if (user.otp == body.otp) {
          return res.status(200).send({
            success: 1,
            error: [],
            data: {
              message: message(language, 'phone_number_verified_successfully'),
            },
          });
        } else {
          return ReE(res, message(language, 'incorrect_otp'));
        }
      }
    }

    if (getAccountRequest.otp == body.otp) {
      // await userService.updateUserByField('phone_number', body.mobile_number, {
      //   is_phone_verified: 1,
      // });

      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: message(language, 'phone_number_verified_successfully'),
        },
      });
    } else {
      return ReE(res, message(language, 'incorrect_otp'));
    }
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| COMPLETE PROFILE |||| -----------------------
export const completeProfileBodySchema = Joi.object({
  image: Joi.string().allow(null, ''),
  email: Joi.string().required(),
  mobile_number: Joi.number().required(),
  country_code: Joi.string().required(),
  name: Joi.string().required(),
});

interface CompleteProfileRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    image: string;
    email: string;
    mobile_number: number;
    country_code: string;
    name: string;
  };
}

export const CompleteProfileHandler: RequestHandler = async (
  req: ValidatedRequest<CompleteProfileRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  const token = req.headers.authorization.split(' ')[1];

  try {
    const data: any = {
      // image: body.image,
      email: body.email,
      phone_number: body.mobile_number,
      dial_code: body.country_code,
      en_full_name: body.name,
      is_profile_completed: 1,
      u_by: userData.id,
    };

    if (body.image) {
      data.image = body.image;
    }

    const _updated = await userService.updateUserByField('id', userData.id, data);

    if (_updated) {
      await authService.updateToken(token, { user_id: userData.id, user_language: language });

      const user = await User.scope('customerLogin').findOne({
        where: {
          id: userData.id,
        },
      });

      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: message(language, 'profile_update_success'),
          user,
        },
      });
    } else {
      return ReE(res, message(language, 'something_went_wrong'), 200);
    }

    // const user = await User.scope('customerLogin').findOne({
    //   where: {
    //     id: userData.id,
    //   },
    // });

    // return res.status(200).send({
    //   success: 1,
    //   error: [],
    //   data: {
    //     message: message(language, 'profile_update_success'),
    //     user,
    //   },
    // });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| COMPLETE ADDRESS |||| -----------------------
export const completeAddressBodySchema = Joi.object({
  address_type: Joi.number().required(),
  address: Joi.string().required(),
  land_mark: Joi.string().required(),
  latitude: Joi.number().required(),
  longitude: Joi.number().required(),
  city_id: Joi.number().required(),
  state_id: Joi.number().required(),
  country_id: Joi.number().required(),
});

interface CompleteAddressRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    address_type: string;
    address: string;
    land_mark: string;
    latitude: number;
    longitude: number;
    city_id: number;
    state_id: number;
    country_id: number;
  };
}

export const completeAddressHandler: RequestHandler = async (
  req: ValidatedRequest<CompleteAddressRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      user_id: userData.id,
      contact_person: userData.en_full_name,
      address: body.address,
      landmark: body.land_mark,
      address_type: body.address_type,
      city_id: body.city_id,
      state_id: body.state_id,
      country_id: body.country_id,
      lat: body.latitude,
      lng: body.longitude,
      is_default: 1,
      u_by: userData.id,
    };

    await userService.createAddress(data);

    await userService.updateUserByField('id', userData.id, {
      is_address_completed: 1,
    });

    const user = await User.scope('customerLogin').findOne({
      where: {
        id: userData.id,
      },
    });

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'address_saved_success'),
        user,
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'));
  }
};

// ---------------- |||| COMPLETE BANK DETAILS |||| -----------------------
export const completeBankDetailsBodySchema = Joi.object({
  full_name: Joi.string().required(),
  account_number: Joi.string().allow('', null),
  code: Joi.string().allow('',null),
  iban: Joi.string().allow('',null)
});

interface CompleteBankDetailsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    full_name: string;
    account_number: string;
    code: string;
    iban: string;
  };
}

export const completeBankDetailsHandler: RequestHandler = async (
  req: ValidatedRequest<CompleteBankDetailsRequestSchema>,
  res,
) => {

  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  let user = {};
  try {
    const data = {
      user_id: userData.id,
      full_name: body.full_name,
      bank_account_no: body.account_number,
      iban: body.iban,
      code: body.code,
      is_default: 1,
      i_by: userData.id,
    };

    await userService.createUserBank(data);

    await userService.updateUserByField('id', userData.id, {
      is_bank_completed: 1,
    });

    console.log(userData);

    if (userData.actor == Actors.Customer) {
      user = await User.scope('customerLogin').findOne({
        where: {
          id: userData.id,
        },
      });
    }

    if (userData.actor == Actors.Musician) {
      user = await userService.musicianResponse(userData.id, language);
    }

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'bank_details_saved_success'),
        user,
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| RESET PASSWORD |||| -----------------------
export const resetPasswordBodySchema = Joi.object({
  mobile_number: Joi.number().required(),
  country_code: Joi.string().required(),
  password: Joi.string().required(),
});

interface ResetPasswordRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    mobile_number: number;
    country_code: string;
    password: string;
  };
}

export const resetPasswordHandler: RequestHandler = async (req: ValidatedRequest<ResetPasswordRequestSchema>, res) => {
  const language = req.headers.language;
  try {
    const body = req.body;
    const User = await userService.getUserByField('phone_number', body.mobile_number);

    if (!User) {
      return ReE(res, message(language, 'no_user_found'));
    }

    const newPassword = await authService.encryptPassword(body.password);
    await userService.updateUserByField('id', User.id, {
      password: newPassword,
      u_by: User.id,
    });

    await authService.destroyTokensByUserId(User.id);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'reset_password_success'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| GET PROFILE |||| -----------------------

export const getProfileHandler: RequestHandler = async (req, res) => {
  const language = req.headers.language;
  try {
    const user = req.userData;
    const token = req.headers.authorization.split(' ')[1];
    const profile = await User.scope('customerLogin').findOne({
      where: { id: user.id },
    });

    if (_.isNil(profile)) {
      return ReE(res, message(language, 'no_user_found'));
    }

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
        auth: { token: token, type: 'Bearer' },
        user: profile,
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| EDIT PROFILE |||| -----------------------

export const editProfileBodySchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().required(),
  image: Joi.string().required(),
});

interface EditProfileRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    name: string;
    email: string;
    image: string;
  };
}

export const editProfileHandler: RequestHandler = async (req: ValidatedRequest<EditProfileRequestSchema>, res: any) => {
  const data = req.body;
  const userData = req.userData;
  const language = req.language;
  const emailVerificationToken = await userService.generateEmailToken();

  const dataObj: any = {
    en_full_name: data.name ? data.name : userData.en_full_name,
    email: data.email ? data.email : userData.email,
    image: data.image ? data.image : userData.image,
    is_email_verified: data.email !== userData.email ? 0 : userData.is_email_verified,
    email_verification_token: emailVerificationToken,
  };

  await userService.updateUserByField('id', userData.id, dataObj);

  const user = await User.scope('customerLogin').findOne({
    where: {
      id: userData.id,
    },
  });

  if (data.email !== userData.email) {
    await sendVerificationEmail(user);
    // Send Verification Email
  }

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'profile_update_success'), user },
  });
};

// ---------------- |||| CHANGE PASSWORD |||| -----------------------
export const changePasswordBodySchema = Joi.object({
  old_password: Joi.string().required(),
  new_password: Joi.string().required(),
});

interface ChangePasswordRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    old_password: string;
    new_password: string;
  };
}

export const changePasswordHandler: RequestHandler = async (
  req: ValidatedRequest<ChangePasswordRequestSchema>,
  res,
) => {
  const language = req.headers.language;
  try {
    const data = req.body;
    const userData = req.userData;

    if (await authService.comparePassword(data.old_password, userData.password)) {
      const newPassword = await authService.encryptPassword(data.new_password);
      const userUpdatedData = await userService.updateUserByField('id', userData.id, {
        password: newPassword,
      });
      if (!userUpdatedData) {
        return ReE(res, message(language, 'no_user_found'));
      } else {
        return res.status(200).send({
          success: 1,
          error: [],
          data: {
            message: message(language, 'password_change_success'),
          },
        });
      }
    } else {
      return ReE(res, message(language, 'old_password_not_match'), 200);
    }
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| FORGOT PASSWORD |||| -----------------------
export const forgotPasswordBodySchema = Joi.object({
  mobile_number: Joi.number().required(),
  country_code: Joi.string().required(),
});

interface ForgotPasswordRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    mobile_number: number;
    country_code: string;
  };
}

export const forgotPasswordHandler: RequestHandler = async (
  req: ValidatedRequest<ForgotPasswordRequestSchema>,
  res,
) => {
  const language = req.headers.language;
  try {
    const body = req.body;

    const User = await userService.getUserByField('phone_number', body.mobile_number);

    if (!User) {
      return ReE(res, message(language, 'no_user_found'), 500);
    }
    const OTP = userService.generateOTP();

    await userService.updateUserByField('id', User.id, {
      otp: OTP,
      u_by: User.id,
    });
    const appName = language == 'ar' ? Messages_ar['appName'] : Messages_en['appName'];
    const content = 'Welcome to ' + appName + ', Your new OTP is :' + OTP;
    await smsservice.sendSMS(body.country_code + body.mobile_number, content);
    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'otp_send_success'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| RESEND OTP |||| -----------------------
export const resendOTPBodySchema = Joi.object({
  mobile_number: Joi.number().required(),
  country_code: Joi.string().required(),
});

interface ResendOTPBodySchemaRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    mobile_number: number;
    country_code: string;
  };
}

export const resendOTPHandler: RequestHandler = async (
  req: ValidatedRequest<ResendOTPBodySchemaRequestSchema>,
  res,
) => {
  const language = req.headers.language;
  try {
    const body = req.body;

    const accountRequest = await AccountRequest.findOne({
      where: { phone_number: body.mobile_number, dial_code: body.country_code },
    });

    if (!accountRequest) {
      return ReE(res, message(language, 'no_user_found'), 500);
    }
    const OTP = userService.generateOTP();
    const appName = language == 'ar' ? Messages_ar['appName'] : Messages_en['appName'];
    const content = 'Welcome to ' + appName + ', Your new OTP is :' + OTP;
    await AccountRequest.update({ otp: OTP }, { where: { id: accountRequest.id } });
    await smsservice.sendSMS(body.country_code + body.mobile_number, content);
    // await userService.updateUserByField('id', User.id, {
    //   otp: OTP,
    //   u_by: User.id,
    // });

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'otp_send_success'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| LOGOUT |||| -----------------------
export const logoutHandler: RequestHandler = async (req, res) => {
  const language = req.headers.language;
  try {
    const tokenWithType: any = req.headers['authorization'] ? req.headers['authorization'] : null;
    const token = tokenWithType ? tokenWithType.split(' ')[1] : null;
    await authService.destroyToken(token);
    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'logout_successfully'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| ROUTES |||| -----------------------
export const getToken: any = () =>
  router.post('/getToken', validator.body(getTokenBodySchema), handleError(tokenHandler));

export const login: any = () => router.post('/login', validator.body(loginBodySchema), handleError(loginHandler));

export const accountRequest: any = () =>
  router.post('/accountRequest', validator.body(accountRequestBodySchema), handleError(accountRequestHandler));

export const signUp: any = () =>
  router.post('/register', validator.body(signUpBodySchema), simpleAuthMiddleware, handleError(signUpHandler));

export const verifyOTP: any = () =>
  router.post('/verifyOTP', validator.body(verifyOTPBodySchema), handleError(verifyOTPUpHandler));

export const completeProfile: any = () =>
  router.post(
    '/completeProfile',
    validator.body(completeProfileBodySchema),
    mainAuthMiddleware,
    handleError(CompleteProfileHandler),
  );

export const completeAddress: any = () =>
  router.post(
    '/completeAddress',
    validator.body(completeAddressBodySchema),
    mainAuthMiddleware,
    handleError(completeAddressHandler),
  );

export const completeBankDetails: any = () =>
  router.post(
    '/completeBankDetails',
    validator.body(completeBankDetailsBodySchema),
    mainAuthMiddleware,
    handleError(completeBankDetailsHandler),
  );

export const resetPassword: any = () =>
  router.post('/resetPassword', validator.body(resetPasswordBodySchema), handleError(resetPasswordHandler));

export const getProfile: any = () => router.get('/profile', mainAuthMiddleware, handleError(getProfileHandler));

export const editProfile: any = () =>
  router.post(
    '/updateProfile',
    validator.body(editProfileBodySchema),
    mainAuthMiddleware,
    handleError(editProfileHandler),
  );

export const changePassword: any = () =>
  router.post(
    '/changePassword',
    validator.body(changePasswordBodySchema),
    mainAuthMiddleware,
    handleError(changePasswordHandler),
  );

export const forgotPassword: any = () =>
  router.post('/forgotPassword', validator.body(forgotPasswordBodySchema), handleError(forgotPasswordHandler));

export const resendOTP: any = () =>
  router.post('/resendOTP', validator.body(resendOTPBodySchema), handleError(resendOTPHandler));

export const logout: any = () => router.get('/logout', handleError(logoutHandler));
