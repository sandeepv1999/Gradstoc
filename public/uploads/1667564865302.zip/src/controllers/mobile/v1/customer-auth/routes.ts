/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import {
  getToken,
  login,
  signUp,
  verifyOTP,
  completeProfile,
  completeAddress,
  completeBankDetails,
  resetPassword,
  getProfile,
  editProfile,
  changePassword,
  forgotPassword,
  logout,
  accountRequest,
  resendOTP,
} from './customer.controllers';

const router = Router();

export const customerAuth: any = () =>
  router.use([
    getToken(),
    login(),
    signUp(),
    verifyOTP(),
    completeProfile(),
    completeAddress(),
    completeBankDetails(),
    resetPassword(),
    getProfile(),
    editProfile(),
    changePassword(),
    forgotPassword(),
    logout(),
    accountRequest(),
    resendOTP(),
  ]);
