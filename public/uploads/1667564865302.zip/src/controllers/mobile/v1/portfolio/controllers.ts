/* eslint-disable @typescript-eslint/no-explicit-any */
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';

import handleError from '../../../../middlewares/handle-error';
import { mainAuthMiddleware, message } from '../../../../middlewares/auth.middleware';
import { ReE } from '../../../../services/util.service';

import * as userService from '../../../../utils/user';
import { MusicianPortfolio } from '../../../../models/musicianPortfolio.model';
import { Category } from '../../../../models/category.model';
import { CategoryTranslation } from '../../../../models/categoryTranslation.model';
import { Sequelize } from 'sequelize';

const router = Router();
const validator = createValidator({ passError: true });

//  ---------------- |||| LIST |||| -----------------------
export const portfolioListBodySchema = Joi.object({
  start: Joi.number().required(),
  limit: Joi.number(),
});

interface PortfolioListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
  };
}

export const portfolioListHandler: RequestHandler = async (req: ValidatedRequest<PortfolioListRequestSchema>, res) => {
  const language = req.headers.language;
  try {
    const body = req.body;
    const User = req.userData;
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);
    let is_last = 1;
    let portfolio_count = 0;

    const Where: any = { is_deleted: 0, is_active: 1, user_id: User.id };

    portfolio_count = await MusicianPortfolio.count({ where: Where });

    let portfolio_list = await MusicianPortfolio.findAll({
      include: [
        {
          model: Category,
          include: [
            {
              model: CategoryTranslation,
              as: 'translation',
              where: { language_code: language },
            },
          ],
          as: 'category',
          attributes: [[Sequelize.fn('', Sequelize.col('`category->translation`.`name`')), 'category_name']],
        },
      ],
      where: Where,
      offset: start,
      limit: limit,
      attributes: [
        'id',
        'category_id',
        'title',
        'video_url',
        'video_thumb',
        'is_approved',
        'is_active',
        [Sequelize.fn('', Sequelize.col('`category->translation`.`name`')), 'category_name'],
      ],
      subQuery: false,
      order: [['id', 'DESC']],
    });

    if (portfolio_list.length > 0) {
      if (portfolio_list.length >= limit) {
        portfolio_list.pop();
        is_last = 0;
      }

      portfolio_list = portfolio_list.map(element => {
        const elemJSON: any = element.toJSON();
        delete elemJSON['category'];
        console.log(elemJSON);
        return elemJSON;
      });

      return res.send({
        success: 1,
        error: [],
        data: { message: message(language, 'success'), portfolio_list, is_last, portfolio_count },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: message(language, 'no_records_found'), portfolio_list, portfolio_count },
      });
    }
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| Add PORTFOLIO |||| -----------------------
export const createPortfolioBodySchema = Joi.object({
  category_id: Joi.number().required(),
  title: Joi.string().required(),
  video_url: Joi.string().required(),
  video_thumb: Joi.string().required(),
});

interface CreatePortfolioRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    category_id: number;
    title: string;
    video_url: string;
    video_thumb: string;
  };
}

export const createPortfolioHandler: RequestHandler = async (
  req: ValidatedRequest<CreatePortfolioRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      user_id: userData.id,
      category_id: body.category_id,
      title: body.title,
      video_url: body.video_url,
      video_thumb: body.video_thumb,
      is_approved: 0,
      i_by: userData.id,
    };

    await userService.createMusicianPortfolio(data);
    await userService.updateUserByField('id', userData.id, { is_portfolio_completed: 1 });
    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'portfolio_added_successfully'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| EDIT PORTFOLIO |||| -----------------------
export const editPortfolioBodySchema = Joi.object({
  id: Joi.number().required(),
  category_id: Joi.number().required(),
  title: Joi.string().required(),
  video_url: Joi.string().required(),
  video_thumb: Joi.string().required(),
});

interface EditPortfolioRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
    category_id: number;
    title: string;
    video_url: string;
    video_thumb: string;
  };
}

export const editPortfolioHandler: RequestHandler = async (req: ValidatedRequest<EditPortfolioRequestSchema>, res) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      user_id: userData.id,
      category_id: body.category_id,
      title: body.title,
      video_url: body.video_url,
      video_thumb: body.video_thumb,
      is_approved: 0,
      u_by: userData.id,
    };

    const portfolio = await userService.getMusicianPortfolio('id', body.id);

    if (!portfolio) {
      return ReE(res, message(language, 'portfolio_not_exists'));
    }

    await userService.updateMusicianPortfolio('id', body.id, data);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'portfolio_updated_successfully'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| Delete PORTFOLIO |||| -----------------------
export const deletePortfolioBodySchema = Joi.object({
  id: Joi.number().required(),
});

interface DeletePortfolioRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
  };
}

export const deletePortfolioHandler: RequestHandler = async (
  req: ValidatedRequest<DeletePortfolioRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      is_deleted: 1,
      u_by: userData.id,
    };

    await userService.updateMusicianPortfolio('id', body.id, data);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'portfolio_deleted_successfully'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| ROUTES |||| -----------------------
export const getPortfolios: any = () =>
  router.post('/', validator.body(portfolioListBodySchema), mainAuthMiddleware, handleError(portfolioListHandler));

export const addPortfolios: any = () =>
  router.post(
    '/create',
    validator.body(createPortfolioBodySchema),
    mainAuthMiddleware,
    handleError(createPortfolioHandler),
  );

export const editPortfolios: any = () =>
  router.post('/edit', validator.body(editPortfolioBodySchema), mainAuthMiddleware, handleError(editPortfolioHandler));

export const deletePortfolios: any = () =>
  router.post(
    '/delete',
    validator.body(deletePortfolioBodySchema),
    mainAuthMiddleware,
    handleError(deletePortfolioHandler),
  );
