/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import { getPortfolios, editPortfolios, deletePortfolios, addPortfolios } from './controllers';

const router = Router();

export const portfolio: any = () =>
  router.use([getPortfolios(), addPortfolios(), editPortfolios(), deletePortfolios()]);
