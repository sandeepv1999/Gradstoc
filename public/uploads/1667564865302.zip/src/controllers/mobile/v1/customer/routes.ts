/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import {
  dashboard,
  favorite,
  musicianDetails,
  musicianByCategory,
  allFavouriteMusicians,
  allMusicians,
  becomeMusician,
  checkAvailablity,
} from './controllers';

const router = Router();

export const customer: any = () =>
  router.use([
    dashboard(),
    favorite(),
    musicianDetails(),
    musicianByCategory(),
    allFavouriteMusicians(),
    allMusicians(),
    becomeMusician(),
    checkAvailablity(),
  ]);
