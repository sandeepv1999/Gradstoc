/* eslint-disable @typescript-eslint/no-explicit-any */
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import * as Joi from '@hapi/joi';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';
import { Sequelize, Op } from 'sequelize';

import handleError from '../../../../middlewares/handle-error';
import { mainAuthMiddleware, message, simpleAuthMiddleware } from '../../../../middlewares/auth.middleware';
import { ReE } from '../../../../services/util.service';
import { Actors, BookingStatus } from '../../../../utils/constants';
import * as userService from '../../../../utils/user';

import { User } from '../../../../models/users.model';
import { AppBanners } from '../../../../models/appBanner.model';
import { Category } from '../../../../models/category.model';
import { CategoryTranslation } from '../../../../models/categoryTranslation.model';
import { UserDetails } from '../../../../models/userDetails.model';
import { Notifications } from '../../../../models/notification.model';
import { UserFavorites } from '../../../../models/userFavorite.model';
import { MusicianCategories } from '../../../../models/musicianCategories.model';
import { Booking } from '../../../../models/bookings.model';
import { BookingAddress } from '../../../../models/bookingAddresses.model';
import { BookingCategory } from '../../../../models/bookingCategory.model';
import _ from 'lodash';
import { MusicianPortfolio } from '../../../../models/musicianPortfolio.model';
import { Rating } from '../../../../models/rating.model';
import { RecentView } from '../../../../models/recentView.model';
import moment, { now } from 'moment';
import { array } from '@hapi/joi';
import * as emailService from '../../../../services/email.service';
import { map } from 'p-iteration';

const router = Router();
const validator = createValidator({ passError: true });

export const homeDataBodySchema = Joi.object({
  latitude: Joi.number(),
  longitude: Joi.number(),
});

interface HomeDataRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    latitude: string;
    longitude: string;
  };
}

export const homeDataHandler: RequestHandler = async (req: ValidatedRequest<HomeDataRequestSchema>, res) => {
  const data = req.body;
  const user = req.userData;
  const language = req.headers.language;
  let notification_unread_count = 0;
  let bookings = [];
  const favouriteWhere = { is_deleted: 0 };
  try {
    if (user) {
      _.set(favouriteWhere, 'user_id', user.id);

      notification_unread_count = await Notifications.count({
        where: {
          [Op.and]: [
            Sequelize.where(Sequelize.fn('!FIND_IN_SET', user.id, Sequelize.col('deleted_by')), { [Op.gte]: 1 }),
            Sequelize.where(Sequelize.fn('!FIND_IN_SET', user.id, Sequelize.col('read_by')), { [Op.gte]: 1 }),
            Sequelize.where(Sequelize.fn('FIND_IN_SET', user.id, Sequelize.col('receiver_ids')), { [Op.gte]: 1 }),
          ],
        },
      });

      bookings = await Booking.findAll({
        where: { user_id: user.id, status: BookingStatus.Pending, is_active: 1 },
        include: [
          {
            model: User,
            as: 'musician',
          },
          {
            model: BookingAddress,
            as: 'booking_address',
          },
          {
            model: BookingCategory,
            as: 'booking_category',
            where: { language_code: language },
          },
        ],
        attributes: [
          'id',
          ['event_date', 'date'],
          'start_time',
          'end_time',
          ['is_fixed', 'booked_type'],
          ['total_amount', 'amount'],
          [Sequelize.fn('', Sequelize.col('musician.en_full_name')), 'musician_name'],
          [Sequelize.fn('', Sequelize.col('booking_address.address')), 'address'],
          [Sequelize.fn('', Sequelize.col('booking_category.name')), 'category_name'],
        ],
        order: [['id', 'DESC']],
      });
    }

    const banner = await AppBanners.findAll({
      where: { is_active: 1, is_deleted: 0 },
      attributes: ['id', ['banner_url', 'image'],'imageType'],
      order: [['id', 'DESC']],
    });

    const categories = await Category.findAll({
      where: { is_active: 1, is_deleted: 0 },
      include: [
        {
          model: CategoryTranslation,
          as: 'translation',
          where: { language_code: language },
        },
      ],
      attributes: [
        'id',
        ['icon_url', 'image'],
        ['sound_url', 'sound'],
        [Sequelize.fn('', Sequelize.col('`translation`.`name`')), 'name'],
      ],
      order: [['id', 'DESC']],
    });

    let popularArtists = await User.findAll({
      where: { actor: Actors.Musician, is_deleted: 0, is_active: 1 },
      include: [
        {
          model: UserDetails,
          as: 'details',
        },
        {
          model: UserFavorites,
          where: favouriteWhere,
          as: 'favorites',
          required: false,
        },
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                },
              ],
            },
          ],
          // include: [
          //   {
          //     model: CategoryTranslation,
          //     where: { language_code: language },
          //     as: 'category',
          //   },
          // ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
      ],
      attributes: [
        'id',
        ['en_full_name', 'name'],
        'image',
        [Sequelize.fn('', Sequelize.col('`favorites`.`is_favorite`')), 'is_favorite'],
        [Sequelize.fn('', Sequelize.col('`details`.`hourly_rate`')), 'hourly_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`fix_rate`')), 'fixed_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`avg_rating`')), 'average_rate'],
      ],
      subQuery: false,
      group: ['id'],
      order: [[Sequelize.col('`details.avg_rating`'), 'DESC']],
      limit: 10,
    });
    console.log('popularArtists**************', popularArtists);
    let recent_viewed = [];
    if (user && user != null && user.id != null) {
      console.log('user id', user.id);
      let recentMusicianid = await userService.getrecentViewMusicianByUser(user.id);

      const recentWhere = { actor: Actors.Musician, is_deleted: 0, is_active: 1 };
      console.log(recentMusicianid);
      const recentArr: number[] = [];
      if (recentMusicianid) {
        recentMusicianid = recentMusicianid.map(elem => {
          const elemJSON: any = elem.toJSON();
          console.log(elemJSON.musician_id);
          recentArr.push(elemJSON.musician_id);
          return elemJSON;
        });
        console.log(recentArr);
        _.set(recentWhere, 'id', { [Op.in]: recentArr });
      } else {
        _.set(recentWhere, 'id', 0);
      }
      recent_viewed = await User.findAll({
        where: recentWhere,
        include: [
          {
            model: UserDetails,
            as: 'details',
            required: false,
          },
          // {
          //   model: UserFavorites,
          //   where: favouriteWhere,
          //   as: 'favorites',
          //   required: false,
          // },
          {
            model: MusicianCategories,
            // include: [
            //   {
            //     model: CategoryTranslation,
            //     where: { language_code: language },
            //     as: 'category',
            //   },
            // ],
            include: [
              {
                model: Category,
                as: 'category',
                where: { is_deleted: 0, is_active: 1 },
                include: [
                  {
                    model: CategoryTranslation,
                    where: { language_code: language },
                    as: 'translation',
                  },
                ],
              },
            ],
            as: 'musician_categories',
            required: false,
            attributes: [
              [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
              [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
            ],
          },
        ],
        attributes: [
          'id',
          ['en_full_name', 'name'],
          'image',
          // [Sequelize.fn('', Sequelize.col('`favorites`.`is_favorite`')), 'is_favorite'],
          [Sequelize.fn('', Sequelize.col('`details`.`hourly_rate`')), 'hourly_amount'],
          [Sequelize.fn('', Sequelize.col('`details`.`fix_rate`')), 'fixed_amount'],
          [Sequelize.fn('', Sequelize.col('`details`.`avg_rating`')), 'average_rate'],
        ],
        subQuery: false,
        // order: [[Sequelize.col('recentview.view'), 'DESC']],
        order: !recentMusicianid ? Sequelize.literal('FIELD(User.id,' + recentArr.join(',') + ')') : [['id', 'DESC']],
        group: ['id'],
        limit: 10,
        logging: true,
      });

      if (recent_viewed) {
        // recent_viewed = recent_viewed.map(elem => {
        //   const elemJSON: any = elem.toJSON();
        //   elemJSON.is_favorite = elemJSON.is_favorite ? elemJSON.is_favorite : 0;
        //   elemJSON.category = elemJSON.musician_categories
        //     ? elemJSON.musician_categories
        //         .map(x => {
        //           return x.category_name;
        //         })
        //         .toString()
        //     : '';
        //   delete elemJSON['details'];
        //   delete elemJSON['favorites'];
        //   delete elemJSON['musician_categories'];
        //   return elemJSON;
        // });

        recent_viewed = await map(recent_viewed, async elem => {
          const elemJSON: any = elem.toJSON();
          if (user) {
            const getFavourite = await userService.checkMusicianFavourite(user.id, elem.id);
            if (getFavourite) {
              console.log(getFavourite.musician_id, '*************', getFavourite.is_favorite);
              elemJSON.is_favorite = 1;
              elemJSON.favorite = getFavourite;
            } else {
              elemJSON.is_favorite = 0;
            }
          } else {
            elemJSON.is_favorite = 0;
          }
          elemJSON.category = elemJSON.musician_categories
            ? elemJSON.musician_categories
                .map(x => {
                  return x.category_name;
                })
                .toString()
            : '';
          elemJSON.average_rate = parseFloat(elemJSON.average_rate).toFixed(2);
          delete elemJSON['details'];
          delete elemJSON['favorites'];
          // delete elemJSON['musician_categories'];
          return elemJSON;
        });
      }
    }

    if (popularArtists) {
      // popularArtists = popularArtists.map(elem => {
      //   const elemJSON: any = elem.toJSON();
      //   elemJSON.is_favorite = elemJSON.is_favorite ? elemJSON.is_favorite : 0;
      //   elemJSON.category = elemJSON.musician_categories
      //     ? elemJSON.musician_categories
      //         .map(x => {
      //           return x.category_name;
      //         })
      //         .toString()
      //     : '';
      //   delete elemJSON['details'];
      //   delete elemJSON['favorites'];
      //   delete elemJSON['musician_categories'];
      //   return elemJSON;
      // });

      popularArtists = await map(popularArtists, async elem => {
        const elemJSON: any = elem.toJSON();
        if (user) {
          const getFavourite = await userService.checkMusicianFavourite(user.id, elem.id);
          if (getFavourite) {
            console.log(getFavourite.musician_id, '*************', getFavourite.is_favorite);
            elemJSON.is_favorite = 1;
          } else {
            elemJSON.is_favorite = 0;
          }
        } else {
          elemJSON.is_favorite = 0;
        }
        elemJSON.average_rate = parseFloat(elemJSON.average_rate.toFixed(1));
        // console.log('getMusicianCategories',elemJSON.musician_categories)
        // elemJSON.category = elemJSON.musician_categories
        //   ? elemJSON.musician_categories
        //       .map(x => {
        //         // console.log('yyy',x)
        //         return x.category_name;
        //       })
        //       .toString()
        //   : '';
        //-------------------

        const getMusicianCategories = await userService.getMusicianCategories(elem.id, language);
        // console.log('getMusicianCategories',getMusicianCategories)
        elemJSON.musician_categories = getMusicianCategories;
        elemJSON.category = elemJSON.musician_categories
          ? elemJSON.musician_categories
              .map(x => {
                // console.log('xxxx',x)
                return x.category_name;
              })
              .toString()
          : '';
        //-----------
        elemJSON.average_rate = parseFloat(elemJSON.average_rate).toFixed(2);
        delete elemJSON['details'];
        delete elemJSON['favorites'];
        // delete elemJSON['musician_categories'];
        return elemJSON;
      });
    }

    if (bookings) {
      bookings = bookings.map(elem => {
        const elemJSON: any = elem.toJSON();
        delete elemJSON['musician'];
        delete elemJSON['booking_address'];
        delete elemJSON['booking_category'];
        return elemJSON;
      });
    }

    const data = {
      notification_unread_count,
      banner,
      categories,
      popularArtists,
      recent_viewed,
      bookings,
    };
    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success'), data },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const favoriteMusicianBodySchema = Joi.object({
  musician_id: Joi.number(),
});

interface FavoriteMusicianRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    musician_id: number;
  };
}

export const favoriteMusicianHandler: RequestHandler = async (
  req: ValidatedRequest<FavoriteMusicianRequestSchema>,
  res,
) => {
  const body = req.body;
  const UserData = req.userData;
  const language = req.headers.language;

  try {
    const respMessage = await userService.musicianFavorite(body.musician_id, UserData.id);
    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, respMessage) },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const musicianDetailBodySchema = Joi.object({
  musician_id: Joi.number(),
});

interface MusicianDetailRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    musician_id: number;
  };
}

export const musicianDetailHandler: RequestHandler = async (
  req: ValidatedRequest<MusicianDetailRequestSchema>,
  res,
) => {
  const body = req.body;
  const UserData = req.userData;
  const language = req.headers.language;

  try {
    const musician = await User.findOne({
      where: { id: body.musician_id },
      include: [
        {
          model: UserDetails,
          as: 'details',
          where: { is_deleted: 0, is_active: 1 },
          required: false,
        },
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                },
              ],
              required: true,
            },
          ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
        {
          model: MusicianPortfolio,
          as: 'portfolios',
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                },
              ],
              required: false,
            },
          ],
          where: { is_deleted: 0, is_active: 1, is_approved: 1 },
          attributes: [
            'title',
            'video_url',
            'video_thumb',
            [Sequelize.fn('', Sequelize.col('`portfolios.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`portfolios.category.translation.name`')), 'category_name'],
          ],
          required: false,
        },
        {
          model: Rating,
          as: 'ratings',
          attributes: [
            'id',
            'booking_id',
            'rating',
            'comments',
            'createdAt',
            [
              Sequelize.literal('(SELECT `en_full_name` FROM users WHERE id = ratings.user_id AND is_deleted = 0)'),
              'customer_name',
            ],
            [Sequelize.literal('(SELECT `image` FROM users WHERE id = ratings.user_id AND is_deleted = 0)'), 'image'],
          ],
          required: false,
        },
      ],
      logging: true,
      attributes: [
        'id',
        [Sequelize.fn('', Sequelize.col('en_full_name')), 'name'],
        'email',
        'image',
        [Sequelize.fn('', Sequelize.col('dial_code')), 'country_code'],
        [Sequelize.fn('', Sequelize.col('phone_number')), 'mobile_number'],
        [Sequelize.fn('', Sequelize.col('details.about_me')), 'about_me'],
        [Sequelize.fn('', Sequelize.col('details.avg_rating')), 'rating'],
        [Sequelize.fn('', Sequelize.col('details.hourly_rate')), 'hourly_rate'],
        [Sequelize.fn('', Sequelize.col('details.fix_rate')), 'full_day_rate'],

        // [Sequelize.fn('', Sequelize.col('details.total_jobs_done')), 'hourly_rate'],
        // [Sequelize.fn('', Sequelize.col('details.avg_resp_time')), 'avg_response'],
        [Sequelize.fn('', Sequelize.col('details.can_set_price')), 'selected_type'],
        // [Sequelize.fn('', Sequelize.col('details.total_jobs_done')), 'jobs_done'],
        [
          Sequelize.literal(
            '(SELECT COUNT(*) FROM bookings WHERE status=3 and musician_id = User.id AND is_deleted = 0)',
          ),
          'jobs_done',
        ],
        [
          Sequelize.literal('(SELECT COUNT(*) FROM rating WHERE musician_id = ratings.musician_id AND is_deleted = 0)'),
          'totle_rate_count',
        ],
        [
          Sequelize.literal(
            '(SELECT AVG(`rating`) FROM rating WHERE musician_id = ratings.musician_id AND is_deleted = 0)',
          ),
          'avg_rating',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = ratings.musician_id AND rating = 5 AND is_deleted = 0)`,
          ),
          'five_star_count',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = ratings.musician_id AND rating = 4 AND is_deleted = 0)`,
          ),
          'four_star_count',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = ratings.musician_id AND rating = 3 AND is_deleted = 0)`,
          ),
          'three_star_count',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = ratings.musician_id AND rating = 2 AND is_deleted = 0)`,
          ),
          'two_star_count',
        ],
        [
          Sequelize.literal(
            `(SELECT COUNT(*) FROM rating WHERE musician_id = ratings.musician_id AND rating = 1 AND is_deleted = 0)`,
          ),
          'one_star_count',
        ],
      ],
    });
    if (!musician) {
      return ReE(res, message(language, 'musician_details_not_found'), 500);
    }

    const musicianResp: any = musician.toJSON();

    musicianResp.avg_rating = parseFloat(parseFloat(musicianResp.avg_rating).toFixed(1));
    musicianResp.avg_response = await userService.getMusicianAvgResponseTime(body.musician_id);
    musicianResp.is_already_booked = 0;
    if (UserData && UserData != null && UserData.id != null) {
      const currentBooking = await userService.checkCurrentBookingByUserId(UserData.id, body.musician_id);
      musicianResp.is_already_booked = currentBooking ? 1 : 0;
    }

    delete musicianResp['details'];

    const rating = {
      fifth: musicianResp.five_star_count,
      forth: musicianResp.four_star_count,
      third: musicianResp.three_star_count,
      second: musicianResp.two_star_count,
      first: musicianResp.one_star_count,
    };

    musicianResp.ratings_count = rating;

    delete musicianResp['five_star_count'];
    delete musicianResp['four_star_count'];
    delete musicianResp['three_star_count'];
    delete musicianResp['two_star_count'];
    delete musicianResp['one_star_count'];

    if (musicianResp.musician_categories) {
      musicianResp.musician_categories.map(elem => {
        delete elem['category'];
      });
    }

    if (musicianResp.portfolios) {
      musicianResp.portfolios.map(elem => {
        delete elem['category'];
      });
    }

    if (musicianResp.ratings) {
      musicianResp.ratings.map(elem => {
        elem.rating_time = moment(elem.createdAt).fromNow();
        elem.createdAt = moment(elem.createdAt).unix();
      });
    }

    await Object.keys(musicianResp).forEach(key => {
      if (musicianResp[key] == undefined && musicianResp[key] == null) {
        musicianResp[key] = '';
      }
      if (typeof musicianResp[key] === 'object') {
        Object.keys(musicianResp[key]).forEach(k => {
          if (musicianResp[key][k] == undefined && musicianResp[key][k] == null) {
            musicianResp[key][k] = '';
          }
        });
      }
    });
    if (UserData && UserData != null && UserData.id != null) {
      const respMessage = await userService.recentViewByUser(body.musician_id, UserData.id);
    }
    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'success'), musicianResp },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const musicianByCategoryBodySchema = Joi.object({
  start: Joi.number(),
  limit: Joi.number(),
  start_date: Joi.number(),
  start_time: Joi.string(),
  category_id: Joi.number(),
  latitude: Joi.number(),
  longitude: Joi.number(),
});

interface MusicianByCategoryRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    start_date: number;
    start_time: string;
    category_id: number;
    latitude: number;
    longitude: number;
  };
}

export const musicianByCategoryHandler: RequestHandler = async (
  req: ValidatedRequest<MusicianByCategoryRequestSchema>,
  res,
) => {
  const body = req.body;
  const UserData = req.userData;
  const language = req.headers.language;

  try {
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);
    const start_date = Number(body.start_date ? body.start_date : 0);
    let is_last = 1;
    const favouriteWhere = { is_deleted: 0 };

    let popularArtists = await User.findAll({
      where: { actor: Actors.Musician, is_deleted: 0, is_active: 1 },
      include: [
        {
          model: UserDetails,
          as: 'details',
        },
        {
          model: UserFavorites,
          where: favouriteWhere,
          as: 'favorites',
          required: false,
        },
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                },
              ],
            },
          ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
      ],
      attributes: [
        'id',
        ['en_full_name', 'name'],
        'image',
        [Sequelize.fn('', Sequelize.col('`favorites`.`is_favorite`')), 'is_favorite'],
        [Sequelize.fn('', Sequelize.col('`details`.`hourly_rate`')), 'hourly_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`fix_rate`')), 'fixed_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`avg_rating`')), 'average_rate'],
      ],
      subQuery: false,
      order: [[Sequelize.col('`details.avg_rating`'), 'DESC']],
      limit: 10,
    });

    let artistsByCategory = await User.findAll({
      where: {
        actor: Actors.Musician,
        is_deleted: 0,
        is_active: 1,
        [Op.and]: [
          Sequelize.where(Sequelize.col('`musician_categories`.`category_id`'), { [Op.in]: [body.category_id] }),
        ],
      },
      include: [
        {
          model: UserDetails,
          as: 'details',
          required: false,
        },
        {
          model: UserFavorites,
          where: favouriteWhere,
          as: 'favorites',
          required: false,
        },
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                  required: false,
                },
              ],
            },
          ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
      ],
      attributes: [
        'id',
        ['en_full_name', 'name'],
        'image',
        [Sequelize.fn('', Sequelize.col('`favorites`.`is_favorite`')), 'is_favorite'],
        [Sequelize.fn('', Sequelize.col('`details`.`hourly_rate`')), 'hourly_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`fix_rate`')), 'fixed_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`avg_rating`')), 'average_rate'],
      ],
      offset: start,
      limit: limit,
      subQuery: false,
      logging: true,
      order: [['id', 'DESC']],
    });

    if (popularArtists) {
      // popularArtists =  popularArtists.map(async elem => {
      //   const elemJSON: any = elem.toJSON();
      //   elemJSON.is_available = await userService.getMusicianAvaibility(elemJSON.id, 0);
      //   return elemJSON;
      // });
      // popularArtists = await Promise.all(
      //   popularArtists.map(
      //     async (elem): Promise<any> => {
      //       const elemJSON: any = elem.toJSON();
      //       elemJSON.is_available = await userService.getMusicianAvaibility(elemJSON.id, start_date);
      //       elemJSON.average_rate = parseFloat(elemJSON.average_rate.toFixed(1));
      //       return elemJSON;
      //     },
      //   ),
      // );

      popularArtists = await map(popularArtists, async elem => {
        const elemJSON: any = elem.toJSON();
        if (UserData) {
          const getFavourite = await userService.checkMusicianFavourite(UserData ? UserData.id : 0, elem.id);
          console.log('**************************');
          console.log(getFavourite);
          if (getFavourite) {
            elemJSON.is_favorite = 1;
          } else {
            elemJSON.is_favorite = 0;
          }
        } else {
          elemJSON.is_favorite = 1;
        }
        elemJSON.is_available = await userService.getMusicianAvaibility(elemJSON.id, start_date);
        elemJSON.average_rate = parseFloat(elemJSON.average_rate.toFixed(1));
        return elemJSON;
      });
    }
    // console.log(artistsByCategory);
    if (artistsByCategory.length >= limit) {
      artistsByCategory.pop();
      is_last = 0;
    }
    if (artistsByCategory) {
      // artistsByCategory = artistsByCategory.map(elem => {
      //   const elemJSON: any = elem.toJSON();
      //   elemJSON.is_available = 1;
      //   return elemJSON;
      // });

      // artistsByCategory = await Promise.all(
      //   artistsByCategory.map(
      //     async (elem): Promise<any> => {
      //       const elemJSON: any = elem.toJSON();
      //       elemJSON.is_available = await userService.getMusicianAvaibility(elemJSON.id, start_date);
      //       elemJSON.musician_categories = await userService.getMusicianAllCategory(elemJSON.id, language);
      //       elemJSON.average_rate = parseFloat(elemJSON.average_rate.toFixed(1));
      //       return elemJSON;
      //     },
      //   ),
      // );

      artistsByCategory = await map(artistsByCategory, async elem => {
        const elemJSON: any = elem.toJSON();
        const getFavourite = await userService.checkMusicianFavourite(UserData ? UserData.id : 0, elem.id);
        console.log('**************************');
        console.log(getFavourite);
        if (getFavourite) {
          elemJSON.is_favorite = 1;
        } else {
          elemJSON.is_favorite = 0;
        }
        elemJSON.is_available = await userService.getMusicianAvaibility(elemJSON.id, start_date);
        elemJSON.musician_categories = await userService.getMusicianAllCategory(elemJSON.id, language);
        elemJSON.average_rate = parseFloat(elemJSON.average_rate.toFixed(1));
        return elemJSON;
      });
    }

    return res.send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
        popularArtists,
        is_last,
        artistsByCategory,
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};
export const allFavouriteMusiciansBodySchema = Joi.object({
  start: Joi.number(),
  limit: Joi.number(),
});

interface AllFavouriteMusiciansRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
  };
}

export const allFavouriteMusiciansHandler: RequestHandler = async (
  req: ValidatedRequest<AllFavouriteMusiciansRequestSchema>,
  res,
) => {
  const body = req.body;
  const UserData = req.userData;
  const language = req.headers.language;

  try {
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;
    const favouriteWhere = { is_deleted: 0 };

    let recentMusicianid = await userService.getfavoriteMusicianByUser(UserData.id);

    const recentWhere = { actor: Actors.Musician, is_deleted: 0, is_active: 1 };
    console.log(recentMusicianid);
    const recentArr: number[] = [];
    if (recentMusicianid) {
      recentMusicianid = recentMusicianid.map(elem => {
        const elemJSON: any = elem.toJSON();
        console.log(elemJSON.musician_id);
        recentArr.push(elemJSON.musician_id);
        return elemJSON;
      });
      console.log(recentArr);
      _.set(recentWhere, 'id', { [Op.in]: recentArr });
    } else {
      _.set(recentWhere, 'id', 0);
    }

    let artistsByCategory = await User.findAll({
      where: recentWhere,
      include: [
        {
          model: UserDetails,
          as: 'details',
          required: false,
        },
        {
          model: UserFavorites,
          where: favouriteWhere,
          as: 'favorites',
          required: false,
        },
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                  required: false,
                },
              ],
            },
          ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
      ],
      attributes: [
        'id',
        ['en_full_name', 'name'],
        'image',
        [Sequelize.fn('', Sequelize.col('`favorites`.`is_favorite`')), 'is_favorite'],
        [Sequelize.fn('', Sequelize.col('`details`.`hourly_rate`')), 'hourly_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`fix_rate`')), 'fixed_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`avg_rating`')), 'average_rate'],
      ],
      offset: start,
      limit: limit,
      subQuery: false,
      logging: true,
      order: [['id', 'DESC']],
      group: ['id'],
    });

    // console.log(artistsByCategory);
    if (artistsByCategory.length >= limit) {
      artistsByCategory.pop();
      is_last = 0;
    }
    if (artistsByCategory) {
      // artistsByCategory = artistsByCategory.map(elem => {
      //   const elemJSON: any = elem.toJSON();
      //   elemJSON.is_available = 1;
      //   return elemJSON;
      // });

      artistsByCategory = await Promise.all(
        artistsByCategory.map(
          async (elem): Promise<any> => {
            const elemJSON: any = elem.toJSON();
            elemJSON.musician_categories = await userService.getMusicianAllCategory(elemJSON.id, language);
            elemJSON.average_rate = parseFloat(elemJSON.average_rate.toFixed(1));
            return elemJSON;
          },
        ),
      );
    }

    return res.send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
        is_last,
        favourite_list: artistsByCategory,
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const allMusiciansBodySchema = Joi.object({
  start: Joi.number(),
  limit: Joi.number(),
  search: Joi.string(),
  category_id: Joi.string(),
  booked_type: Joi.number(),
});

interface AllMusiciansRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search: string;
    category_id: string;
    booked_type: number;
  };
}

export const allMusiciansHandler: RequestHandler = async (req: ValidatedRequest<AllMusiciansRequestSchema>, res) => {
  const body = req.body;
  const UserData = req.userData;
  const language = req.headers.language;

  try {
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    let is_last = 1;
    const favouriteWhere = { is_deleted: 0 };
    let recentWhere: any = {};
    const conditionArr = [];
    recentWhere = { actor: Actors.Musician, is_deleted: 0, is_active: 1 };

    if (body.search && body.search != null) {
      conditionArr.push(
        Sequelize.where(Sequelize.col('`User`.`en_full_name`'), { [Op.like]: '%' + body.search + '%' }),
      );
      // _.set(recentWhere, 'en_full_name', { [Op.like]: '%' + body.search + '%' });
      // recentWhere = {
      //   ...recentWhere,
      //   // [Op.and]: [Sequelize.where(Sequelize.col('`User`.`en_full_name`'), { [Op.like]: '%' + body.search + '%' })],
      // };
    }
    if (body.booked_type && body.booked_type != null) {
      if (body.booked_type == 2) {
        conditionArr.push(
          Sequelize.where(Sequelize.fn('', Sequelize.col('`details`.`fix_rate`')), {
            [Op.ne]: 0,
          }),
        );
        // recentWhere = {
        //   ...recentWhere,
        //   [Op.and]: [
        //     Sequelize.where(Sequelize.fn('', Sequelize.col('`details`.`fix_rate`')), {
        //       [Op.ne]: 0,
        //     }),
        //   ],
        // };
      } else {
        // _.set(recentWhere, 'details.hourly_rate', { [Op.ne]: 0 });
        conditionArr.push(
          Sequelize.where(Sequelize.fn('', Sequelize.col('`details`.`hourly_rate`')), {
            [Op.ne]: 0,
          }),
        );
        // recentWhere = {
        //   ...recentWhere,
        //   [Op.and]: [
        //     Sequelize.where(Sequelize.fn('', Sequelize.col('`details`.`hourly_rate`')), {
        //       [Op.ne]: 0,
        //     }),
        //   ],
        // };
      }
    }
    if (body.category_id && body.category_id != null) {
      conditionArr.push(
        Sequelize.where(Sequelize.col('`musician_categories`.`category_id`'), { [Op.in]: [body.category_id] }),
      );
      // recentWhere = {
      //   ...recentWhere,
      //   [Op.and]: [
      //     Sequelize.where(Sequelize.col('`musician_categories`.`category_id`'), { [Op.in]: [body.category_id] }),
      //   ],
      // };
    }

    recentWhere = {
      ...recentWhere,
      [Op.and]: conditionArr,
    };

    let artistsByCategory = await User.findAll({
      where: recentWhere,
      include: [
        {
          model: UserDetails,
          as: 'details',
          required: false,
        },
        {
          model: MusicianCategories,
          include: [
            {
              model: Category,
              as: 'category',
              where: { is_deleted: 0, is_active: 1 },
              include: [
                {
                  model: CategoryTranslation,
                  where: { language_code: language },
                  as: 'translation',
                  required: false,
                },
              ],
            },
          ],
          as: 'musician_categories',
          required: false,
          attributes: [
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.id`')), 'category_id'],
            [Sequelize.fn('', Sequelize.col('`musician_categories.category.translation.name`')), 'category_name'],
          ],
        },
      ],
      attributes: [
        'id',
        ['en_full_name', 'name'],
        'image',
        // [Sequelize.fn('', Sequelize.col('`favorites`.`is_favorite`')), 'is_favorite'],
        [Sequelize.fn('', Sequelize.col('`details`.`hourly_rate`')), 'hourly_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`fix_rate`')), 'fixed_amount'],
        [Sequelize.fn('', Sequelize.col('`details`.`avg_rating`')), 'average_rate'],
      ],
      offset: start,
      limit: limit,
      subQuery: false,
      logging: true,
      order: [['id', 'DESC']],
      group: ['id'],
    });

    // console.log(artistsByCategory);
    if (artistsByCategory.length >= limit) {
      artistsByCategory.pop();
      is_last = 0;
    }
    if (artistsByCategory) {
      artistsByCategory = await map(artistsByCategory, async elem => {
        const elemJSON: any = elem.toJSON();
        const getFavourite = await userService.checkMusicianFavourite(UserData.id, elem.id);
        if (getFavourite) {
          elemJSON.is_favorite = 1;
        } else {
          elemJSON.is_favorite = 0;
        }
        elemJSON.musician_categories = await userService.getMusicianAllCategory(elemJSON.id, language);
        elemJSON.average_rate = parseFloat(elemJSON.average_rate.toFixed(1));
        return elemJSON;
      });
    }

    return res.send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
        is_last,
        musician_list: artistsByCategory,
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const becomeMusicianBodySchema = Joi.object({
  subject: Joi.string(),
  message: Joi.string(),
  full_name: Joi.string(),
  email: Joi.string(),
  country_code: Joi.string(),
  mobile_number: Joi.string(),
});

interface BecomeMusicianRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    subject: string;
    message: string;
    full_name: string;
    email: string;
    country_code: string;
    mobile_number: string;
  };
}

export const becomeMusicianHandler: RequestHandler = async (
  req: ValidatedRequest<BecomeMusicianRequestSchema>,
  res,
) => {
  const body = req.body;
  const UserData = req.userData;
  const language = req.headers.language;

  try {
    emailService.becomeMusicianEmail(body);
    return res.send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'become_musician_success'),
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const checkMusicianAvailablityBodySchema = Joi.object({
  musician_id: Joi.number().required(),
  start_time: Joi.number().required(),
});

interface CheckMusicianAvailablitySchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    musician_id: number;
    start_time: number;
  };
}

export const checkMusicianAvailablityHandler: RequestHandler = async (
  req: ValidatedRequest<CheckMusicianAvailablitySchema>,
  res,
) => {
  const body = req.body;
  const language = req.headers.language;

  try {
    const checkAvailablity = await userService.getMusicianAvaibilityByTime(body.musician_id, body.start_time);
    return res.send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
        is_available: checkAvailablity,
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

export const dashboard: any = () =>
  router.post('/dashboard', validator.body(homeDataBodySchema), simpleAuthMiddleware, handleError(homeDataHandler));
export const favorite: any = () =>
  router.post(
    '/favorite',
    validator.body(favoriteMusicianBodySchema),
    mainAuthMiddleware,
    handleError(favoriteMusicianHandler),
  );
export const musicianDetails: any = () =>
  router.post(
    '/musicianDetails',
    validator.body(musicianDetailBodySchema),
    simpleAuthMiddleware,
    handleError(musicianDetailHandler),
  );

export const musicianByCategory: any = () =>
  router.post(
    '/musicianbyCategory',
    validator.body(musicianByCategoryBodySchema),
    simpleAuthMiddleware,
    handleError(musicianByCategoryHandler),
  );

export const allFavouriteMusicians: any = () =>
  router.post(
    '/allFavouriteMusicians',
    validator.body(allFavouriteMusiciansBodySchema),
    simpleAuthMiddleware,
    handleError(allFavouriteMusiciansHandler),
  );

export const allMusicians: any = () =>
  router.post(
    '/allMusicians',
    validator.body(allMusiciansBodySchema),
    simpleAuthMiddleware,
    handleError(allMusiciansHandler),
  );

export const becomeMusician: any = () =>
  router.post(
    '/becomeMusician',
    validator.body(becomeMusicianBodySchema),
    simpleAuthMiddleware,
    handleError(becomeMusicianHandler),
  );

export const checkAvailablity: any = () =>
  router.post(
    '/checkAvailablity',
    validator.body(checkMusicianAvailablityBodySchema),
    simpleAuthMiddleware,
    handleError(checkMusicianAvailablityHandler),
  );
