/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import {
  cmsPages,
  faqs,
  contactUs,
  updateBankDetails,
  getCountries,
  getStates,
  getCity,
  getSocialLinks,
  getCategoryList,
  languageList,
  toggleNotification,
  resendEmailVerification,
  reasonsList,
  notificationList,
  clearNotification,
  readNotification,
  notificationCount,
} from './controllers';

const router = Router();

export const common: any = () =>
  router.use([
    cmsPages(),
    faqs(),
    contactUs(),
    updateBankDetails(),
    getCountries(),
    getStates(),
    getCity(),
    getSocialLinks(),
    getCategoryList(),
    languageList(),
    toggleNotification(),
    resendEmailVerification(),
    reasonsList(),
    notificationList(),
    clearNotification(),
    readNotification(),
    notificationCount(),
  ]);
