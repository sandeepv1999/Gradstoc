/* eslint-disable @typescript-eslint/no-explicit-any */
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import * as Joi from '@hapi/joi';

import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';

import handleError from '../../../../middlewares/handle-error';
import { mainAuthMiddleware, message, simpleAuthMiddleware } from '../../../../middlewares/auth.middleware';
import { ReE } from '../../../../services/util.service';

import { FAQ } from '../../../../models/faq.model';
import { FAQTranslation } from '../../../../models/faqTranslation.model';
import * as userService from '../../../../utils/user';
import * as authService from '../../../../utils/auth';

import config from '../../../../config';
import { Actors } from '../../../../utils/constants';
import { Sequelize } from 'sequelize';
import { Feedback } from '../../../../models/feedback.model';
import { Token } from '../../../../models/tokens.model';
import { User } from '../../../../models/users.model';
import { Country } from '../../../../models/country.model';
import { State } from '../../../../models/state.model';
import { City } from '../../../../models/city.model';
import { Settings } from '../../../../models/settings.model';
import { Category } from '../../../../models/category.model';
import { CategoryTranslation } from '../../../../models/categoryTranslation.model';
import { Notifications } from '../../../../models/notification.model';
import { NotificationTranslation } from '../../../../models/notificationTranslation.model';
import { Language } from '../../../../models/language.model';
import { Booking } from '../../../../models/bookings.model';
import { BookingCategory } from '../../../..//models/bookingCategory.model';
import { Reason } from '../../../../models/reason.model';
import { sendVerificationEmail } from '../../../../services/email.service';
import { Op } from 'sequelize';
import moment from 'moment';

const router = Router();
const validator = createValidator({ passError: true });

//  ---------------- |||| CMS PAGES |||| -----------------------
export const cmsHandler: RequestHandler = async (req, res) => {
  const user = req.userData;
  const currentUserLanguage = req.language;
  const language = req.headers.language;

  let cms = {};
  if (user.actor == Actors.Customer) {
    cms = {
      about: `${config.CMS_URL}/cms-page?lang=${currentUserLanguage}&id=1`,
      privacy_policy: `${config.CMS_URL}/cms-page?lang=${currentUserLanguage}&id=2`,
      terms_and_conditions: `${config.CMS_URL}/cms-page?lang=${currentUserLanguage}&id=3`,
    };
  }
  if (user.actor == Actors.Musician) {
    cms = {
      about: `${config.CMS_URL}/cms-page?lang=${currentUserLanguage}&id=4`,
      privacy_policy: `${config.CMS_URL}/cms-page?lang=${currentUserLanguage}&id=5`,
      terms_and_conditions: `${config.CMS_URL}/cms-page?lang=${currentUserLanguage}&id=6`,
    };
  }

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'success'), cms },
  });
};

//  ---------------- |||| FAQs |||| -----------------------
export const faqHandler: RequestHandler = async (req, res) => {
  const user = req.userData;
  const currentUserLanguage = req.language;
  const language = req.headers.language;
  const where: any = {};

  where.is_deleted = 0;
  where.actor = user.actor;

  const FAQs = await FAQ.findAll({
    include: [
      {
        model: FAQTranslation,
        where: {
          language_code: currentUserLanguage,
        },
        as: 'translation',
      },
    ],
    where: where,
    attributes: [
      'id',
      [Sequelize.fn('', Sequelize.col('translation.question')), 'question'],
      [Sequelize.fn('', Sequelize.col('translation.question')), 'answer'],
    ],
    order: [['id', 'DESC']],
  });

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'success'), FAQs },
  });
};

//  ---------------- |||| CONTACT US |||| -----------------------

export const contactUsBodySchema = Joi.object({
  subject: Joi.string().required(),
  message: Joi.string().required(),
  full_name: Joi.string(),
  email: Joi.string(),
  country_code: Joi.string(),
  mobile_number: Joi.number(),
});

interface ContactUsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    subject: string;
    message: string;
    full_name: string;
    email: string;
    country_code: string;
    mobile_number: number;
  };
}

export const contactUsHandler: RequestHandler = async (req: ValidatedRequest<ContactUsRequestSchema>, res) => {
  let user: User = null;

  const token = req.headers['authorization'];
  const language = req.headers.language;

  if (token) {
    const access_token = token.split(' ')[1];
    const tokenData = await Token.findOne({ where: { access_token } });
    if (tokenData) {
      user = await User.findOne({ where: { is_deleted: 0, id: tokenData.user_id } });
    }
  }

  const body = req.body;

  const data = {
    country_code: user ? user.dial_code : body.country_code,
    full_name: user ? user.en_full_name : body.full_name,
    email: user ? user.email : body.email,
    mobile_number: user ? user.phone_number : body.mobile_number,
    subject: body.subject,
    message: body.message,
    i_by: user ? user.id : 0,
    user_id: user ? user.id : 0,
  };

  await Feedback.create(data);

  // Send email to ADMIN

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'contact_us_success') },
  });
};

//  ---------------- |||| GET COUNTRY |||| -----------------------
export const countryHandler: RequestHandler = async (req, res) => {
  const currentUserLanguage = req.language;

  const where: any = {};

  where.is_deleted = 0;
  where.is_active = 1;

  const country = await Country.findAll({
    where: where,
    attributes: [
      [Sequelize.fn('', Sequelize.col('id')), 'country_id'],
      [Sequelize.fn('', Sequelize.col('name')), 'country_name'],
    ],
    order: [['id', 'DESC']],
  });

  return res.send({
    success: 1,
    error: [],
    data: { message: message(currentUserLanguage, 'success'), country },
  });
};

//  ---------------- |||| GET STATE |||| -----------------------

export const getStateBodySchema = Joi.object({
  country_id: Joi.number().required(),
});

interface GetStateRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    country_id: number;
  };
}

export const getStateHandler: RequestHandler = async (req: ValidatedRequest<GetStateRequestSchema>, res) => {
  const body = req.body;
  const where: any = {};
  const language = req.headers.language;

  where.is_deleted = 0;
  where.is_active = 1;
  where.country_id = body.country_id;

  const state = await State.findAll({
    where: where,
    attributes: [
      [Sequelize.fn('', Sequelize.col('id')), 'state_id'],
      [Sequelize.fn('', Sequelize.col('name')), 'state_name'],
    ],
    order: [['id', 'DESC']],
  });

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'success'), state },
  });
};

//  ---------------- |||| GET CITY |||| -----------------------

export const getCityBodySchema = Joi.object({
  state_id: Joi.number().required(),
});

interface GetCityRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    state_id: number;
  };
}

export const getCityHandler: RequestHandler = async (req: ValidatedRequest<GetCityRequestSchema>, res) => {
  const body = req.body;
  const language = req.headers.language;

  const where: any = {};

  where.is_deleted = 0;
  where.is_active = 1;
  where.state_id = body.state_id;

  const city = await City.findAll({
    where: where,
    attributes: [
      [Sequelize.fn('', Sequelize.col('id')), 'city_id'],
      [Sequelize.fn('', Sequelize.col('name')), 'city_name'],
    ],
    order: [['id', 'DESC']],
  });

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'success'), city },
  });
};

//  ---------------- |||| EDIT BANK DETAILS |||| -----------------------

export const editBankDetailsBodySchema = Joi.object({
  full_name: Joi.string().required(),
  // account_number: Joi.string().required(),
  // code: Joi.string().required(), //commented on 21 june 2022
  account_number: Joi.string().allow('', null),
  code: Joi.string().allow('',null),
  iban: Joi.string().allow('',null)
});

interface EditBankDetailsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    full_name: string;
    account_number: string;
    code: string;
    iban: string; //added on 21 june 2022
  };
}

export const editBankDetailsHandler: RequestHandler = async (
  req: ValidatedRequest<EditBankDetailsRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  let user = {} as User;
  try {
    const data = {
      full_name: body.full_name,
      bank_account_no: body.account_number,
      code: body.code,
      iban: body.iban, //added on 21 june 2022
      u_by: userData.id,
    };

    await userService.updateUserBank('user_id', userData.id, data);

    // await userService.updateUserByField('id', userData.id, {
    //   is_bank_completed: 1,
    // });

    if (userData.actor == Actors.Customer) {
      user = await User.scope('customerLogin').findOne({
        where: {
          id: userData.id,
        },
      });
    }

    if (userData.actor == Actors.Musician) {
      user = await userService.musicianResponse(userData.id, language);
    }

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'bank_details_updated_success'),
        user,
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| GET SOCIAL LINKS |||| -----------------------
export const socialLinkHandler: RequestHandler = async (req, res) => {
  const settings = await Settings.findAll();
  const language = req.headers.language;

  const data = {
    instagram_link:
      settings.filter(x => x.key == 'instagram_link').length > 0
        ? settings.filter(x => x.key == 'instagram_link')[0].value
        : '',
    facebook_link:
      settings.filter(x => x.key == 'facebook_link').length > 0
        ? settings.filter(x => x.key == 'facebook_link')[0].value
        : '',
    twitter_link:
      settings.filter(x => x.key == 'twitter_link').length > 0
        ? settings.filter(x => x.key == 'twitter_link')[0].value
        : '',
  };

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'success'), settings: data },
  });
};

//  ---------------- |||| GET Category List |||| -----------------------
export const categoryListHandler: RequestHandler = async (req, res) => {
  // const settings = await Settings.findAll();
  const language = req.headers.language;

  const categories = await Category.findAll({
    where: { is_deleted: 0, is_active: 1 },
    include: [{ model: CategoryTranslation, as: 'translation', where: { language_code: language } }],
    attributes: [
      ['id', 'category_id'],
      [Sequelize.fn('', Sequelize.col('`translation`.`name`')), 'category_name'],
      ['icon_url', 'image'],
      ['sound_url', 'sound'],
      // 'sound_url',
    ],
  });

  // categories.map(elem => {
  //   const elemJSON = elem.toJSON();
  //   delete elemJSON['category'];
  //   return elemJSON;
  // });

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'success'), categories },
  });
};

//  ---------------- |||| GET Languages |||| -----------------------
export const languageListHandler: RequestHandler = async (req, res) => {
  // const settings = await Settings.findAll();
  const language = req.headers.language;

  const languages = await Language.findAll();

  return res.send({
    success: 1,
    error: [],
    data: { message: message(language, 'success'), languages },
  });
};

//  ---------------- |||| Toggle Notification switch |||| -----------------------
export const toggleNotificationHandler: RequestHandler = async (req, res) => {
  // const settings = await Settings.findAll();
  const language = req.headers.language;
  const user = req.userData;
  try {
    const notificationValue = user.is_notification == 0 ? 1 : 0;

    await userService.updateUserByField('id', user.id, { is_notification: notificationValue });
    await authService.updateTokenByField('user_id', user.id, { is_notification: notificationValue });

    return res.send({
      success: 1,
      error: [],
      data: { message: message(language, 'notification_setting_update_success') },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| Resend Email Verification |||| -----------------------
export const resendEmailVerificationBodySchema = Joi.object({
  email: Joi.string().required(),
});

interface ResendEmailVerificationRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    email: string;
  };
}

export const resendEmailVerificationHandler: RequestHandler = async (
  req: ValidatedRequest<ResendEmailVerificationRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const User = await userService.getUserByField('email', body.email);

    if (!User) {
      return ReE(res, message(language, 'no_user_found'), 500);
    }
    await sendVerificationEmail(User);
    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

//  ---------------- |||| REASON LIST |||| -----------------------
export const reasonsListBodySchema = Joi.object({
  start: Joi.number(),
  limit: Joi.number(),
  search_text: Joi.string()
    .allow('')
    .allow(null),
  statusFilter: Joi.number().allow(null),
  type: Joi.number()
    .required()
    .allow(null),
  actor: Joi.number().allow(null),
});

interface ReasonsListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
    search_text: string;
    statusFilter: number;
    type: number;
    actor: number;
  };
}

export const reasonsListHandler: RequestHandler = async (req: ValidatedRequest<ReasonsListRequestSchema>, res) => {
  try {
    const body = req.body;

    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);

    // let is_last = 1;

    /* eslint-disable @typescript-eslint/no-explicit-any */
    const where: any = {};

    where.is_deleted = 0;
    where.type = body.type;

    if (body.statusFilter) {
      where.is_active = { [Op.eq]: body.statusFilter };
    }
    if (body.search_text) {
      // where.reason = { [Op.eq]: body.search_text };
      where.reason = { [Op.like]: '%' + body.search_text + '%' };
    }

    if (body.actor) {
      where.actor = body.actor;
    }

    const reasons = await Reason.findAndCountAll({
      where: where,
      // offset: start,
      // limit: limit,
      order: [['id', 'DESC']],
    });

    if (reasons.rows.length > 0) {
      // if (reasons.rows.length >= limit) {
      //   reasons.rows.pop();
      //   is_last = 0;
      // }
      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', reasons },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No Record found', reasons },
      });
      // return res.status(404).send({ success: 0, error: { message: 'No record found' } });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| NOTIFICATION LIST |||| -----------------------
export const notificationListBodySchema = Joi.object({
  start: Joi.number(),
  limit: Joi.number(),
});

interface NotificationListRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    start: number;
    limit: number;
  };
}

export const notificationListHandler: RequestHandler = async (
  req: ValidatedRequest<NotificationListRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const userData = req.userData;
    const language = req.headers.language;
    const start = Number(body.start ? body.start : 0);
    const limit = Number(body.limit ? Number(body.limit) + 1 : 11);
    const notificationsList = {};
    let is_last = 1;

    /* eslint-disable @typescript-eslint/no-explicit-any */
    const where: any = {};

    const _notifications = await Notifications.findAndCountAll({
      include: [
        {
          model: NotificationTranslation,
          as: 'translation',
          where: { language_code: language },
        },
      ],
      where: {
        is_deleted: 0,
        [Op.and]: [
          Sequelize.where(Sequelize.fn('!FIND_IN_SET', userData.id, Sequelize.col('deleted_by')), { [Op.gte]: 1 }),
          //Sequelize.where(Sequelize.fn('!FIND_IN_SET', userData.id, Sequelize.col('read_by')), { [Op.gte]: 1 }),
          Sequelize.where(Sequelize.fn('FIND_IN_SET', userData.id, Sequelize.col('receiver_ids')), { [Op.gte]: 1 }),
        ],
      },
      attributes: [
        'id',
        'notification_type',
        'redirection_id',
        'read_by',
        'deleted_by',
        'createdAt',
        [
          Sequelize.literal(
            '(SELECT icon_url FROM category_master WHERE is_deleted=0 and id = (select category_id from booking_categories where is_deleted=0 and booking_id =Notifications.redirection_id limit 1))',
          ),
          'category_image',
        ],
      ],
      offset: start,
      limit: limit,
      order: [['id', 'DESC']],
      logging: true,
    });

    if (_notifications.rows.length > 0) {
      if (_notifications.rows.length >= limit) {
        _notifications.rows.pop();
        is_last = 0;
      }

      const notificationsList = _notifications.rows.map(notification => {
        const notificationData: any = notification.toJSON();
        console.log(notificationData);
        let readStatus = 0;
        if (notification.read_by) {
          const readArray = notification.read_by.split(',').map(Number);
          if (readArray.includes(userData.id)) readStatus = 1;
        }
        // const notificationJsonParse = JSON.parse(notificationData.notification_data);
        return {
          id: notificationData.id,
          description: notificationData.translation ? notificationData.translation[0].message : '',
          notification_text: notificationData.translation ? notificationData.translation[0].title : '',
          date: moment(notificationData.createdAt).unix(),
          is_read: readStatus,
          // notification_data: JSON.parse(notificationData.notification_data),
          notification_type: notificationData.notification_type,
          booking_id: notificationData.redirection_id,
          category_image: notificationData.category_image,
        };
      });

      return res.send({
        success: 1,
        error: [],
        data: { message: 'Success', notification: notificationsList, is_last: is_last },
      });
    } else {
      return res.send({
        success: 1,
        error: [],
        data: { message: 'No Record found', notification: [] },
      });
      // return res.status(404).send({ success: 0, error: { message: 'No record found' } });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CLEAR NOTIFICATION |||| -----------------------
export const clearNotificationBodySchema = Joi.object({});

interface ClearNotificationRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {};
}

export const clearNotificationHandler: RequestHandler = async (
  req: ValidatedRequest<ClearNotificationRequestSchema>,
  res,
) => {
  try {
    // const body = req.body;
    const userData = req.userData;
    const language = req.headers.language;
    const _notifications = await Notifications.findAll({
      where: {
        [Op.and]: [
          Sequelize.where(Sequelize.fn('!FIND_IN_SET', userData.id, Sequelize.col('deleted_by')), { [Op.gte]: 1 }),
          Sequelize.where(Sequelize.fn('FIND_IN_SET', userData.id, Sequelize.col('receiver_ids')), { [Op.gte]: 1 }),
          // Sequelize.where(Sequelize.fn('!FIND_IN_SET', userData.id, Sequelize.col('read_by')), { [Op.gte]: 1 }),
        ],
      },
    });
    console.log(_notifications);

    _notifications.forEach(notification => {
      // Now make deleted all notifications
      // if (notification.read_by == null) notification.read_by = userData.id.toString();
      // else notification.read_by = notification.read_by + ',' + userData.id.toString();
      if (notification.deleted_by == null) notification.deleted_by = userData.id.toString();
      else notification.deleted_by = notification.deleted_by + ',' + userData.id.toString();
      notification
        .save()
        .then(() => {
          console.log('All Notification successfully cleared.');
        })
        .catch(err => {
          console.log('Error while reading all notificaitons');
          console.error(err);
        });
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

//  ---------------- |||| CLEAR NOTIFICATION |||| -----------------------
export const readNotificationBodySchema = Joi.object({
  id: Joi.number().required(),
});

interface ReadNotificationRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    id: number;
  };
}

export const readNotificationHandler: RequestHandler = async (
  req: ValidatedRequest<ReadNotificationRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const userData = req.userData;
    const language = req.headers.language;
    const _notifications = await Notifications.findAll({
      where: { id: body.id },
    });
    console.log(_notifications);

    _notifications.forEach(notification => {
      // Now make deleted all notifications
      if (notification.read_by == null) notification.read_by = userData.id.toString();
      else notification.read_by = notification.read_by + ',' + userData.id.toString();
      notification
        .save()
        .then(() => {
          console.log('Notification successfully read.');
        })
        .catch(err => {
          console.log('Error while reading all notificaitons');
          console.error(err);
        });
    });

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success' },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};
//  ---------------- |||| CLEAR NOTIFICATION |||| -----------------------
export const notificationCountBodySchema = Joi.object({});

interface NotificationCountRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {};
}

export const notificationCountHandler: RequestHandler = async (
  req: ValidatedRequest<NotificationCountRequestSchema>,
  res,
) => {
  try {
    const body = req.body;
    const userData = req.userData;
    const language = req.headers.language;
    let countData = 0;
    const _notifications = await Notifications.findAll({
      where: {
        [Op.and]: [
          Sequelize.where(Sequelize.fn('!FIND_IN_SET', userData.id, Sequelize.col('deleted_by')), { [Op.gte]: 1 }),
          Sequelize.where(Sequelize.fn('FIND_IN_SET', userData.id, Sequelize.col('receiver_ids')), { [Op.gte]: 1 }),
          Sequelize.where(Sequelize.fn('!FIND_IN_SET', userData.id, Sequelize.col('read_by')), { [Op.gte]: 1 }),
        ],
      },
    });
    if (_notifications) {
      countData = _notifications.length;
    }

    return res.send({
      success: 1,
      error: [],
      data: { message: 'Success', count: countData },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ success: 0, error: { message: error.message } });
  }
};

export const cmsPages: any = () => router.get('/cms', mainAuthMiddleware, handleError(cmsHandler));
export const faqs: any = () => router.get('/faq', mainAuthMiddleware, handleError(faqHandler));
export const contactUs: any = () =>
  router.post('/contactUs', validator.body(contactUsBodySchema), handleError(contactUsHandler));
export const updateBankDetails: any = () =>
  router.post(
    '/updateBankDetails',
    validator.body(editBankDetailsBodySchema),
    mainAuthMiddleware,
    handleError(editBankDetailsHandler),
  );
export const getCountries: any = () => router.get('/countries', handleError(countryHandler));
export const getStates: any = () =>
  router.post('/states', validator.body(getStateBodySchema), handleError(getStateHandler));

export const getCity: any = () => router.post('/city', validator.body(getCityBodySchema), handleError(getCityHandler));

export const getSocialLinks: any = () => router.get('/socialLinks', handleError(socialLinkHandler));

export const getCategoryList: any = () =>
  router.get('/getCategoryList', simpleAuthMiddleware, handleError(categoryListHandler));

export const languageList: any = () => router.get('/language', handleError(languageListHandler));

export const toggleNotification: any = () =>
  router.get('/toggleNotification', mainAuthMiddleware, handleError(toggleNotificationHandler));

export const resendEmailVerification: any = () =>
  router.post(
    '/resendEmailVerification',
    validator.body(resendEmailVerificationBodySchema),
    mainAuthMiddleware,
    handleError(resendEmailVerificationHandler),
  );

export const reasonsList: any = () =>
  router.post('/reasons', validator.body(reasonsListBodySchema), mainAuthMiddleware, handleError(reasonsListHandler));

export const notificationList: any = () =>
  router.post(
    '/notification',
    validator.body(notificationListBodySchema),
    mainAuthMiddleware,
    handleError(notificationListHandler),
  );
export const clearNotification: any = () =>
  router.post(
    '/clearnotification',
    validator.body(clearNotificationBodySchema),
    mainAuthMiddleware,
    handleError(clearNotificationHandler),
  );
export const readNotification: any = () =>
  router.post(
    '/readnotification',
    validator.body(readNotificationBodySchema),
    mainAuthMiddleware,
    handleError(readNotificationHandler),
  );

export const notificationCount: any = () =>
  router.post(
    '/notificationcount',
    validator.body(notificationCountBodySchema),
    mainAuthMiddleware,
    handleError(notificationCountHandler),
  );
