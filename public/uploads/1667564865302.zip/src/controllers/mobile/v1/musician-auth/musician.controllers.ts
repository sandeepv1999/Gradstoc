/* eslint-disable @typescript-eslint/no-explicit-any */
import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import * as Joi from '@hapi/joi';
import bcrypt from 'bcryptjs';
import * as _ from 'lodash';
import { ContainerTypes, ValidatedRequest, ValidatedRequestSchema } from 'express-joi-validation';

import handleError from '../../../../middlewares/handle-error';
import { mainAuthMiddleware, message, simpleAuthMiddleware } from '../../../../middlewares/auth.middleware';
import { ReE } from '../../../../services/util.service';

import { User } from '../../../../models/users.model';
import { sendForgotPasswordEmail } from '../../../../services/email.service';
import * as userService from '../../../../utils/user';
import * as authService from '../../../../utils/auth';
import moment from 'moment';
import { Sequelize, Op } from 'sequelize';

import { Actors } from '../../../../utils/constants';

const router = Router();
const validator = createValidator({ passError: true });

// ---------------- |||| LOGIN |||| -----------------------
export const loginBodySchema = Joi.object({
  email: Joi.string().required(),
  password: Joi.string().required(),
  device_type: Joi.string().required(),
  device_id: Joi.string().allow('', null),
});

interface LoginRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    email: string;
    password: string;
    device_type: string;
    device_id: string;
  };
}

export const loginHandler: RequestHandler = async (req: ValidatedRequest<LoginRequestSchema>, res) => {
  const body = req.body;
  const language = req.headers.language;
  try {
    const getUserByEmail = await User.scope('musicianLogin').findOne({
      where: { email: body.email, actor: Actors.Musician },
    });

    if (_.isNil(getUserByEmail)) {
      return ReE(res, message(language, 'no_user_found'));
    }

    if (!getUserByEmail.is_active) {
      return ReE(res, message(language, 'account_inactive'));
    }

    if (getUserByEmail.is_suspended) {
      return ReE(res, message(language, 'account_blocked'));
    }

    if (await bcrypt.compare(body.password, getUserByEmail.password)) {
      const token = req.headers.authorization.split(' ')[1];
      const data = {
        user_id: getUserByEmail.id,
        device_type: body.device_type,
        device_id: body.device_id,
        is_notification: 1,
        last_login: moment().unix(),
        user_language: req.headers.language ? req.headers.language : 'en',
      };
      await authService.updateToken(token, data);

      const user = await userService.musicianResponse(getUserByEmail.id, language);

      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: message(language, 'success'),
          auth: { token: token, type: 'Bearer' },
          user,
        },
      });
    } else {
      return ReE(res, message(language, 'wrong_password'), 200);
    }
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| FORGOT PASSWORD |||| -----------------------
export const forgotPasswordBodySchema = Joi.object({
  email: Joi.string().required(),
});

interface ForgotPasswordRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    email: string;
  };
}

export const forgotPasswordHandler: RequestHandler = async (
  req: ValidatedRequest<ForgotPasswordRequestSchema>,
  res,
) => {
  const language = req.headers.language;
  const host = req.headers.host;

  try {
    const body = req.body;

    const User = await userService.getUserByField('email', body.email);

    if (!User) {
      return ReE(res, message(language, 'user_not_found'), 500);
    }
    const forgotPasswordToken = await userService.generateEmailToken();

    const userUpdated = await userService.updateUserByField('id', User.id, {
      forgot_password_token: forgotPasswordToken,
      u_by: User.id,
    });

    await sendForgotPasswordEmail(userUpdated, host);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'forgot_password_send_success'),
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| GET PROFILE |||| -----------------------

export const getProfileHandler: RequestHandler = async (req, res) => {
  const language = req.headers.language;
  try {
    const user = req.userData;
    const token = req.headers.authorization.split(' ')[1];
    const profile = await userService.musicianResponse(user.id, language);

    if (_.isNil(profile)) {
      return ReE(res, message(language, 'no_user_found'));
    }

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'success'),
        auth: { token: token, type: 'Bearer' },
        user: profile,
      },
    });
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| COMPLETE PROFILE |||| -----------------------
export const completeProfileBodySchema = Joi.object({
  image: Joi.string().allow(null, ''),
  email: Joi.string().required(),
  mobile_number: Joi.number().required(),
  country_code: Joi.string().required(),
  name: Joi.string().required(),
  about_me: Joi.string().required(),
});

interface CompleteProfileRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    image: string;
    email: string;
    mobile_number: number;
    country_code: string;
    name: string;
    about_me: string;
  };
}

export const CompleteProfileHandler: RequestHandler = async (
  req: ValidatedRequest<CompleteProfileRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  const token = req.headers.authorization.split(' ')[1];
  try {
    const getUserByEmail = await User.scope('musicianLogin').findOne({
      where: {
        email: body.email,
        actor: Actors.Musician,
        id: {
          [Op.ne]: userData.id,
        },
      },
    });

    if (getUserByEmail) {
      return ReE(res, message(language, 'email_already_exists'));
    }

    const data: any = {
      email: body.email,
      phone_number: body.mobile_number,
      dial_code: body.country_code,
      en_full_name: body.name,
      is_profile_completed: 1,
      u_by: userData.id,
    };

    if (body.image) {
      data.image = body.image;
    }

    const _updated = await userService.updateUserByField('id', userData.id, data);

    const _detailsUpdated = await userService.updateUserDetailsByField('user_id', userData.id, {
      about_me: body.about_me,
    });

    if (_updated && _detailsUpdated) {
      await authService.updateToken(token, { user_id: userData.id, user_language: language });

      const user = await userService.musicianResponse(userData.id, language);

      return res.status(200).send({
        success: 1,
        error: [],
        data: {
          message: message(language, 'profile_update_success'),
          user,
        },
      });
    } else {
      return ReE(res, message(language, 'something_went_wrong'), 200);
    }
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| COMPLETE PROFILE |||| -----------------------
export const updateDetailsBodySchema = Joi.object({
  hourly_rate: Joi.number()
    .min(1)
    .label('Hourly Rate'),
  full_day_rate: Joi.number()
    .min(1)
    .label('Fixed Rate'),
  selected_category: Joi.string().required(),
});

interface UpdateDetailsRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    hourly_rate: number;
    full_day_rate: number;
    selected_category: string;
  };
}

export const updateDetailsHandler: RequestHandler = async (req: ValidatedRequest<UpdateDetailsRequestSchema>, res) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const userDetailsdata = {};
    if (body.hourly_rate) {
      _.set(userDetailsdata, 'hourly_rate', body.hourly_rate);
    }
    if (body.full_day_rate) {
      _.set(userDetailsdata, 'fix_rate', body.full_day_rate);
    }
    await userService.updateUserDetailsByField('user_id', userData.id, userDetailsdata);

    const categories = body.selected_category.split(',');
    const data = [];
    categories.forEach(element => {
      data.push({
        musician_id: userData.id,
        category_id: element,
      });
    });

    await userService.updateMusicianCategories(userData.id, data);

    await userService.updateUserByField('id', userData.id, { is_music_detail_completed: 1 });

    const user = await userService.musicianResponse(userData.id, language);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'profile_update_success'),
        user,
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| COMPLETE PORTFOLIO |||| -----------------------
export const createPortfolioBodySchema = Joi.object({
  category_id: Joi.number().required(),
  title: Joi.string().required(),
  video_url: Joi.string().required(),
  video_thumb: Joi.string().required(),
});

interface CreatePortfolioRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    category_id: number;
    title: string;
    video_url: string;
    video_thumb: string;
  };
}

export const createPortfolioHandler: RequestHandler = async (
  req: ValidatedRequest<CreatePortfolioRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      user_id: userData.id,
      category_id: body.category_id,
      title: body.title,
      video_url: body.video_url,
      video_thumb: body.video_thumb,
      is_approved: 0,
      i_by: userData.id,
    };

    await userService.createMusicianPortfolio(data);

    await userService.updateUserByField('id', userData.id, { is_portfolio_completed: 1 });

    const user = await userService.musicianResponse(userData.id, language);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'portfolio_added_successfully'),
        user,
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};

// ---------------- |||| COMPLETE ADDRESS |||| -----------------------
export const completeAddressBodySchema = Joi.object({
  address_type: Joi.number(),
  address: Joi.string().required(),
  land_mark: Joi.string().required(),
  latitude: Joi.number().required(),
  longitude: Joi.number().required(),
  city_id: Joi.number().required(),
  state_id: Joi.number().required(),
  country_id: Joi.number().required(),
});

interface CompleteAddressRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    address_type: string;
    address: string;
    land_mark: string;
    latitude: number;
    longitude: number;
    city_id: number;
    state_id: number;
    country_id: number;
  };
}

export const completeAddressHandler: RequestHandler = async (
  req: ValidatedRequest<CompleteAddressRequestSchema>,
  res,
) => {
  const body = req.body;
  const userData = req.userData;
  const language = req.headers.language;
  try {
    const data = {
      user_id: userData.id,
      contact_person: userData.en_full_name,
      address: body.address,
      landmark: body.land_mark,
      address_type: body.address_type ? body.address_type : '',
      city_id: body.city_id,
      state_id: body.state_id,
      country_id: body.country_id,
      lat: body.latitude,
      lng: body.longitude,
      is_default: 1,
      u_by: userData.id,
    };

    await userService.createAddress(data);

    await userService.updateUserByField('id', userData.id, {
      is_address_completed: 1,
    });

    const user = await userService.musicianResponse(userData.id, language);

    return res.status(200).send({
      success: 1,
      error: [],
      data: {
        message: message(language, 'address_saved_success'),
        user,
      },
    });
  } catch (error) {
    return ReE(res, message(language, 'internal_server_error'));
  }
};
// ---------------- |||| CHANGE PASSWORD |||| -----------------------
export const changePasswordBodySchema = Joi.object({
  old_password: Joi.string().required(),
  new_password: Joi.string().required(),
});

interface ChangePasswordRequestSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    old_password: string;
    new_password: string;
  };
}

export const changePasswordHandler: RequestHandler = async (
  req: ValidatedRequest<ChangePasswordRequestSchema>,
  res,
) => {
  const language = req.headers.language;
  try {
    const data = req.body;
    const userData = req.userData;

    if (await authService.comparePassword(data.old_password, userData.password)) {
      const newPassword = await authService.encryptPassword(data.new_password);
      const userUpdatedData = await userService.updateUserByField('id', userData.id, {
        password: newPassword,
      });
      if (!userUpdatedData) {
        return ReE(res, message(language, 'no_user_found'));
      } else {
        return res.status(200).send({
          success: 1,
          error: [],
          data: {
            message: message(language, 'password_change_success'),
          },
        });
      }
    } else {
      return ReE(res, message(language, 'old_password_not_match'), 200);
    }
  } catch (error) {
    console.log(error);
    return ReE(res, message(language, 'internal_server_error'), 500);
  }
};
// ---------------- |||| ROUTES |||| -----------------------
export const signIn: any = () =>
  router.post('/login', validator.body(loginBodySchema), simpleAuthMiddleware, handleError(loginHandler));

export const forgotPassword: any = () =>
  router.post(
    '/forgotPassword',
    validator.body(forgotPasswordBodySchema),
    simpleAuthMiddleware,
    handleError(forgotPasswordHandler),
  );

export const getProfile: any = () => router.get('/profile', mainAuthMiddleware, handleError(getProfileHandler));

export const completeProfile: any = () =>
  router.post(
    '/updateProfile',
    validator.body(completeProfileBodySchema),
    simpleAuthMiddleware,
    handleError(CompleteProfileHandler),
  );

export const completeMusicianDetails: any = () =>
  router.post(
    '/updateDetails',
    validator.body(updateDetailsBodySchema),
    simpleAuthMiddleware,
    handleError(updateDetailsHandler),
  );

export const completePortfolio: any = () =>
  router.post(
    '/addPortfolio',
    validator.body(createPortfolioBodySchema),
    simpleAuthMiddleware,
    handleError(createPortfolioHandler),
  );

export const completeAddress: any = () =>
  router.post(
    '/completeAddress',
    validator.body(completeAddressBodySchema),
    mainAuthMiddleware,
    handleError(completeAddressHandler),
  );

export const changePassword: any = () =>
  router.post(
    '/changePassword',
    validator.body(changePasswordBodySchema),
    mainAuthMiddleware,
    handleError(changePasswordHandler),
  );
