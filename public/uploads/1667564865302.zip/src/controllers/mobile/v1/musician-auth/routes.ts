/* eslint-disable @typescript-eslint/no-explicit-any */
import { Router } from 'express';
import {
  signIn,
  forgotPassword,
  getProfile,
  completeProfile,
  completeMusicianDetails,
  completePortfolio,
  completeAddress,
  changePassword,
} from './musician.controllers';

const router = Router();

export const musicianAuth: any = () =>
  router.use([
    signIn(),
    forgotPassword(),
    getProfile(),
    completeProfile(),
    completeMusicianDetails(),
    completePortfolio(),
    completeAddress(),
    changePassword(),
  ]);
