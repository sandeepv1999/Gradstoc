import { RequestHandler, Router } from 'express';
import { createValidator } from 'express-joi-validation';
import handleError from '../../middlewares/handle-error';
import { JWT } from '../../utils/jwt';
import config from '../../config';
import axios from 'axios';
import crypto from 'crypto';
import moment from 'moment';
// const fs = require('fs');
import fs from 'fs';
// import file from '../../../'
// let resCode = fs.readFileSync('../../../response-code.json');
// let getResCode = JSON.parse(resCode);
import path from 'path';
import { Booking } from '../../models/bookings.model';

// const crypto = require('crypto');

const hostName = config.HOSTNAME;
const responseCodeFilePath = path.join(__dirname, './response-code.json');
console.log(responseCodeFilePath);
const resCode = fs.readFileSync(responseCodeFilePath).toString();

const getResCode = JSON.parse(resCode);
// console.log('aaaa', hostName + '/api/payment/reciept');
// const configData = {
//   service_url: 'https://payments-dev.urway-tech.com/URWAYPGService/transaction/jsonProcess/JSONrequest',
//   terminalId: 'nodeJs',
//   merchantkey: '4e5b624f798b6f8fa39dd0125ec1f37d3b33b473cdba6bbf03c99f3554caa32d',
//   password: 'password',
//   currency: 'SAR',
//   reciepturl: hostName + '/api/payment/reciept',
// };

//test
// const configData = {
//   service_url: 'https://payments-dev.urway-tech.com/URWAYPGService/transaction/jsonProcess/JSONrequest',
//   terminalId: 'alhaan',
//   merchantkey: 'c3cd33d6cb6c6bbe603ccb5e6507e0df43ca29556ca66c35b107834afec519c2',
//   password: 'alhaan@123',
//   currency: 'SAR',
//   reciepturl: hostName + '/api/payment/reciept',
// };

//live
const configData = {
  service_url: 'https://payments.urway-tech.com/URWAYPGService/transaction/jsonProcess/JSONrequest',
  terminalId: 'alhaan',
  merchantkey: 'b419ad05115dc6c28db3c8b6295a625eeda54cf5d8619d760eef16a8548c68a4',
  password: 'alhaan@URWAY_123',
  currency: 'SAR',
  reciepturl: hostName + '/api/payment/reciept',
};

const router = Router();
const validator = createValidator();
const jwt = new JWT(config);

const GetPayHandler: RequestHandler = async (req, res) => {
  try {
    const { token } = req.query;

    // console.log('host',req.headers.host);

    const data = await jwt.verifyToken(token);
    console.log(data);

    res.render('payment/pay', { data, token });
  } catch (error) {
    console.log('pay handler error***********', error);
    // res.locals.error_msg = 'Something went wrong!';
    // res.status(400);
    // return res.redirect(200,'payment/error');
    return res.redirect('/api/payment/err');
    // res.render('payment/error', { errormsg: 'Something went wrong' });
  }
};

const PostPayHandler: RequestHandler = async (req: any, res) => {
  try {
    const body = req.body;
    const { token } = req.query;

    console.log(body);

    const data: any = await jwt.verifyToken(body.token);
    console.log(data);

    const keys =
      body.track_id +
      '|' +
      configData.terminalId +
      '|' +
      configData.password +
      '|' +
      configData.merchantkey +
      '|' +
      parseFloat(data.amount).toFixed(2) +
      '|' +
      data.currancy;

    const hash = crypto
      .createHash('sha256')
      .update(keys)
      .digest('hex');
    console.log('****************ip', data.ip);
    const paymentData = {
      trackid: body.track_id,
      terminalId: configData.terminalId,
      password: configData.password,
      action: '1',
      // merchantIp: '180.211.110.125',
      // merchantIp: req.connection.remoteAddress,
      merchantIp: data.ip,
      country: data.country.toUpperCase(),
      currency: data.currancy.toUpperCase(),
      address: '',
      amount: parseFloat(data.amount).toFixed(2),
      udf1: data.booking_id.toString(),
      tokenizationType: '0',
      cardToken: '',
      firstName: body.name,
      customerEmail: body.email,
      // customerEmail: 'faizanuddin@peerbits.com',
      requestHash: hash,
      tokenOperation: 'A',
      transid: '',
      udf2: configData.reciepturl,
    };
    console.log('paymentData*******', paymentData);

    axios
      .post(configData.service_url, JSON.stringify(paymentData), {
        headers: { 'content-type': 'application/json' },
      })
      .then(response => {
        console.log('***************** Response *******************');
        console.log(response.data);
        const responsePayment = response.data;
        if (responsePayment.responseCode) {
          if (responsePayment.responseCode === '000') {
            const receiptpageshow = 'display';
            const receiptpagehide = 'display:none';
            let transDate = '';
            if (responsePayment.trandate) transDate = responsePayment.trandate;
            else transDate = moment(new Date()).format('yyyy-MM-dd, HH:mm');
            const statusMsgColor = true;
            req.session.processing = true;
            const receiptData = {
              resultset: getResCode[responsePayment.responseCode],
              tranIdset: responsePayment.tranid,
              amountset: responsePayment.amount,
              currentdateset: transDate,
              receiptpageshowset: receiptpageshow,
              receiptpagehideset: receiptpagehide,
              statasColor: statusMsgColor,
              cardtoken: responsePayment.cardToken,
            };
            res.render('payment/receipt', {
              data: receiptData,
            });
          } else {
            const receiptpageshow = 'display';
            const receiptpagehide = 'display:none';
            const statusMsgColor = false;
            let transDate = '';
            if (responsePayment.trandate) transDate = responsePayment.trandate;
            else transDate = moment().format('yyyy-MM-dd, HH:mm');
            req.session.processing = true;
            const receiptData = {
              resultset: getResCode[responsePayment.responseCode],
              tranIdset: responsePayment.tranid,
              amountset: responsePayment.amount,
              currentdateset: transDate,
              receiptpageshowset: receiptpageshow,
              receiptpagehideset: receiptpagehide,
              statasColor: statusMsgColor,
              cardtoken: responsePayment.cardToken,
            };
            res.render('payment/receipt', {
              data: receiptData,
            });
          }
        } else {
          const error = null;
          req.session.processing = true;
          const redirectURL = (responsePayment.targetUrl + '').replace('?', '') + '?paymentid=' + responsePayment.payid;
          req.session.setRedirectURL = redirectURL;
          res.redirect(redirectURL);
        }
      })
      .catch(err => {
        console.log('***************** Error *******************');
        console.error(err);
      });

    // res.render('payment1/pay');
  } catch (error) {
    console.log(error);
    res.locals.error_msg = 'Something went wrong!';
    res.status(400);
  }
};

const getRecieptHandler: RequestHandler = async (req: any, res) => {
  try {
    req.session.processing = true;
    const apiURL = configData.service_url;
    const query = req.query;
    console.log('*********************** query is logged here ***************************');
    console.log(query);
    const responseHash = query.responseHash;
    const getToken = query.cardToken + '' == 'null' ? '' : query.cardToken;
    const requestkeys = query.TranId + '|' + configData.merchantkey + '|' + query.ResponseCode + '|' + query.amount;
    const requesthash = crypto
      .createHash('sha256')
      .update(requestkeys)
      .digest('hex');
    const setPostRequest = {
      firstName: '',
      lastName: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      phoneNumber: '',
      trackid: query.TrackId,
      terminalId: configData.terminalId,
      customerEmail: '',
      action: '10',
      merchantIp: '',
      password: configData.password,
      currency: configData.currency.toUpperCase(),
      country: '',
      transid: query.TranId,
      amount: query.amount,
      tokenOperation: '',
      cardToken: '',
      requestHash: '',
      udf1: query.UserField1,
      udf2: '',
      udf3: '',
      udf4: '',
      udf5: '',
    };

    const currentdate = new Date();
    if (requesthash === responseHash) {
      const postHashSequence =
        query.TrackId +
        '|' +
        configData.terminalId +
        '|' +
        configData.password +
        '|' +
        configData.merchantkey +
        '|' +
        Number(query.amount) +
        '|' +
        configData.currency;
      const generatePostHash = crypto
        .createHash('sha256')
        .update(postHashSequence)
        .digest('hex');
      axios
        .post(
          configData.service_url,
          JSON.stringify({
            firstName: '',
            lastName: '',
            address: '',
            city: '',
            state: '',
            zipCode: '',
            phoneNumber: '',
            trackid: query.TrackId,
            terminalId: configData.terminalId,
            customerEmail: '',
            action: 10,
            merchantIp: '',
            password: configData.password,
            currency: configData.currency,
            country: '',
            transid: query.TranId,
            amount: Number(query.amount),
            tokenOperation: '',
            cardToken: '',

            requestHash: generatePostHash,
            udf1: query.UserField1,
            udf2: '',
            udf3: '',
            udf4: '',
            udf5: '',
          }),
          { headers: { 'content-type': 'application/json' } },
        )
        .then(async response => {
          const responsePayment = response.data;
          // console.log(body)
          // let responsePayment = JSON.parse(body);
          if (responsePayment.result + '' === 'Successful' && query.Result + '' === 'Successful') {
            const receiptpageshow = 'display';
            const receiptpagehide = 'display:none';
            let transDate = moment().format('yyyy-MM-dd, HH:mm');
            if (responsePayment.trandate) transDate = responsePayment.trandate;
            else transDate = moment().format('yyyy-MM-dd, HH:mm');
            const statusMsgColor = true;
            const receiptData: any = {
              resultset: getResCode[query.ResponseCode],
              tranIdset: query.TranId,
              amountset: query.amount,
              currentdateset: transDate,
              receiptpageshowset: receiptpageshow,
              receiptpagehideset: receiptpagehide,
              statasColor: statusMsgColor,
              cardtoken: getToken,
            };
            const bookignData = await Booking.findOne({ where: { id: query.UserField1 } });
            if (bookignData) {
              await Booking.update({ is_active: 1 }, { where: { id: bookignData.id } });
              receiptData.is_booking_updated = 1;
              receiptData.errorMessage = '';
            } else {
              receiptData.is_booking_updated = 0;
              receiptData.errorMessage = 'Booking not found';
            }

            res.render('payment/receipt', {
              receiptData: receiptData,
              data: JSON.stringify(receiptData),
            });
          } else {
            const receiptpageshow = 'display';
            const receiptpagehide = 'display:none';
            let transDate = moment().format('yyyy-MM-dd, HH:mm');
            if (responsePayment.trandate) transDate = responsePayment.trandate;
            else transDate = moment().format('yyyy-MM-dd, HH:mm');
            const statusMsgColor = false;
            const receiptData = {
              resultset: getResCode[query.ResponseCode],
              tranIdset: query.TranId,
              amountset: query.amount,
              currentdateset: transDate,
              receiptpageshowset: receiptpageshow,
              receiptpagehideset: receiptpagehide,
              statasColor: statusMsgColor,
              cardtoken: getToken,
              is_booking_updated: 0,
              errorMessage: 'Something went wrong',
            };
            res.render('payment/receipt', {
              receiptData: receiptData,
              data: JSON.stringify(receiptData),
            });
          }
        })
        .catch(err => {
          console.log('***************** Error *******************');
          console.error(err);
        });
    }
  } catch (error) {
    throw new Error(error);
  }
};
const getErrorPageHandler: RequestHandler = async (req, res) => {
  console.log('****************in******************');
  res.render('payment/error');
};
export const getPay: any = () => router.get('/pay', handleError(GetPayHandler));

export const postPay: any = () => router.post('/pay', handleError(PostPayHandler));

export const getReciept: any = () => router.get('/reciept', handleError(getRecieptHandler));

export const getErrorPage: any = () => router.get('/err', handleError(getErrorPageHandler));
