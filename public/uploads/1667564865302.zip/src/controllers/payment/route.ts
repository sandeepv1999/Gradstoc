import { Router } from 'express';
import { getPay, getReciept, postPay, getErrorPage } from './controller';

const router = Router();

router.get('/status', (req, res) => res.json({ status: 'Payment UP' }));

router.use([getPay(), postPay(), getReciept(), getErrorPage()]);

export default router;
