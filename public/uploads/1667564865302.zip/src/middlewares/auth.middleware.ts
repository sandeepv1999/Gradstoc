/* eslint-disable @typescript-eslint/no-explicit-any */
import { Response, NextFunction, Request } from 'express';
import { User } from '../models/users.model';

import { Token } from '../models/tokens.model';
import { Messages_ar, Messages_en } from '../utils/message';

const simpleAuthMiddleware = async (req: Request, res: Response, next: NextFunction): Promise<any> => {
  const tokenWithType: any = req.headers['authorization'] ? req.headers['authorization'] : null;
  const tokenType = tokenWithType ? tokenWithType.split(' ')[0] : null;
  const token = tokenWithType ? tokenWithType.split(' ')[1] : null;
  if (!tokenWithType) {
    return res.status(401).json({
      success: 0,
      status: 401,
      error: {
        message: 'Unauthorized',
      },
    });
  }
  if (tokenType != 'Bearer') {
    return res.status(401).json({
      success: 0,
      status: 401,
      error: {
        message: 'Unauthorized',
      },
    });
  }
  console.log(token);
  const Where: any = {};
  Where.access_token = token;
  // Where.is_active = 1;
  const tokenData = await Token.findOne({ where: Where, logging: true });
  console.log(tokenData);
  if (!tokenData) {
    return res.status(401).json({
      success: 0,
      status: 401,
      data: {
        data: {},
        message: 'Unauthorized',
      },
    });
  }
  if (tokenData.user_id) {
    const userData = await User.findOne({ where: { is_deleted: 0, id: tokenData.user_id } });
    req.userData = userData;
  }
  next();
};

const mainAuthMiddleware = async (req: Request, res: Response, next: NextFunction): Promise<any> => {
  console.log('mainAuth');
  const tokenWithType: any = req.headers['authorization'] ? req.headers['authorization'] : null;
  const language: any = req.headers.language ? req.headers.language : 'en';
  const tokenType = tokenWithType ? tokenWithType.split(' ')[0] : null;
  const token = tokenWithType ? tokenWithType.split(' ')[1] : null;
  if (!tokenWithType) {
    // CHECK TOKEN.
    return res.status(401).json({
      success: 0,
      status: 401,
      error: {
        message: 'Unauthorized',
      },
    });
  }
  if (tokenType != 'Bearer') {
    // CHECK TOKEN TYPE.
    return res.status(401).json({
      success: 0,
      status: 401,
      error: {
        message: 'Unauthorized',
      },
    });
  }
  const Where: any = {};
  Where.access_token = token;
  // FIND TOKEN DATA USING TOKEN.
  let tokenData = await Token.findOne({ where: Where });

  if (!tokenData) {
    // IF TOKEN DATA NOT FOUND.
    return res.status(401).json({
      success: 0,
      status: 401,
      error: {
        message: 'Unauthorized',
      },
    });
  }
  console.log('========>1');
  if (language && tokenData.user_language !== language) {
    await Token.update({ user_language: language }, { where: { id: tokenData.id } });
    tokenData = await Token.findOne({ where: Where });
  }
  console.log('========>2');

  if (tokenData.user_id) {
    // IF TOKEN DATA FOUND ADD USER DATA IN REQ.
    const userData = await User.scope('withPassword').findOne({ where: { is_deleted: 0, id: tokenData.user_id } });
    req.userData = userData;
    req.language = tokenData.user_language ? tokenData.user_language : language;
  }
  console.log('========>3');

  next();
};

const message = (language, messageKey): any => {
  console.log('***********' + language + '*****************');
  const message = language == 'ar' ? Messages_ar[messageKey] : Messages_en[messageKey];
  return message
    ? message
    : language == 'ar'
    ? Messages_ar['message_not_available']
    : Messages_en['message_not_available'];
  // if (language == 'ar') {
  //   message = Messages_ar[messageKey];
  // } else {
  //   message = Messages_en[messageKey];
  // }
  if (message) {
    return message;
  } else {
    return Messages_en['something_went_wrong'];
  }
};

export { simpleAuthMiddleware, mainAuthMiddleware, message };
