/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { User } from '../models/users.model';

declare global {
  namespace Express {
    interface Request {
      userData?: User;
      language?: string;
    }
    // namespace MulterS3 {
    //   interface File extends Multer.File {
    //     bucket: string;
    //     key: string;
    //     acl: string;
    //     contentType: string;
    //     contentDisposition: null;
    //     storageClass: string;
    //     serverSideEncryption: null;
    //     metadata: any;
    //     location: string;
    //     etag: string;
    //   }
    // }
  }
}
