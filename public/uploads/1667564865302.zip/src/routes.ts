/**
 * @file Routes
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { Router } from 'express';
import adminRouts from './controllers/admin/routes';
import mobileV1Routs from './controllers/mobile/v1/routes';
import paymentRoutes from './controllers/payment/route';

const router = Router();

// Health status
router.get('/status', (req, res) => res.json({ status: 'UP' }));

// Admin routes
router.use('/admin', adminRouts);

// Mobile V1 routes
router.use('/v1', mobileV1Routs);

// Mobile V1 routes
router.use('/payment', paymentRoutes);

export default router;
