/**
 * @file config
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

import { CleanEnv, cleanEnv, makeValidator, num, port, str } from 'envalid';

import nodeURL from 'url';

type Environment = {
  NODE_ENV: string;
  PORT: number;
  WHITELIST_ORIGINS: string[];
  DB_URI: string;
  PBKDF2_N_SALT_BYTES: number;
  SMTP_USER: string;
  SMTP_PASS: string;
  SMTP_PORT: number;
  SMTP_HOST: string;
  SMTP_FROM_EMAIL: string;
  CONTACT_US_EMAIL: string;
  BCRYPT_ROUND_FOR_PASSWORD: number;
  IMAGE_UPLOAD_PATH: string;
  AWS_SECRET_ACCESS_KEY: string;
  AWS_REGION: string;
  AWS_BUCKET: string;
  AWS_ACCESS_KEY_ID: string;
  CLIENT_EMAIL: string;
  FRONTEND_URL: string;
  CMS_URL: string;
  PLAY_STORE_LINK_MUSICIAN: string;
  APPLE_APP_STORE_LINK_MUSICIAN: string;
  PLAY_STORE_LINK_CUSTOMER: string;
  APPLE_APP_STORE_LINK_CUSTOMER: string;
  TWILIO_NUMBER: string;
  TWILIO_ACCOUNT_SID: string;
  TWILIO_AUTH_TOKEN: string;
  SMS_CLIENT_ID: string;
  SMS_API_KEY: string;
  SMS_SENDER_ID: string;
  SMS_URL: string;
  CURRENCY: string;

  DB_HOST: string;
  DB_PORT: string;
  DB_NAME: string;
  DB_USER: string;
  DB_PASSWORD: string;
  DB_DIALECT: string;

  FIREBASE_API_KEY: string;
  CONSICUTIVE_CANCELLATION: number;
  PLAY_STORE: string;
  APP_STORE: string;
  PAYMENT_SECRET_HEX: string;
  PAYMENT_TOKEN_LIFETIME_MIN: number;
  HOSTNAME: string;
};

const origins = makeValidator<string[]>((x: string) => {
  let origins: string[];
  try {
    origins = JSON.parse(x);
  } catch (error) {
    throw new Error(`Invalid urls: "${x}"`);
  }
  return origins.map((origin, index) => {
    try {
      new nodeURL.URL(origin);
      return origin;
    } catch (e) {
      throw new Error(`Invalid url at position [${index}]: "${origin}"`);
    }
  });
}, 'origins');

export type Config = Readonly<Environment & CleanEnv>;

const config: Config = cleanEnv<Environment>(process.env, {
  NODE_ENV: str({ choices: ['production', 'test', 'development'] }),
  PORT: port(),
  WHITELIST_ORIGINS: origins(),
  DB_URI: str(),
  PBKDF2_N_SALT_BYTES: num(),
  SMTP_USER: str(),
  SMTP_PASS: str(),
  SMTP_PORT: num(),
  SMTP_HOST: str(),
  SMTP_FROM_EMAIL: str(),
  CONTACT_US_EMAIL: str(),
  BCRYPT_ROUND_FOR_PASSWORD: num(),
  IMAGE_UPLOAD_PATH: str(),
  AWS_SECRET_ACCESS_KEY: str(),
  AWS_REGION: str(),
  AWS_BUCKET: str(),
  AWS_ACCESS_KEY_ID: str(),
  CLIENT_EMAIL: str(),
  FRONTEND_URL: str(),
  CMS_URL: str(),
  PLAY_STORE_LINK_MUSICIAN: str(),
  APPLE_APP_STORE_LINK_MUSICIAN: str(),
  PLAY_STORE_LINK_CUSTOMER: str(),
  APPLE_APP_STORE_LINK_CUSTOMER: str(),
  CURRENCY: str(),

  TWILIO_NUMBER: str(),
  TWILIO_ACCOUNT_SID: str(),
  TWILIO_AUTH_TOKEN: str(),

  SMS_CLIENT_ID: str(),
  SMS_API_KEY: str(),
  SMS_SENDER_ID: str(),
  SMS_URL: str(),

  DB_HOST: str(),
  DB_PORT: str(),
  DB_NAME: str(),
  DB_USER: str(),
  DB_PASSWORD: str(),
  DB_DIALECT: str(),

  FIREBASE_API_KEY: str(),
  CONSICUTIVE_CANCELLATION: num(),
  PLAY_STORE: str(),
  APP_STORE: str(),
  PAYMENT_SECRET_HEX: str(),
  PAYMENT_TOKEN_LIFETIME_MIN: num(),
  HOSTNAME: str(),
});

export default config;
