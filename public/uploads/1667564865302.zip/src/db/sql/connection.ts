/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @file db
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

// import * as Sequelize from 'sequelize';
import { Sequelize } from 'sequelize';
import config from '../../config';
const databaseUrl = config.DB_URI;

export function setUpSequelize(): any {
  // const sequelize = new Sequelize(databaseUrl, { logging: true });
console.log("CONFIG",config.DB_NAME, config.DB_USER, config.DB_PASSWORD)
  const sequelize = new Sequelize(config.DB_NAME, config.DB_USER, config.DB_PASSWORD, {
    host: config.DB_HOST,
    dialect: 'mysql',
    port: Number(config.DB_PORT),
    logging: true,
  });

  return sequelize;
}
