// import { Server } from 'http';
import app from './app';
import logger from './logger';
import { setUpSequelize } from './db/sql/connection';
// HTTP server
// let server: Server;

const sequelize = setUpSequelize();
sequelize
  .authenticate()
  .then(() => {
    logger.info('DB Connection has been established successfully.');
    app.listen(app.get('port'), (): void => {
      logger.info(`🌏🌏🌏🌏  Express server started at http://localhost:${app.get('port')}   🌏🌏🌏🌏`);
    });
  })
  .catch((err: Error) => {
    console.error('Unable to connect to the database:', err);
  });
