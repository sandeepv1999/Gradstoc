/**
 * @file Express App file
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 */

/* eslint-disable @typescript-eslint/no-explicit-any */

import path from 'path';

import express, { Request, Response, NextFunction } from 'express';
import bodyParser from 'body-parser';
import compression from 'compression';
import cors from 'cors';

import { NotFoundError } from './errors';
import routes from './routes';
import config from './config';
// import { ContainerTypes, ExpressJoiError } from 'express-joi-validation';
import { ExpressJoiError } from 'express-joi-validation';
import { ReE } from './services/util.service';
import exphbs from 'express-handlebars';
import session from 'express-session';

// Express application
const app = express();
const hbs = exphbs.create({ defaultLayout: 'layout', extname: '.hbs' });

app.set('views', path.join(__dirname, 'views'));

app.engine(
  'hbs',
  exphbs({
    defaultLayout: 'layout',
    extname: '.hbs',
  }),
);

app.set('view engine', 'hbs');

// app.engine(
//   'hbs',
//   exphbs({
//     defaultLayout: 'layout',
//     extname: '.hbs',
//   }),
// );

// Set port
app.set('port', config.PORT || 3000);

// Configure middleware
app.use(cors());
// app.use(cors({ origin: config.WHITELIST_ORIGINS }));
app.use(compression());
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({ extended: true ,limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 31557600000 }));
app.use(session({ secret: 'aF[w-T}.@(t4#Z6t', saveUninitialized: false, resave: false }));
// API routes
app.use('/api', routes);

app.use(express.static(path.join(__dirname, 'adminpanel')));
app.get('/*', function(req, res) {
  res.sendFile(path.join(__dirname, 'adminpanel', 'index.html'));
});

// Handle 404 error
/* eslint-disable @typescript-eslint/no-unused-vars */
app.use((req, res, next) => next(new NotFoundError()));

// app.use((err: any | ExpressJoiError, req: express.Request, res: express.Response, next: NextFunction) => {
//   // ContainerTypes is an enum exported by this module. It contains strings
//   // such as "body", "headers", "query"...
//   if (err && err.type in ContainerTypes) {
//     const e: ExpressJoiError = err;
//     // e.g "you submitted a bad query paramater"
//     res.status(400).end(`You submitted a bad ${e.type} paramater`);
//   } else {
//     res.status(500).end('internal server error');
//   }
// });

app.use((err: any | ExpressJoiError, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.log(err);
  if (err.message) {
    return ReE(res, err.message, err.status);
  }
  const e: ExpressJoiError = err;
  return ReE(res, e.error.details[0].message, 400);
});

// Handle application errors
// app.use((err: any | ApplicationError | ExpressJoiError, req: Request, res: Response, next: NextFunction) => {
//   console.log('******************111111');
//   if (res.headersSent) {
//     return next(err);
//   }
//   console.log(err);
//   // return ReE(res, err.error.details[0].message);

//   return res.status(err.status ?? 500).json({
//     error: config.isDevelopment ? err : undefined,
//     message: err.message,
//     code: err.code,
//   });
// });

export default app;
