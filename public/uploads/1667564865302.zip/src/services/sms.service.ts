/**
 * @file SMS service
 * @copyright Peerbits
 * @author Arshad Shaikh<arshad@peerbits.com>
 * DESCRIPTION
 */

import axios, { AxiosRequestConfig } from 'axios';

import { Twilio } from 'twilio';
import config from '../config';

// import https from 'https';

// getting ready
const twilioNumber = config.TWILIO_NUMBER;
const accountSid = config.TWILIO_ACCOUNT_SID;
const authToken = config.TWILIO_AUTH_TOKEN;
const client = new Twilio(accountSid, authToken);

export const sendSMS = async (toNumber, text) => {
  // const messageDetails = {
  //   SenderId: `${config.SMS_SENDER_ID}`,
  //   Is_Unicode: true,
  //   Is_Flash: true,
  //   ApiKey: `${config.SMS_API_KEY}`,
  //   ClientId: `${config.SMS_CLIENT_ID}`,
  //   Message: `${text}`,
  //   MobileNumbers: `${toNumber.replace(/\+/g, '')}`, //Removing (+)prefix from number
  // };

  const messageDetails = { 
    api_id: `${config.SMS_API_KEY}`, 
    api_password: `${config.SMS_CLIENT_ID}`, 
    sms_type: "T", 
    encoding: "T", 
    sender_id: `${config.SMS_SENDER_ID}`, 
    phonenumber: `${toNumber.replace(/\+/g, '')}`, //Removing (+)prefix from number, 
        templateid: null, 
        textmessage:`${text}`, 
        V1: null, 
        V2: null, 
        V3: null, 
        V4: null, 
        V5: null,
    ValidityPeriodInSeconds: 60,
    uid:"xyz",
    callback_url:"https://xyz.com/",
    pe_id:null,
    template_id:null
    } 

  console.log('messageDetails', messageDetails);

  const options: AxiosRequestConfig = {
    method: 'POST',
    url: `${config.SMS_URL}`,
    // url: 'https://rest.gateway.sa/api/SendSMS?api_id=API6186597292&api_password=rOMRXd0hWm&sms_type=T&encoding=T&sender_id=AlhanAlZman&phonenumber=+966555277756&textmessage=test&uid=xyz&callback_url=https://xyz.com/',
    data: messageDetails,
    transformResponse: [
      response => {
        console.log('SMS response:   ', response);
        return response;
      },
    ],
  };
  // send the request
  await axios(options);
};

/*
//USING TWILIO
export const sendSMS = async (toNumber, text) => {
  console.log('\x1b[36m%s\x1b[0m', '*********toNumber,text****************');
  console.log(toNumber, text);
  console.log('\x1b[36m%s\x1b[0m', '*********toNumber,text****************');
  const textContent = {
    body: text,
    to: toNumber,
    from: twilioNumber,
  };
  await client.messages
    .create(textContent)
    .then(message => console.log(message.to))
    .catch(err => {
      console.log('\x1b[36m%s\x1b[0m', '**********twilio***************');
      console.log(err);
      console.log('\x1b[36m%s\x1b[0m', '**********twilio***************');
    });
};
*/
// const sendSMS = async (User, otp) => {
//   const options = {
//     hostname: 'flaviocopes.com',
//     port: 443,
//     path: '/todos',
//     method: 'POST',
//     headers: {
//       'Content-Type': 'application/json',
//       'Content-Length': data.length,
//     },
//   };
// };
