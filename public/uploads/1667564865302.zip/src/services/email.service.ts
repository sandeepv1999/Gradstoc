import nodemailer from 'nodemailer';
import config from '../config';
import { EmailTemplateTranslation } from '../models/emailTemplateTranslation.model';
import { EnailTemplates } from '../models/email_templates.model';
import smtpTransport from 'nodemailer-smtp-transport';
import { Settings } from '../models/settings.model';

const transporter = nodemailer.createTransport(
  smtpTransport({
    host: config.SMTP_HOST,
    port: config.SMTP_PORT,
    auth: {
      user: config.SMTP_USER,
      pass: config.SMTP_PASS,
    },
  }),
);

const sendMusicianRegistrationEmail = async (User, key) => {
  let image;
  //make mail setting

  const emailTemplate = await EnailTemplates.findOne({
    where: { is_deleted: 0, is_active: 1, key },
    include: [
      {
        model: EmailTemplateTranslation,
        where: { language_code: 'en' },
        as: 'translation',
      },
    ],
  });

  if (emailTemplate) {
    const setting = await Settings.findOne({
      where: { key: 'app_logo' },
    });

    const title = emailTemplate.translation[0].title;
    let temp_content = emailTemplate.translation[0].content;

    const playStoreLinkImage = `<img
    src="${config.PLAY_STORE}"
    alt="Google Play Store" />`;

    const appleAppStoreLinkImage = `<img
    src="${config.APP_STORE}" 
    alt="Apple App Store" />`;

    if (setting) image = '<img alt="logo" src="' + setting.value + '" />';
    else image = '<img alt="logo" src="/img/logo.png" />';

    temp_content = temp_content.replace('{logo}', image);

    if (key == 'unblock_musician') {
      temp_content = temp_content.replace('{User_Name}', User.en_full_name);
      temp_content = temp_content.replace('{email}', User.email);
      temp_content = temp_content.replace('{play_store_link}', config.PLAY_STORE_LINK_MUSICIAN);
      temp_content = temp_content.replace('{apple_app_store_link}', config.APPLE_APP_STORE_LINK_MUSICIAN);
    }
    if (key == 'registration_musician') {
      temp_content = temp_content.replace('{User_Name}', User.en_full_name);
      temp_content = temp_content.replace('{email}', User.email);
      temp_content = temp_content.replace('{play_store_link}', config.PLAY_STORE_LINK_MUSICIAN);
      temp_content = temp_content.replace('{apple_app_store_link}', config.APPLE_APP_STORE_LINK_MUSICIAN);
    }
    if (key == 'registration_customer') {
      temp_content = temp_content.replace('{User_Name}', User.en_full_name);
      temp_content = temp_content.replace('{phone}', User.phone_number);
      temp_content = temp_content.replace('{play_store_link}', config.PLAY_STORE_LINK_CUSTOMER);
      temp_content = temp_content.replace('{apple_app_store_link}', config.APPLE_APP_STORE_LINK_CUSTOMER);
    }

    if (key == 'registration_sub_admin') {
      temp_content = temp_content.replace('{User_Name}', User.name);
      temp_content = temp_content.replace('{email}', User.email);
      temp_content = temp_content.replace('{admin_panel_link}', config.FRONTEND_URL);
    }

    temp_content = temp_content.replace('{password}', User.password);
    temp_content = temp_content.replace('{admin_email}', config.CLIENT_EMAIL);
    temp_content = temp_content.replace('{admin_email}', config.CLIENT_EMAIL);

    temp_content = temp_content.replace('{play_store_link_image}', playStoreLinkImage);
    temp_content = temp_content.replace('{apple_app_store_link_image}', appleAppStoreLinkImage);

    //make configuration
    const mailOptions = {
      from: config.SMTP_USER,
      to: User.email,
      subject: title,
      html: temp_content,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        throw new Error(error.message);
      } else {
        console.log('\x1b[36m%s\x1b[0m', '*************************');
        console.log('Message sent: ' + info);
        console.log('\x1b[36m%s\x1b[0m', '*************************');
      }
    });
  }
};

const sendForgotPasswordEmail = async (User, host = null) => {
  let image;
  const link = config.FRONTEND_URL + '/reset-password?token=' + User.forgot_password_token;
  //make mail setting
  console.log(link);

  const emailTemplate = await EnailTemplates.findOne({
    where: { is_deleted: 0, is_active: 1, key: 'forgot_password' },
    include: [
      {
        model: EmailTemplateTranslation,
        where: { language_code: 'en' },
        as: 'translation',
      },
    ],
  });

  if (emailTemplate) {
    const setting = await Settings.findOne({
      where: { key: 'app_logo' },
    });

    const title = emailTemplate.translation[0].title;
    let temp_content = emailTemplate.translation[0].content;

    if (setting) image = '<img alt="logo" src="' + setting.value + '" />';
    else image = '<img alt="logo" src="/img/logo.png" />';

    temp_content = temp_content.replace('{logo}', image);
    temp_content = temp_content.replace('{User_Name}', User.en_full_name);
    temp_content = temp_content.replace('{data}', link);
    // temp_content = temp_content.replace('{password}', User.password);
    temp_content = temp_content.replace('{admin_email}', config.CLIENT_EMAIL);
    temp_content = temp_content.replace('{admin_email}', config.CLIENT_EMAIL);

    temp_content = temp_content.replace('{play_store_link}', config.PLAY_STORE_LINK_MUSICIAN);
    temp_content = temp_content.replace('{apple_app_store_link}', config.APPLE_APP_STORE_LINK_MUSICIAN);

    const playStoreLinkImage = `<img
    src="${config.PLAY_STORE}"
    alt="Google Play Store" />`;

    const appleAppStoreLinkImage = `<img
    src="${config.APP_STORE}" 
    alt="Apple App Store" />`;

    temp_content = temp_content.replace('{play_store_link_image}', playStoreLinkImage);
    temp_content = temp_content.replace('{apple_app_store_link_image}', appleAppStoreLinkImage);

    //make configuration
    const mailOptions = {
      from: config.SMTP_USER,
      to: User.email,
      subject: title,
      html: temp_content,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        throw new Error(error.message);
      } else {
        console.log('\x1b[36m%s\x1b[0m', '*************************');
        console.log('Message sent: ' + info);
        console.log('\x1b[36m%s\x1b[0m', '*************************');
      }
    });
  }
};

const sendVerificationEmail = async User => {
  let image;
  //make mail setting

  const emailTemplate = await EnailTemplates.findOne({
    where: { is_deleted: 0, is_active: 1, key: 'verify_customer_email' },
    include: [
      {
        model: EmailTemplateTranslation,
        where: { language_code: 'en' },
        as: 'translation',
      },
    ],
  });

  if (emailTemplate) {
    const setting = await Settings.findOne({
      where: { key: 'app_logo' },
    });

    const title = emailTemplate.translation[0].title;
    let temp_content = emailTemplate.translation[0].content;

    const playStoreLinkImage = `<img
    src="${config.PLAY_STORE}"
    alt="Google Play Store" />`;

    const appleAppStoreLinkImage = `<img
    src="${config.APP_STORE}" 
    alt="Apple App Store" />`;

    if (setting) image = '<img alt="logo" src="' + setting.value + '" />';
    else image = '<img alt="logo" src="/img/logo.png" />';

    const link = config.FRONTEND_URL + '/verify-email?token=' + User.email_verification_token;

    temp_content = temp_content.replace('{logo}', image);
    temp_content = temp_content.replace('{User_Name}', User.en_full_name);
    temp_content = temp_content.replace('{link}', link);

    temp_content = temp_content.replace('{admin_email}', config.CLIENT_EMAIL);
    temp_content = temp_content.replace('{admin_email}', config.CLIENT_EMAIL);

    temp_content = temp_content.replace('{play_store_link}', config.PLAY_STORE_LINK_MUSICIAN);
    temp_content = temp_content.replace('{apple_app_store_link}', config.APPLE_APP_STORE_LINK_MUSICIAN);

    temp_content = temp_content.replace('{play_store_link_image}', playStoreLinkImage);
    temp_content = temp_content.replace('{apple_app_store_link_image}', appleAppStoreLinkImage);

    //make configuration
    const mailOptions = {
      from: config.SMTP_USER,
      to: User.email,
      subject: title,
      html: temp_content,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        throw new Error(error.message);
      } else {
        console.log('\x1b[36m%s\x1b[0m', '*************************');
        console.log('Message sent: ' + info);
        console.log('\x1b[36m%s\x1b[0m', '*************************');
      }
    });
  }
};

const becomeMusicianEmail = async User => {
  let image;
  //make mail setting

  const emailTemplate = await EnailTemplates.findOne({
    where: { is_deleted: 0, is_active: 1, key: 'become_musician' },
    include: [
      {
        model: EmailTemplateTranslation,
        where: { language_code: 'en' },
        as: 'translation',
      },
    ],
  });

  if (emailTemplate) {
    const setting = await Settings.findOne({
      where: { key: 'app_logo' },
    });

    const title = emailTemplate.translation[0].title;
    let temp_content = emailTemplate.translation[0].content;

    const playStoreLinkImage = `<img
    src="${config.PLAY_STORE}"
    alt="Google Play Store" />`;

    const appleAppStoreLinkImage = `<img
    src="${config.APP_STORE}" 
    alt="Apple App Store" />`;

    if (setting) image = '<img alt="logo" src="' + setting.value + '" />';
    else image = '<img alt="logo" src="/img/logo.png" />';

    temp_content = temp_content.replace('{logo}', image);

    temp_content = temp_content.replace('{User_Name}', User.full_name);
    temp_content = temp_content.replace('{email}', User.email);
    temp_content = temp_content.replace('{subject}', User.subject);
    temp_content = temp_content.replace('{message}', User.message);
    temp_content = temp_content.replace('{country_code}', User.country_code);
    temp_content = temp_content.replace('{mobile_number}', User.mobile_number);

    temp_content = temp_content.replace('{play_store_link}', config.PLAY_STORE_LINK_MUSICIAN);
    temp_content = temp_content.replace('{apple_app_store_link}', config.APPLE_APP_STORE_LINK_MUSICIAN);

    temp_content = temp_content.replace('{password}', User.password);
    temp_content = temp_content.replace('{admin_email}', config.CLIENT_EMAIL);
    temp_content = temp_content.replace('{admin_email}', config.CLIENT_EMAIL);

    temp_content = temp_content.replace('{play_store_link_image}', playStoreLinkImage);
    temp_content = temp_content.replace('{apple_app_store_link_image}', appleAppStoreLinkImage);

    //make configuration
    const mailOptions = {
      from: config.SMTP_USER,
      to: config.CLIENT_EMAIL,
      subject: title,
      html: temp_content,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        throw new Error(error.message);
      } else {
        console.log('\x1b[36m%s\x1b[0m', '*************************');
        console.log('Message sent: ' + info);
        console.log('\x1b[36m%s\x1b[0m', '*************************');
      }
    });
  }
};
export { sendMusicianRegistrationEmail, sendForgotPasswordEmail, sendVerificationEmail, becomeMusicianEmail };
