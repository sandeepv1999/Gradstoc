import { CronJob } from 'cron';
import moment from 'moment';
import { forEach } from 'p-iteration';
import { Op, Sequelize } from 'sequelize';
import { User } from '../models/users.model';
import * as emailService from './email.service';

const musicianUnblock = async () => {
  try {
    console.log('Cron running successfully');
    // const users = await User.findOne({ where: { id: 1 }, logging: true });
    // unblock musician and send email
    const currentTime = moment().unix();
    console.log(currentTime);
    const where: any = {};
    where.is_deleted = 0;
    where.actor = 4;
    where.is_suspended = 1;
    where.suspension_time = {
      [Op.ne]: null,
      [Op.lte]: currentTime,
    };

    const musicians = await User.findAll({
      where: where,
      order: [['id', 'DESC']],
      logging: true,
    });
    // console.log('>> musician >>', musicians);
    if (musicians.length > 0) {
      await forEach(musicians, async musician => {
        // console.log(musician.id);
        //send mail to musician
        emailService.sendMusicianRegistrationEmail(musician, 'unblock_musician');

        musician.is_suspended = 0;
        musician.suspension_time = null;
        musician.save();
      });
    }
  } catch (error) {
    console.error('****************Error in Musician unblock cron*************************');
    console.log(error);
    console.error('****************Error in Musician unblock cron*************************');
  }
};

new CronJob(
  '0 */5 * * * *',
  () => {
    const d = new Date();
    console.log('Cron Musician Unblock Running', d);
    musicianUnblock();
  },
  null,
  true,
);
