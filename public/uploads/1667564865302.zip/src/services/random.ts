/**
 * @file Random service
 * @copyright Peerbits
 * @author Abhishek Savani <abhishek.savani@peerbits.com>
 * DESCRIPTION
 */
import crypto from 'crypto';
import config from '../config';
export class RandomService {
  /**
   * Generates a pseudorandom string.
   * The length of the salt is specified by the environment
   * variable PBKDF2_N_SALT_BYTES.
   * The salt is to be used with the password service.
   */

  public salt(): string {
    return crypto.randomBytes(config.PBKDF2_N_SALT_BYTES).toString('base64');
  }

  public getCurrency(): string {
    return config.CURRENCY;
  }
}
