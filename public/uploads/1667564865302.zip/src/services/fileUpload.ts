/* eslint-disable @typescript-eslint/no-explicit-any */
import multer from 'multer';
import { Request } from 'express';
import { Config } from '../config';
import multerS3 from 'multer-s3';
import aws from 'aws-sdk';

export class FileUpload {
  constructor(private config: Config) {}
  public imageUpload = (): any => {
    // IMAGE UPLOAD IN LOCAL SERVER
    const storage = multer.diskStorage({
      destination: (req, file, cb) => {
        console.log("fileeee",file);
        cb(null, `${this.config.IMAGE_UPLOAD_PATH}/`);
      },
      filename: (req, file, cb) => {
        const extension: string[] = file.originalname.split('.');
        const fileName = Date.now() + '-' + file.fieldname + '.' + extension[extension.length - 1];
        cb(null, fileName);
      },
    });
    return multer({ storage: storage });
  };
  public imageUploadS3 = () => {
    // IMAGE UPLOAD IN S3
    
    console.log("sonalis",this.config.AWS_ACCESS_KEY_ID);
    console.log("sonali AWS_SECRET_ACCESS_KEYs",this.config.AWS_SECRET_ACCESS_KEY);

    const s3 = new aws.S3({
      accessKeyId: this.config.AWS_ACCESS_KEY_ID,
      secretAccessKey: this.config.AWS_SECRET_ACCESS_KEY,
    });

    console.log("s3",s3)
    console.log("thid",this.config.AWS_BUCKET)
    
    const upload = multer({
      storage: multerS3({
        s3: s3,
        bucket: this.config.AWS_BUCKET,
        contentType: multerS3.DEFAULT_CONTENT_TYPE,
        acl: 'public-read',
        metadata: function(req, file, cb) {
          cb(null, { fieldName: file.originalname });
        },
        key: function(req, file, cb) {
          cb(null, Date.now().toString() + '-' + file.originalname);
        },
      }),
    });
    console.log("upload",upload);

    return upload;
  };
  public checkImageType(req: Request): boolean {
    // THIS FUNCTION USE IN CONTROLLER.
    if (
      // !req.file.originalname.match(/\.(jpg|jpeg|png)$/) &&
      req.file.mimetype.split('/')[1] != 'jpeg' ||
      req.file.mimetype.split('/')[1] != 'jpg' ||
      req.file.mimetype.split('/')[1] != 'png'
    ) {
      return true;
    }
  }
}
