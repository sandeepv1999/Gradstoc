import FCM = require('fcm-push');
import { Notifications } from '../models/notification.model';
import { Token } from '../models/tokens.model';
import config from '../config';
import { setUpSequelize } from '../db/sql/connection';
import { NotificationTranslation } from '../models/notificationTranslation.model';
import { Op } from 'sequelize';
import { Actors, NotificationTypes, PushNotificaitonTypes } from '../utils/constants';
import moment from 'moment';
import { Language } from '../models/language.model';
import { message } from '../middlewares/auth.middleware';
import { map } from 'p-iteration';

const connection = setUpSequelize();

const serverkey = config.FIREBASE_API_KEY;

const fcm = new FCM(serverkey);

const SendPushNotification = (id: Array<string>, data: any) => {
  const message = {
    registration_ids: id,
    priority: 'high',
    delay_while_idle: false,
    time_to_live: 0,
    data: data,
    notification: data,
    aps: {
      alert: data,
      badge: 1,
      sound: 'default',
      // candidate_id: data.candidate_id ? data.candidate_id : 0,
      // proposal_id: data.proposal_id ? data.proposal_id : 0,
      notification_type: data.notification_type,
    },
    date: new Date(),
  };

  fcm
    .send(message)
    .then(function(response) {
      console.log('\x1b[36m%s\x1b[0m', 'Successfully sent with response: ', response);
    })
    .catch(function(err) {
      console.log('\x1b[33m%s\x1b[0m', 'Notification error :', err);
    });
};

export const saveNotificationData = async (data, senderId, recieverIds) => {
  await connection.transaction(async t => {
    const typeId = data[0].booking_id ? data[0].booking_id : null;
    const notification = await Notifications.create({
      from_id: senderId,
      receiver_ids: recieverIds.toString(),
      type: 0, // 0 for user notification 1 for notifications sent by admin
      notification_type: data[0].notification_type,
      redirection_id: typeId,
      to_type: data[0].to_type,
      notification_data: JSON.stringify(data),
      i_by: senderId,
      data: JSON.stringify(data),
    });

    data = data.map(data => {
      data.notification_id = notification.id;
      data.message = data.body;
      return data;
    });

    await NotificationTranslation.bulkCreate(data);
  });
};

const getUserTokens = async (user_ids: Array<number>, actor: number, language_code: string) => {
  const userTokens = await Token.findAll({
    where: {
      user_id: { [Op.in]: user_ids },
      // user_type: actor,
      is_notification: 1,
      user_language: language_code,
    },
  });
  const _tokens = userTokens.map(token => {
    return token.device_id;
  });

  return _tokens;
};

export const sendNotification = async (
  type: string,
  userIds: Array<number>,
  actor: Actors,
  data?: {
    company_name?: string;
    proposal_name?: string;
    user_name?: string;
    candidate_id?: number;
    proposal_id?: number;
    booking_id?: number;
  },
  fromUser?: number,
  adminNotificationData?: Array<any>,
) => {
  const getLanguages = await Language.findAll();

  let notificationData: any = [];
  console.log('in 2', data);
  notificationData = await map(getLanguages, async language => {
    let title = '';
    let body = '';
    let notification_type = type;
    switch (type) {
      case PushNotificaitonTypes.BOOKING_REQUEST:
        title = message(language.language_code, 'booking_request_title');
        body = message(language.language_code, 'booking_request_message');
        break;
      case PushNotificaitonTypes.CANCEL_REQUEST:
        title = message(language.language_code, 'cancel_request_title');
        body = message(language.language_code, 'cancel_request_message');
        title = title.replace('{customer_name}', String(data.user_name));
        body = body.replace('{customer_name}', String(data.user_name));
        break;
      case PushNotificaitonTypes.PAYMENT_DUE_REQUEST_ACCEPTED:
        title = message(language.language_code, 'payment_due_request_accept_title');
        body = message(language.language_code, 'payment_due_request_accept_message');
        break;
      case PushNotificaitonTypes.PAYMENT_DUE_REQUEST_REJECTED:
        title = message(language.language_code, 'payment_due_request_reject_title');
        body = message(language.language_code, 'payment_due_request_reject_message');
        break;
      case PushNotificaitonTypes.PAYMENT_REFUND:
        title = message(language.language_code, 'payment_refund_title');
        body = message(language.language_code, 'payment_refund_message');
        body = body.replace('{booking_id}', String(data.booking_id));
        break;
      case PushNotificaitonTypes.PORTFOLIO_APPROVED:
        title = message(language.language_code, 'portfolio_approved_title');
        body = message(language.language_code, 'portfolio_approved_message');
        break;
      case PushNotificaitonTypes.PORTFOLIO_UNAPPROVED:
        title = message(language.language_code, 'portfolio_rejected_title');
        body = message(language.language_code, 'portfolio_rejected_message');
        break;
      case PushNotificaitonTypes.RATING:
        title = message(language.language_code, 'rating_title');
        body = message(language.language_code, 'rating_message');
        body = body.replace('{customer_name}', String(data.user_name));
        break;
      case PushNotificaitonTypes.REQUEST_COMPLETED:
        title = message(language.language_code, 'request_completed_title');
        body = message(language.language_code, 'request_completed_message');
        body = body.replace('{musician_name}', String(data.user_name));
        break;
      case PushNotificaitonTypes.REQUEST_ACCEPTED:
        title = message(language.language_code, 'request_accepted_title');
        body = message(language.language_code, 'request_accepted_message');
        body = body.replace('{musician_name}', String(data.user_name));
        break;
      case PushNotificaitonTypes.REQUEST_REJECTED:
        title = message(language.language_code, 'request_rejected_title');
        body = message(language.language_code, 'request_rejected_message');
        body = body.replace('{musician_name}', String(data.user_name));
        break;
      case PushNotificaitonTypes.USER_DELETE:
        title = message(language.language_code, 'account_delete_title');
        body = message(language.language_code, 'account_delete_message');
        break;
      case PushNotificaitonTypes.USER_INACTIVE:
        title = message(language.language_code, 'account_inactive_title');
        body = message(language.language_code, 'account_inactive_message');
        break;
      case PushNotificaitonTypes.USER_BLOCK:
        title = message(language.language_code, 'account_block_title');
        body = message(language.language_code, 'account_block_message');
        break;
      case PushNotificaitonTypes.ACCOUNT_BLOCK_BY_REQUEST:
        title = message(language.language_code, 'account_block_by_request_cancellation_title');
        body = message(language.language_code, 'account_block_by_request_cancellation_message');
        body = body.replace('{consicutive_cancellation}', String(config.CONSICUTIVE_CANCELLATION));
        break;
      default:
        const getNotificationByLanguage = adminNotificationData.find(x => x.language_code == language.language_code);
        title = getNotificationByLanguage.title;
        body = getNotificationByLanguage.body;
        notification_type = getNotificationByLanguage.notification_type;
        break;
    }

    const firebaseIds = await getUserTokens(userIds, actor, language.language_code);

    const _notification = {
      title: title,
      body: body,
      notification_type: notification_type,
      date: moment(),
      to_type: actor,
      language_code: language.language_code,

      booking_id: data && data.booking_id && data.booking_id != null ? data.booking_id : 0,
    };
    // console.log('>>>>> in 3', _notification);
    SendPushNotification(firebaseIds, _notification);
    return _notification;
  });

  if (
    type != PushNotificaitonTypes.USER_DELETE &&
    type != PushNotificaitonTypes.USER_INACTIVE &&
    type != PushNotificaitonTypes.USER_BLOCK
  )
    saveNotificationData(notificationData, fromUser, userIds);
};
